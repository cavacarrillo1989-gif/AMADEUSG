export type UserRole = 'admin' | 'instructor' | 'student';

export interface User {
  id: string;
  name: string;
  email: string;
  username?: string;
  password?: string;
  role: UserRole;
  avatar: string;
  title?: string;
  bio?: string;
  registeredAt: string;
}

export type CourseStatus = 'published' | 'draft' | 'archived';

export interface Course {
  id: string;
  title: string;
  slug?: string;
  description: string;
  shortDescription: string;
  image: string;
  instructorId: string;
  durationHours: number;
  category: string;
  level: 'Básico' | 'Intermedio' | 'Avanzado';
  status: CourseStatus;
  createdAt: string;
  passingScorePercent: number; // e.g. 70
  price?: number;
  discountPrice?: number;
}

export interface CourseModule {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  order: number;
}

export type LessonType = 'video' | 'document' | 'zoom' | 'task' | 'quiz';

export type ResourceType = 'pdf' | 'doc' | 'slide' | 'link' | 'code' | 'zoom' | 'video' | 'other';

export interface LessonResource {
  id: string;
  title: string;
  type: ResourceType;
  url: string;
  size?: string;
  fileName?: string;
  description?: string;
}

export interface Lesson {
  id: string;
  moduleId: string;
  courseId: string;
  title: string;
  description: string;
  durationMinutes: number;
  order: number;
  type: LessonType;
  videoUrl?: string; // YouTube, Vimeo or MP4
  documentUrl?: string;
  documentContent?: string;
  resources?: LessonResource[];
  linkedTaskId?: string;
  linkedQuizId?: string;
  linkedZoomId?: string;
}

export interface Task {
  id: string;
  courseId: string;
  moduleId?: string;
  lessonId?: string;
  title: string;
  instructions: string;
  maxScore: number;
  dueDate: string;
  attachedFileUrl?: string;
  attachedFileName?: string;
  createdAt: string;
}

export type SubmissionStatus = 'submitted' | 'graded';

export interface TaskSubmission {
  id: string;
  taskId: string;
  studentId: string;
  courseId: string;
  submittedAt: string;
  comments: string;
  fileName?: string;
  fileSize?: string;
  fileUrl?: string;
  score?: number; // e.g. 18 / 20
  feedback?: string;
  gradedAt?: string;
  gradedBy?: string;
  status: SubmissionStatus;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  points: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  courseId: string;
  moduleId?: string;
  lessonId?: string;
  title: string;
  description: string;
  timeLimitMinutes: number;
  passingScore: number; // out of total points or percentage
  questions: QuizQuestion[];
  createdAt: string;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  studentId: string;
  courseId: string;
  completedAt: string;
  answers: Record<string, number>; // questionId -> selectedOptionIndex
  score: number;
  maxScore: number;
  passed: boolean;
}

export interface ZoomSession {
  id: string;
  courseId: string;
  moduleId?: string;
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  durationMinutes: number;
  zoomLink: string;
  meetingId: string;
  passcode: string;
  instructorName: string;
  status: 'upcoming' | 'live' | 'finished';
  recordingUrl?: string;
}

export type EnrollmentStatus = 'pending' | 'approved' | 'rejected';

export interface Enrollment {
  id: string;
  studentId: string;
  courseId: string;
  enrolledAt: string;
  completedLessonIds: string[];
  completedAt?: string;
  isCompleted: boolean;
  status: EnrollmentStatus;
  requestedAt?: string;
  approvedAt?: string;
  approvedBy?: string;
  rejectedReason?: string;
}

export interface Certificate {
  id: string;
  certificateCode: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  issueDate: string;
  durationHours: number;
  centerName: string;
  instructorName: string;
  directorName: string;
}

export interface CenterSettings {
  name: string;
  tagline: string;
  directorName: string;
  directorTitle: string;
  address: string;
  contactEmail: string;
  contactPhone: string;
  logoText: string;
  accreditationCode: string;
}

export type PaymentMethod = 'credit_card' | 'bank_transfer' | 'paypal' | 'whatsapp_advisor';

export interface PaymentTransaction {
  id: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  courseId: string;
  courseTitle: string;
  amount: number;
  currency: 'USD';
  method: PaymentMethod;
  status: 'completed' | 'pending' | 'failed';
  paymentDate: string;
  transactionRef: string;
  receiptNumber: string;
  cardLastFour?: string;
  bankName?: string;
  voucherFileName?: string;
}

