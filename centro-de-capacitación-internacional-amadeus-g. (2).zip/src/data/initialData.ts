import { User, Course, CourseModule, Lesson, Task, TaskSubmission, Quiz, QuizAttempt, ZoomSession, Enrollment, Certificate, CenterSettings, PaymentTransaction } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'usr_admin',
    name: 'Ing. Carlos Mendoza',
    email: 'director@amadeusg.edu.pe',
    username: 'admin',
    password: 'admin123',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    title: 'Director General de Capacitación',
    bio: 'Más de 15 años liderando programas de acreditación técnica y capacitación ejecutiva.',
    registeredAt: '2025-01-10',
  },
  {
    id: 'usr_inst_1',
    name: 'Dra. Elena Ramos',
    email: 'elena.ramos@amadeusg.edu.pe',
    username: 'elena.docente',
    password: 'docente123',
    role: 'instructor',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    title: 'Especialista en Inteligencia Artificial y Big Data',
    bio: 'Doctora en Computación, consultora senior para organismos multinacionales e investigadora.',
    registeredAt: '2025-01-15',
  },
  {
    id: 'usr_inst_2',
    name: 'Prof. Andrés Morales',
    email: 'andres.morales@amadeusg.edu.pe',
    username: 'andres.docente',
    password: 'docente123',
    role: 'instructor',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
    title: 'Enterprise Agile Coach & PMP',
    bio: 'Certified Scrum Trainer (CST) con 12 años implementando marcos ágiles en banca y retail.',
    registeredAt: '2025-02-01',
  },
  {
    id: 'usr_student_1',
    name: 'Sofía Castro',
    email: 'sofia.castro@empresa.com',
    username: 'sofia.estudiante',
    password: 'estudiante123',
    role: 'student',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    title: 'Coordinadora de Proyectos',
    bio: 'Profesional en constante actualización tecnológica buscando certificar competencias ágiles.',
    registeredAt: '2025-03-01',
  },
  {
    id: 'usr_student_2',
    name: 'Mateo Gómez',
    email: 'mateo.gomez@techdev.io',
    username: 'mateo.estudiante',
    password: 'estudiante123',
    role: 'student',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    title: 'Analista de Sistemas Junior',
    bio: 'Interesado en desarrollo full-stack e integración de modelos de lenguaje en aplicaciones web.',
    registeredAt: '2025-03-10',
  }
];

export const INITIAL_CENTER_SETTINGS: CenterSettings = {
  name: 'CENTRO DE CAPACITACIÓN INTERNACIONAL AMADEUS G.',
  tagline: 'Excelencia Académica y Certificación para el Futuro Laboral',
  directorName: 'Dr. Roberto Valenzuela Pardo',
  directorTitle: 'Director Académico y de Acreditación',
  address: 'Av. Las Begonias 441, San Isidro - Lima, Perú',
  contactEmail: 'informes@amadeusg.edu.pe',
  contactPhone: '+51 (01) 710-8500',
  logoText: 'AMADEUS G. Virtual',
  accreditationCode: ''
};

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course_1',
    title: 'Diplomado en Gestión de Proyectos Ágiles y Scrum',
    slug: 'scrum-gestion-agil',
    shortDescription: 'Domina los marcos Scrum, Kanban y Design Thinking para liderar equipos ágiles de alto rendimiento.',
    description: 'Programa oficial de capacitación diseñado para capacitar a líderes, gerentes y especialistas en metodologías ágiles. Aprenderás a planificar sprints, gestionar el backlog, implementar ceremonias efectivas, calcular la velocidad del equipo y preparar la certificación internacional PSM I / PMI-ACP.',
    image: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800&auto=format&fit=crop&q=80',
    instructorId: 'usr_inst_2',
    durationHours: 40,
    category: 'Gestión y Liderazgo',
    level: 'Intermedio',
    status: 'published',
    createdAt: '2025-02-15',
    passingScorePercent: 70
  },
  {
    id: 'course_2',
    title: 'Inteligencia Artificial y Análisis de Datos para Negocios',
    slug: 'ia-analisis-datos-negocios',
    shortDescription: 'Aplica herramientas de IA generativa, analítica predictiva y dashboards para la toma de decisiones estratégicas.',
    description: 'Capacitación intensiva para directivos, consultores y analistas. Descubre cómo aprovechar modelos de lenguaje, automatización con Python sin código avanzado, Power BI y métricas clave para potenciar la productividad y resolver problemas comerciales reales.',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
    instructorId: 'usr_inst_1',
    durationHours: 45,
    category: 'Tecnología e Inteligencia Artificial',
    level: 'Avanzado',
    status: 'published',
    createdAt: '2025-02-20',
    passingScorePercent: 75
  },
  {
    id: 'course_3',
    title: 'Desarrollo Web Full Stack con React, Node y TypeScript',
    slug: 'desarrollo-web-fullstack',
    shortDescription: 'Construye aplicaciones web escalables modernas desde la arquitectura de bases de datos hasta la interfaz de usuario.',
    description: 'Aprende a diseñar arquitecturas web robustas con Vite, React, Tailwind CSS, Node.js, Express y bases de datos relacionales y documentales. Incluye despliegue en la nube, pruebas unitarias y seguridad de APIs.',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80',
    instructorId: 'usr_inst_1',
    durationHours: 60,
    category: 'Ingeniería de Software',
    level: 'Intermedio',
    status: 'published',
    createdAt: '2025-03-01',
    passingScorePercent: 70
  }
];

export const INITIAL_MODULES: CourseModule[] = [
  // Modules for Course 1 (Agile & Scrum)
  {
    id: 'mod_1_1',
    courseId: 'course_1',
    title: 'Módulo 1: Fundamentos del Manifiesto Ágil y Mentalidad Lean',
    description: 'Principios rectores, historia, diferencias entre predictivo y adaptativo, y valores ágiles.',
    order: 1
  },
  {
    id: 'mod_1_2',
    courseId: 'course_1',
    title: 'Módulo 2: Marco de Trabajo Scrum (Roles, Eventos y Artefactos)',
    description: 'Product Owner, Scrum Master, Developers, Daily Scrum, Sprint Planning, Review y Retrospectiva.',
    order: 2
  },
  {
    id: 'mod_1_3',
    courseId: 'course_1',
    title: 'Módulo 3: Estimación, Métricas Ágiles y Taller Práctico',
    description: 'Planning Poker, Story Points, Burndown Charts, velocidad del equipo y gestión de impedimentos.',
    order: 3
  },
  // Modules for Course 2 (IA & Data)
  {
    id: 'mod_2_1',
    courseId: 'course_2',
    title: 'Módulo 1: Ecosistema de la Inteligencia Artificial y Machine Learning',
    description: 'Conceptos clave, IA generativa vs predictiva y oportunidades de negocio.',
    order: 1
  },
  {
    id: 'mod_2_2',
    courseId: 'course_2',
    title: 'Módulo 2: Prompt Engineering y Automatización de Procesos',
    description: 'Técnicas avanzadas de prompting, agentes y análisis automatizado de documentos.',
    order: 2
  }
];

export const INITIAL_LESSONS: Lesson[] = [
  // Lessons Course 1 - Module 1
  {
    id: 'les_1_1_1',
    moduleId: 'mod_1_1',
    courseId: 'course_1',
    title: '1.1 Bienvenida e Introducción a la Filosofía Ágil',
    description: 'En esta primera lección revisamos el contexto de la volatilidad e incertidumbre (VUCA), por qué las metodologías en cascada fallan en proyectos modernos y el surgimiento del Manifiesto Ágil.',
    durationMinutes: 25,
    order: 1,
    type: 'video',
    videoUrl: 'https://www.youtube.com/embed/502ILHjX9EE',
    resources: [
      { id: 'res_1', title: 'Guía Oficial del Manifiesto Ágil (PDF)', type: 'pdf', url: '#', size: '2.4 MB' },
      { id: 'res_2', title: 'Diapositivas de la Sesión Introductoria', type: 'slide', url: '#', size: '5.1 MB' }
    ]
  },
  {
    id: 'les_1_1_2',
    moduleId: 'mod_1_1',
    courseId: 'course_1',
    title: '1.2 Los 4 Valores y 12 Principios del Manifiesto Ágil',
    description: 'Lectura estructurada y análisis de casos reales: cómo priorizar individuos e interacciones sobre procesos y herramientas.',
    durationMinutes: 20,
    order: 2,
    type: 'document',
    documentContent: `### Los 4 Valores Esenciales de la Agilidad

1. **Individuos e interacciones** sobre procesos y herramientas.
2. **Software/producto funcionando** sobre documentación extensiva.
3. **Colaboración con el cliente** sobre negociación contractual.
4. **Respuesta ante el cambio** sobre seguir un plan estricto.

*Nota pedagógica:* Aunque valoramos los elementos de la derecha, valoramos aún más los elementos de la izquierda. En el entorno laboral actual de alta competencia, la adaptabilidad rápida es la mayor ventaja competitiva.

#### Los 12 Principios en la Práctica
- Nuestra mayor prioridad es satisfacer al cliente mediante la entrega temprana y continua de valor.
- Aceptamos requisitos cambiantes, incluso en etapas avanzadas del desarrollo.
- Los procesos ágiles aprovechan el cambio para proporcionar ventaja competitiva.
- Entregamos valor con frecuencia, desde un par de semanas a un par de meses.`,
    resources: [
      { id: 'res_3', title: 'Matriz de Evaluación de Agilidad Organizacional (Excel)', type: 'doc', url: '#', size: '1.1 MB' }
    ]
  },
  {
    id: 'les_1_1_3',
    moduleId: 'mod_1_1',
    courseId: 'course_1',
    title: '1.3 Sesión en Vivo Zoom: Debate de Casos Ágiles y Q&A',
    description: 'Clase sincrónica con el Prof. Andrés Morales para analizar dilemas reales en la adopción ágil en empresas de servicios y tecnología.',
    durationMinutes: 60,
    order: 3,
    type: 'zoom',
    linkedZoomId: 'zoom_1'
  },
  {
    id: 'les_1_1_4',
    moduleId: 'mod_1_1',
    courseId: 'course_1',
    title: '1.4 Evaluación Corta: Principios y Valores Ágiles',
    description: 'Cuestionario de evaluación formativa para medir tu comprensión de los principios ágiles.',
    durationMinutes: 15,
    order: 4,
    type: 'quiz',
    linkedQuizId: 'quiz_1'
  },
  // Lessons Course 1 - Module 2
  {
    id: 'les_1_2_1',
    moduleId: 'mod_1_2',
    courseId: 'course_1',
    title: '2.1 Roles en Scrum: Product Owner, Scrum Master y Desarrolladores',
    description: 'Responsabilidades clave, accountability y cómo evitar los errores más comunes de microgestión en equipos de alto rendimiento.',
    durationMinutes: 30,
    order: 1,
    type: 'video',
    videoUrl: 'https://www.youtube.com/embed/9TycLR0TqFA',
    resources: [
      { id: 'res_4', title: 'Scrum Guide Oficial 2020 en Español (PDF)', type: 'pdf', url: '#', size: '1.8 MB' },
      { id: 'res_5', title: 'Plantilla de Definición de Roles RACI', type: 'doc', url: '#', size: '850 KB' }
    ]
  },
  {
    id: 'les_1_2_2',
    moduleId: 'mod_1_2',
    courseId: 'course_1',
    title: '2.2 Tarea Práctica: Redacción de Historias de Usuario y Criterios de Aceptación',
    description: 'Aplica la técnica INVEST para diseñar el Product Backlog inicial de un producto digital con sus criterios de aceptación.',
    durationMinutes: 45,
    order: 2,
    type: 'task',
    linkedTaskId: 'task_1'
  },
  {
    id: 'les_1_2_3',
    moduleId: 'mod_1_2',
    courseId: 'course_1',
    title: '2.3 Examen Final de Certificación del Diplomado Scrum',
    description: 'Evaluación integral de 5 preguntas de selección múltiple con casos prácticos para la obtención de tu Certificado Oficial.',
    durationMinutes: 20,
    order: 3,
    type: 'quiz',
    linkedQuizId: 'quiz_2'
  },

  // Lessons Course 2 - Module 1
  {
    id: 'les_2_1_1',
    moduleId: 'mod_2_1',
    courseId: 'course_2',
    title: '1.1 Introducción a Modelos Fundacionales y Transformers',
    description: 'Aprende los fundamentos técnicos de los LLMs, embeddings y cómo las empresas están creando soluciones inteligentes.',
    durationMinutes: 35,
    order: 1,
    type: 'video',
    videoUrl: 'https://www.youtube.com/embed/aircAruvnKk',
    resources: [
      { id: 'res_6', title: 'Infografía Arquitectura Transformer (PDF)', type: 'pdf', url: '#', size: '3.2 MB' }
    ]
  },
  {
    id: 'les_2_1_2',
    moduleId: 'mod_2_1',
    courseId: 'course_2',
    title: '1.2 Clase en Vivo Zoom: Casos de Uso Empresariales con IA',
    description: 'Sesión interactiva en directo con la Dra. Elena Ramos revisando casos reales de optimización y retorno de inversión.',
    durationMinutes: 75,
    order: 2,
    type: 'zoom',
    linkedZoomId: 'zoom_2'
  }
];

export const INITIAL_TASKS: Task[] = [
  {
    id: 'task_1',
    courseId: 'course_1',
    moduleId: 'mod_1_2',
    lessonId: 'les_1_2_2',
    title: 'Diseño de Backlog y 3 Historias de Usuario con Rúbrica INVEST',
    instructions: `### Instrucciones de la Tarea:
1. Selecciona un caso de negocio (ejemplo: Plataforma de capacitación virtual, App de entregas o Sistema bancario móvil).
2. Redacta el **Objetivo del Producto (Product Goal)** en 1 párrafo.
3. Elabora **3 Historias de Usuario completas** respetando el formato estándar:
   - *Como [rol de usuario]*
   - *Quiero [acción o funcionalidad]*
   - *Para [beneficio o valor de negocio esperado]*
4. Define al menos **3 Criterios de Aceptación (Gherkin: Dado/Cuando/Entonces)** para cada historia.
5. Sube tu trabajo en formato PDF o redacta la entrega directamente en el formulario con tu enlace público de Notion/Google Docs.`,
    maxScore: 20,
    dueDate: '2026-10-30T23:59:00',
    attachedFileName: 'Plantilla_Historias_Usuario_AMADEUS.docx',
    attachedFileUrl: '#',
    createdAt: '2025-02-18'
  }
];

export const INITIAL_TASK_SUBMISSIONS: TaskSubmission[] = [
  {
    id: 'sub_1',
    taskId: 'task_1',
    studentId: 'usr_student_1',
    courseId: 'course_1',
    submittedAt: '2025-03-12T16:30:00',
    comments: 'Estimado profesor Andrés, adjunto mi entrega con las 3 historias de usuario para el sistema de matrículas virtuales con criterios en formato Gherkin.',
    fileName: 'Entrega_Historias_Sofia_Castro.pdf',
    fileSize: '1.4 MB',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    score: 19,
    feedback: '¡Excelente trabajo, Sofía! La redacción cumple a cabalidad con la regla INVEST. Destaco especialmente la claridad en los criterios de aceptación de la pasarela de pagos. ¡Aprobado con honores!',
    gradedAt: '2025-03-13T10:15:00',
    gradedBy: 'Prof. Andrés Morales',
    status: 'graded'
  }
];

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 'quiz_1',
    courseId: 'course_1',
    moduleId: 'mod_1_1',
    lessonId: 'les_1_1_4',
    title: 'Control de Lectura 1: Principios y Valores Ágiles',
    description: 'Comprueba tu dominio de los conceptos esenciales del Manifiesto Ágil. Tienes 15 minutos para responder 3 preguntas.',
    timeLimitMinutes: 15,
    passingScore: 14,
    createdAt: '2025-02-16',
    questions: [
      {
        id: 'q1_1',
        question: '¿Cuál de los siguientes enunciados representa un valor fundamental del Manifiesto Ágil?',
        options: [
          'Seguir un plan detallado sobre la respuesta al cambio',
          'Documentación extensiva sobre el software funcionando',
          'Individuos e interacciones sobre procesos y herramientas',
          'Negociación de contratos sobre la colaboración continua'
        ],
        correctOptionIndex: 2,
        points: 7,
        explanation: 'El Manifiesto Ágil establece explícitamente: "Individuos e interacciones sobre procesos y herramientas".'
      },
      {
        id: 'q1_2',
        question: 'En un entorno ágil, ¿cómo se conciben los requisitos cambiantes?',
        options: [
          'Como una falla de planificación que debe penalizarse económicamente',
          'Como una oportunidad para proporcionar ventaja competitiva al cliente',
          'Están prohibidos una vez iniciado el desarrollo del proyecto',
          'Solo se aceptan si son autorizados por el comité de control de cambios tradicional'
        ],
        correctOptionIndex: 1,
        points: 7,
        explanation: 'El segundo principio ágil indica: "Aceptamos requisitos cambiantes, incluso en etapas avanzadas; los procesos ágiles aprovechan el cambio para dar ventaja competitiva".'
      },
      {
        id: 'q1_3',
        question: '¿Cuál es la medida principal de progreso en los proyectos ágiles según los 12 principios?',
        options: [
          'La cantidad de horas hombre consumidas según el diagrama de Gantt',
          'El cumplimiento exacto de la documentación de requerimientos',
          'El producto o software funcionando que entrega valor real',
          'El número de reuniones diarias ejecutadas exitosamente'
        ],
        correctOptionIndex: 2,
        points: 6,
        explanation: 'El séptimo principio afirma: "El producto funcionando es la medida principal de progreso".'
      }
    ]
  },
  {
    id: 'quiz_2',
    courseId: 'course_1',
    moduleId: 'mod_1_2',
    lessonId: 'les_1_2_3',
    title: 'Examen de Certificación: Fundamentos y Gestión con Scrum',
    description: 'Examen oficial para la acreditación académica en el Diplomado de Gestión Ágil. Nota mínima aprobatoria: 14/20.',
    timeLimitMinutes: 25,
    passingScore: 14,
    createdAt: '2025-02-22',
    questions: [
      {
        id: 'q2_1',
        question: '¿Quién es el único responsable de maximizar el valor del producto y gestionar el Product Backlog en Scrum?',
        options: [
          'El Scrum Master',
          'El Product Owner',
          'El Gerente de Proyecto tradicional',
          'Los Desarrolladores (Developers)'
        ],
        correctOptionIndex: 1,
        points: 5,
        explanation: 'El Product Owner es la persona encargada de maximizar el valor del producto resultante del trabajo del Scrum Team y el único dueño del Product Backlog.'
      },
      {
        id: 'q2_2',
        question: '¿Cuál es la duración máxima recomendada para el Daily Scrum?',
        options: [
          '30 minutos con diapositivas',
          '15 minutos, manteniendo un formato enfocado',
          '45 minutos para resolver todos los problemas técnicos',
          '1 hora semanal los días lunes'
        ],
        correctOptionIndex: 1,
        points: 5,
        explanation: 'El Daily Scrum es un evento de 15 minutos para que los Developers inspeccionen el progreso hacia el Sprint Goal y adapten el Sprint Backlog.'
      },
      {
        id: 'q2_3',
        question: '¿Qué es el "Incremento" en el marco Scrum?',
        options: [
          'Una versión preliminar que aún no ha sido testeada',
          'Un peldaño concreto hacia el Product Goal que cumple con la Definición de Terminado (DoD)',
          'El reporte financiero de horas invertidas presentado al cliente',
          'La lista de tareas pendientes que quedaron para el siguiente ciclo'
        ],
        correctOptionIndex: 1,
        points: 5,
        explanation: 'Un Incremento es un peldaño concreto hacia el Product Goal; cada Incremento se suma a todos los anteriores y debe ser utilizable y cumplir la Definition of Done.'
      },
      {
        id: 'q2_4',
        question: '¿Qué evento de Scrum tiene como objetivo principal que el equipo inspeccione cómo fue el último Sprint con respecto a personas, relaciones, procesos y herramientas para planificar mejoras?',
        options: [
          'Sprint Planning',
          'Sprint Review',
          'Sprint Retrospective',
          'Grooming o Refinamiento'
        ],
        correctOptionIndex: 2,
        points: 5,
        explanation: 'La Retrospectiva del Sprint inspecciona el funcionamiento del equipo y crea un plan de mejoras para ejecutarse en el siguiente Sprint.'
      }
    ]
  }
];

export const INITIAL_QUIZ_ATTEMPTS: QuizAttempt[] = [
  {
    id: 'att_1',
    quizId: 'quiz_1',
    studentId: 'usr_student_1',
    courseId: 'course_1',
    completedAt: '2025-03-11T14:20:00',
    answers: {
      'q1_1': 2,
      'q1_2': 1,
      'q1_3': 2
    },
    score: 20,
    maxScore: 20,
    passed: true
  },
  {
    id: 'att_2',
    quizId: 'quiz_2',
    studentId: 'usr_student_1',
    courseId: 'course_1',
    completedAt: '2025-03-14T11:05:00',
    answers: {
      'q2_1': 1,
      'q2_2': 1,
      'q2_3': 1,
      'q2_4': 2
    },
    score: 20,
    maxScore: 20,
    passed: true
  }
];

export const INITIAL_ZOOM_SESSIONS: ZoomSession[] = [
  {
    id: 'zoom_1',
    courseId: 'course_1',
    moduleId: 'mod_1_1',
    title: 'Clase Magistral en Vivo: Casos Reales de Transformación Ágil',
    description: 'Sesión interactiva en vivo por Zoom con el Prof. Andrés Morales. Análisis de tableros Jira, resolución de impedimentos y sesión de preguntas abiertas.',
    date: '2026-09-22',
    startTime: '19:30',
    durationMinutes: 60,
    zoomLink: 'https://zoom.us/j/84920481023?pwd=AMADEUS_AGILE_2026',
    meetingId: '849 2048 1023',
    passcode: 'AMADEUS2026',
    instructorName: 'Prof. Andrés Morales',
    status: 'upcoming',
    recordingUrl: 'https://www.youtube.com/embed/502ILHjX9EE'
  },
  {
    id: 'zoom_2',
    courseId: 'course_2',
    moduleId: 'mod_2_1',
    title: 'Taller Práctico Zoom: Construcción de Agentes y Automatización de Negocios',
    description: 'Sesión de laboratorio en tiempo real guiada por la Dra. Elena Ramos. Conexión de APIs, generación de reportes y optimización de prompts.',
    date: '2026-09-25',
    startTime: '20:00',
    durationMinutes: 90,
    zoomLink: 'https://zoom.us/j/91238475610?pwd=AMADEUS_AI_2026',
    meetingId: '912 3847 5610',
    passcode: 'DATA99',
    instructorName: 'Dra. Elena Ramos',
    status: 'upcoming'
  }
];

export const INITIAL_ENROLLMENTS: Enrollment[] = [
  {
    id: 'enr_1',
    studentId: 'usr_student_1',
    courseId: 'course_1',
    enrolledAt: '2025-03-02',
    completedLessonIds: ['les_1_1_1', 'les_1_1_2', 'les_1_1_3', 'les_1_1_4', 'les_1_2_1', 'les_1_2_2', 'les_1_2_3'],
    completedAt: '2025-03-14',
    isCompleted: true,
    status: 'approved',
    approvedAt: '2025-03-02',
    approvedBy: 'Dr. Roberto Valenzuela (Admin)'
  },
  {
    id: 'enr_2',
    studentId: 'usr_student_1',
    courseId: 'course_2',
    enrolledAt: '2025-03-10',
    completedLessonIds: ['les_2_1_1'],
    isCompleted: false,
    status: 'approved',
    approvedAt: '2025-03-10',
    approvedBy: 'Dr. Roberto Valenzuela (Admin)'
  },
  {
    id: 'enr_3',
    studentId: 'usr_student_2',
    courseId: 'course_1',
    enrolledAt: '2025-03-12',
    completedLessonIds: ['les_1_1_1'],
    isCompleted: false,
    status: 'approved',
    approvedAt: '2025-03-12',
    approvedBy: 'Dr. Roberto Valenzuela (Admin)'
  },
  {
    id: 'enr_4',
    studentId: 'usr_student_2',
    courseId: 'course_3',
    enrolledAt: '2025-03-16',
    requestedAt: '2025-03-16',
    completedLessonIds: [],
    isCompleted: false,
    status: 'pending'
  },
  {
    id: 'enr_5',
    studentId: 'usr_student_1',
    courseId: 'course_4',
    enrolledAt: '2025-03-17',
    requestedAt: '2025-03-17',
    completedLessonIds: [],
    isCompleted: false,
    status: 'pending'
  }
];

export const INITIAL_CERTIFICATES: Certificate[] = [
  {
    id: 'cert_1',
    certificateCode: 'AMADEUS-2025-AGL-89412',
    studentId: 'usr_student_1',
    studentName: 'Sofía Castro',
    courseId: 'course_1',
    courseTitle: 'Diplomado en Gestión de Proyectos Ágiles y Scrum',
    issueDate: '15 de Marzo de 2025',
    durationHours: 40,
    centerName: 'CENTRO DE CAPACITACIÓN INTERNACIONAL AMADEUS G.',
    instructorName: 'Prof. Andrés Morales',
    directorName: 'Dr. Roberto Valenzuela Pardo'
  }
];

export const INITIAL_TRANSACTIONS: PaymentTransaction[] = [
  {
    id: 'tx_1',
    studentId: 'usr_student_1',
    studentName: 'Sofía Castro',
    studentEmail: 'sofia.castro@empresa.com',
    courseId: 'course_1',
    courseTitle: 'Diplomado en Gestión de Proyectos Ágiles y Scrum',
    amount: 149,
    currency: 'USD',
    method: 'credit_card',
    status: 'completed',
    paymentDate: '2025-03-01T14:30:00.000Z',
    transactionRef: 'PAY-CC-9921408',
    receiptNumber: 'REC-2025-0101',
    cardLastFour: '4242'
  },
  {
    id: 'tx_2',
    studentId: 'usr_student_2',
    studentName: 'Mateo Gómez',
    studentEmail: 'mateo.gomez@techdev.io',
    courseId: 'course_1',
    courseTitle: 'Diplomado en Gestión de Proyectos Ágiles y Scrum',
    amount: 149,
    currency: 'USD',
    method: 'bank_transfer',
    status: 'completed',
    paymentDate: '2025-03-12T09:15:00.000Z',
    transactionRef: 'PICH-TRANS-55102',
    receiptNumber: 'REC-2025-0102',
    bankName: 'Banco Pichincha',
    voucherFileName: 'comprobante_banco_pichincha_55102.pdf'
  },
  {
    id: 'tx_3',
    studentId: 'usr_student_1',
    studentName: 'Sofía Castro',
    studentEmail: 'sofia.castro@empresa.com',
    courseId: 'course_2',
    courseTitle: 'Especialización en Ciencia de Datos y Machine Learning con Python',
    amount: 189,
    currency: 'USD',
    method: 'paypal',
    status: 'completed',
    paymentDate: '2025-03-14T16:45:00.000Z',
    transactionRef: 'PP-ORD-8874102',
    receiptNumber: 'REC-2025-0103'
  },
  {
    id: 'tx_4',
    studentId: 'usr_student_2',
    studentName: 'Mateo Gómez',
    studentEmail: 'mateo.gomez@techdev.io',
    courseId: 'course_3',
    courseTitle: 'Power BI Empresarial y Dashboard Analytics',
    amount: 129,
    currency: 'USD',
    method: 'whatsapp_advisor',
    status: 'completed',
    paymentDate: '2025-03-15T11:20:00.000Z',
    transactionRef: 'WA-ADV-0997342614',
    receiptNumber: 'REC-2025-0104'
  }
];

