import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  CheckSquare,
  Video,
  Award,
  Users,
  Edit3,
  Edit2,
  Trash2,
  Calendar,
  FileText,
  Clock,
  Send,
  CheckCircle2,
  ExternalLink,
  ChevronDown,
  Layers,
  HelpCircle,
  Paperclip,
  Presentation,
  Download,
  AlertCircle
} from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';
import { Course, CourseModule, Lesson, Task, TaskSubmission, Quiz, ZoomSession } from '../types';
import { EditCourseModal } from './modals/EditCourseModal';
import { ModuleModal } from './modals/ModuleModal';
import { LessonModal } from './modals/LessonModal';
import { TaskModal } from './modals/TaskModal';
import { QuizModal } from './modals/QuizModal';

interface InstructorPanelProps {
  onOpenClassroom: (courseId: string) => void;
  activeSubTab?: 'courses' | 'grading' | 'zoom' | 'students';
}

export const InstructorPanel: React.FC<InstructorPanelProps> = ({
  onOpenClassroom,
  activeSubTab = 'courses'
}) => {
  const {
    currentUser,
    courses,
    modules,
    lessons,
    tasks,
    taskSubmissions,
    quizzes,
    zoomSessions,
    users,
    enrollments,
    deleteModule,
    deleteLesson,
    deleteTask,
    deleteQuiz,
    createZoomSession,
    deleteZoomSession,
    gradeTaskSubmission,
    getCourseProgress
  } = usePlatform();

  // Courses where current user is assigned as instructor, or fallback to all courses
  const myCourses = courses.filter(c => c.instructorId === currentUser.id);
  const availableCourses = myCourses.length > 0 ? myCourses : courses;
  const [selectedCourseId, setSelectedCourseId] = useState<string>(() => availableCourses[0]?.id || courses[0]?.id || '');

  // Submissions for courses of this instructor
  const myCourseIds = myCourses.length > 0 ? myCourses.map(c => c.id) : courses.map(c => c.id);
  const mySubmissions = taskSubmissions.filter(s => myCourseIds.includes(s.courseId));

  // Grading modal state
  const [gradingSubmission, setGradingSubmission] = useState<TaskSubmission | null>(null);
  const [gradeScore, setGradeScore] = useState<number>(18);
  const [gradeFeedback, setGradeFeedback] = useState<string>('');

  // Course editing state
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);

  // Module modal state
  const [isModuleModalOpen, setIsModuleModalOpen] = useState(false);
  const [editingModule, setEditingModule] = useState<CourseModule | null>(null);

  // Lesson modal state
  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [lessonModalModuleId, setLessonModalModuleId] = useState<string>('');

  // Task modal state
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskModalModuleId, setTaskModalModuleId] = useState<string>('');

  // Quiz modal state
  const [isQuizModalOpen, setIsQuizModalOpen] = useState(false);
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);
  const [quizModalModuleId, setQuizModalModuleId] = useState<string>('');

  // Tab within course manager
  const [courseContentTab, setCourseContentTab] = useState<'structure' | 'tasks' | 'quizzes'>('structure');

  // Zoom scheduling modal
  const [showZoomModal, setShowZoomModal] = useState(false);
  const [newZoomTitle, setNewZoomTitle] = useState('');
  const [newZoomDate, setNewZoomDate] = useState('2026-09-28');
  const [newZoomTime, setNewZoomTime] = useState('19:00');
  const [newZoomDuration, setNewZoomDuration] = useState(60);
  const [newZoomLink, setNewZoomLink] = useState('https://zoom.us/j/1234567890');
  const [newZoomId, setNewZoomId] = useState('123 456 7890');
  const [newZoomPasscode, setNewZoomPasscode] = useState('AMADEUS2026');

  // Handle grade submission
  const handleSaveGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gradingSubmission) return;
    gradeTaskSubmission(gradingSubmission.id, gradeScore, gradeFeedback);
    setGradingSubmission(null);
    alert('Calificación guardada y retroalimentación enviada al estudiante con éxito.');
  };

  const handleCreateZoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newZoomTitle.trim() || !selectedCourseId) return;

    createZoomSession({
      courseId: selectedCourseId,
      title: newZoomTitle,
      description: 'Clase sincrónica de refuerzo e interacción.',
      date: newZoomDate,
      startTime: newZoomTime,
      durationMinutes: newZoomDuration,
      zoomLink: newZoomLink,
      meetingId: newZoomId,
      passcode: newZoomPasscode,
      instructorName: currentUser.name,
      status: 'upcoming'
    });

    setNewZoomTitle('');
    setShowZoomModal(false);
    alert('Clase Zoom programada e integrada en el aula.');
  };

  const activeCourse = courses.find(c => c.id === selectedCourseId) || availableCourses[0];
  const activeCourseModules = modules.filter(m => m.courseId === activeCourse?.id);
  const activeCourseLessons = lessons.filter(l => l.courseId === activeCourse?.id);
  const activeCourseTasks = tasks.filter(t => t.courseId === activeCourse?.id);
  const activeCourseQuizzes = quizzes.filter(q => q.courseId === activeCourse?.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">
            Panel del Docente / Instructor
          </span>
          <h1 className="text-2xl font-black text-slate-900 mt-1">
            Gestión Académica de Cursos
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Bienvenido, <strong className="text-slate-800">{currentUser.name}</strong>. Administra tus contenidos, califica tareas y monitorea a tus alumnos.
          </p>
        </div>

        {/* Course Selector Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-600">Curso Seleccionado:</span>
          <select
            value={selectedCourseId}
            onChange={e => setSelectedCourseId(e.target.value)}
            className="text-xs font-bold text-slate-800 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500"
          >
            {myCourses.map(c => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Subtab: Courses & Content Builder */}
      {activeSubTab === 'courses' && activeCourse && (
        <div className="space-y-6">
          {/* Active Course Banner */}
          <div className="bg-slate-900 text-white rounded-2xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-5 shadow-lg border border-slate-800">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-800">
                  {activeCourse.category}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-semibold border border-slate-700">
                  Nivel: {activeCourse.level}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-semibold border border-slate-700">
                  {activeCourse.durationHours} hrs lectivas
                </span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                  activeCourse.status === 'published' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}>
                  {activeCourse.status === 'published' ? 'Publicado en Plataforma' : 'Modo Borrador'}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {activeCourse.title}
              </h2>
              <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
                {activeCourse.shortDescription || activeCourse.description}
              </p>
              <div className="text-[11px] text-slate-400 pt-1">
                Docente Responsable: <strong className="text-slate-200">{users.find(u => u.id === activeCourse.instructorId)?.name || 'Asignado'}</strong> • {activeCourseModules.length} módulos • {activeCourseLessons.length} lecciones • {activeCourseTasks.length} tareas • {activeCourseQuizzes.length} exámenes
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 sm:shrink-0">
              <button
                onClick={() => setEditingCourse(activeCourse)}
                className="px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
                title="Editar título, descripción, categoría, nivel, horas y docente asignado"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Editar Datos del Curso</span>
              </button>

              <button
                onClick={() => onOpenClassroom(activeCourse.id)}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition border border-slate-700"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Ver Aula Virtual</span>
              </button>
            </div>
          </div>

          {/* Sub-Navigation Pills for Content Management */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setCourseContentTab('structure')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  courseContentTab === 'structure'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Módulos y Lecciones ({activeCourseLessons.length})</span>
              </button>

              <button
                onClick={() => setCourseContentTab('tasks')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  courseContentTab === 'tasks'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <CheckSquare className="w-3.5 h-3.5" />
                <span>Tareas y Asignaciones ({activeCourseTasks.length})</span>
              </button>

              <button
                onClick={() => setCourseContentTab('quizzes')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  courseContentTab === 'quizzes'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Exámenes y Evaluaciones ({activeCourseQuizzes.length})</span>
              </button>
            </div>

            {/* Quick action buttons depending on selected tab */}
            {courseContentTab === 'structure' && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setEditingModule(null);
                    setIsModuleModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-xl text-xs border border-emerald-200 flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nuevo Módulo</span>
                </button>
                <button
                  onClick={() => {
                    if (activeCourseModules.length === 0) {
                      alert('Primero debes crear al menos un módulo.');
                      return;
                    }
                    setEditingLesson(null);
                    setLessonModalModuleId(activeCourseModules[0].id);
                    setIsLessonModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nueva Lección</span>
                </button>
              </div>
            )}

            {courseContentTab === 'tasks' && (
              <button
                onClick={() => {
                  setEditingTask(null);
                  setTaskModalModuleId(activeCourseModules[0]?.id || '');
                  setIsTaskModalOpen(true);
                }}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Crear Nueva Tarea</span>
              </button>
            )}

            {courseContentTab === 'quizzes' && (
              <button
                onClick={() => {
                  setEditingQuiz(null);
                  setQuizModalModuleId(activeCourseModules[0]?.id || '');
                  setIsQuizModalOpen(true);
                }}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Crear Nuevo Examen</span>
              </button>
            )}
          </div>

          {/* TAB 1: Modules & Lessons Structure */}
          {courseContentTab === 'structure' && (
            <div className="space-y-4">
              {activeCourseModules.map((mod, modIdx) => {
                const modLessons = activeCourseLessons.filter(l => l.moduleId === mod.id);

                return (
                  <div key={mod.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                    <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md uppercase tracking-wider">
                            Módulo {modIdx + 1}
                          </span>
                          <h4 className="font-bold text-slate-900 text-sm">
                            {mod.title}
                          </h4>
                        </div>
                        {mod.description && (
                          <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                            {mod.description}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => {
                            setEditingLesson(null);
                            setLessonModalModuleId(mod.id);
                            setIsLessonModalOpen(true);
                          }}
                          className="px-2.5 py-1 bg-white hover:bg-slate-100 text-blue-700 font-semibold rounded-lg text-xs border border-slate-200 flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>Lección</span>
                        </button>
                        <button
                          onClick={() => {
                            setEditingModule(mod);
                            setIsModuleModalOpen(true);
                          }}
                          className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 font-semibold rounded-lg text-xs border border-slate-200 flex items-center gap-1"
                          title="Editar título y descripción del módulo"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Editar</span>
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`¿Eliminar el módulo "${mod.title}" y todas sus lecciones?`)) {
                              deleteModule(mod.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                          title="Eliminar módulo"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="divide-y divide-slate-100">
                      {modLessons.map(lesson => {
                        const hasResources = lesson.resources && lesson.resources.length > 0;

                        return (
                          <div key={lesson.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition">
                            <div className="flex items-start gap-3">
                              <div className="p-2 rounded-xl bg-slate-100 text-slate-700 shrink-0 mt-0.5">
                                {lesson.type === 'video' && <Video className="w-4 h-4 text-rose-600" />}
                                {lesson.type === 'document' && <FileText className="w-4 h-4 text-blue-600" />}
                                {lesson.type === 'task' && <CheckSquare className="w-4 h-4 text-amber-600" />}
                                {lesson.type === 'quiz' && <HelpCircle className="w-4 h-4 text-purple-600" />}
                                {lesson.type === 'zoom' && <Video className="w-4 h-4 text-emerald-600" />}
                              </div>

                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-900 text-sm">
                                    {lesson.title}
                                  </span>
                                  <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-slate-100 text-slate-600">
                                    {lesson.type}
                                  </span>
                                </div>
                                <div className="text-slate-500 text-xs flex flex-wrap items-center gap-3">
                                  <span>{lesson.durationMinutes} minutos</span>
                                  {lesson.videoUrl && (
                                    <span className="text-blue-600 truncate max-w-xs text-[11px]">
                                      • Video streaming vinculado
                                    </span>
                                  )}
                                  {hasResources && (
                                    <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md text-[11px] font-semibold">
                                      <Paperclip className="w-3 h-3" />
                                      {lesson.resources!.length} materiales adjuntos ({lesson.resources!.map(r => r.type.toUpperCase()).join(', ')})
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 sm:self-center self-end">
                              <button
                                onClick={() => {
                                  setEditingLesson(lesson);
                                  setLessonModalModuleId(mod.id);
                                  setIsLessonModalOpen(true);
                                }}
                                className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-lg text-xs flex items-center gap-1 transition"
                                title="Editar lección, cambiar tipo, adjuntar PDFs, diapositivas y enlaces"
                              >
                                <Edit2 className="w-3 h-3" />
                                <span>Editar Lección & Materiales</span>
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`¿Eliminar la lección "${lesson.title}"?`)) {
                                    deleteLesson(lesson.id);
                                  }
                                }}
                                className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition"
                                title="Eliminar lección"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        );
                      })}

                      {modLessons.length === 0 && (
                        <div className="p-6 text-center text-xs text-slate-400">
                          No hay lecciones creadas en este módulo aún. Haz clic en <strong>+ Lección</strong> para agregar contenido didáctico.
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {activeCourseModules.length === 0 && (
                <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
                  <Layers className="w-10 h-10 text-slate-300 mx-auto" />
                  <h4 className="font-bold text-slate-800 text-sm">Este curso aún no tiene módulos</h4>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Organiza el plan de estudios creando módulos pedagógicos para luego añadir lecciones, videos, PDFs y tareas.
                  </p>
                  <button
                    onClick={() => {
                      setEditingModule(null);
                      setIsModuleModalOpen(true);
                    }}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs"
                  >
                    Crear Primer Módulo
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Tasks Management */}
          {courseContentTab === 'tasks' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <CheckSquare className="w-4 h-4 text-amber-600" />
                    <span>Tareas y Asignaciones Prácticas del Curso</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Permiten a los estudiantes subir entregables, informes o código para ser calificados sobre 20 puntos.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setEditingTask(null);
                    setTaskModalModuleId(activeCourseModules[0]?.id || '');
                    setIsTaskModalOpen(true);
                  }}
                  className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-2xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>Nueva Tarea</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeCourseTasks.map(task => {
                  const taskMod = modules.find(m => m.id === task.moduleId);
                  const submissionsCount = taskSubmissions.filter(s => s.taskId === task.id).length;

                  return (
                    <div key={task.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-2xs flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            {taskMod ? taskMod.title : 'General del Curso'}
                          </span>
                          <span className="text-[11px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                            Nota máx: {task.maxScore || 20} pts
                          </span>
                        </div>

                        <h4 className="font-bold text-slate-900 text-sm">
                          {task.title}
                        </h4>

                        <p className="text-xs text-slate-600 whitespace-pre-line line-clamp-3">
                          {task.instructions}
                        </p>

                        {task.attachedFileName && (
                          <div className="flex items-center gap-1.5 text-xs text-blue-700 bg-blue-50 p-2 rounded-lg border border-blue-100">
                            <FileText className="w-3.5 h-3.5 shrink-0" />
                            <span className="font-semibold truncate">Plantilla: {task.attachedFileName}</span>
                          </div>
                        )}
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                        <span className="text-slate-500 text-[11px]">
                          Vence: <strong>{new Date(task.dueDate).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</strong> • {submissionsCount} entregas
                        </span>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingTask(task);
                              setTaskModalModuleId(task.moduleId || '');
                              setIsTaskModalOpen(true);
                            }}
                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg text-xs flex items-center gap-1"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Editar</span>
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`¿Eliminar la tarea "${task.title}"?`)) {
                                deleteTask(task.id);
                              }
                            }}
                            className="p-1 text-slate-400 hover:text-red-600 rounded-lg"
                            title="Eliminar tarea"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {activeCourseTasks.length === 0 && (
                  <div className="col-span-2 bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-2">
                    <CheckSquare className="w-8 h-8 text-slate-300 mx-auto" />
                    <p className="text-xs text-slate-500">
                      No hay tareas registradas en este curso todavía.
                    </p>
                    <button
                      onClick={() => {
                        setEditingTask(null);
                        setTaskModalModuleId(activeCourseModules[0]?.id || '');
                        setIsTaskModalOpen(true);
                      }}
                      className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs"
                    >
                      + Crear Primera Tarea
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: Quizzes & Evaluations Management */}
          {courseContentTab === 'quizzes' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-purple-600" />
                    <span>Exámenes y Cuestionarios en Línea</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Evaluaciones objetivas de selección múltiple con calificación automatizada inmediata.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setEditingQuiz(null);
                    setQuizModalModuleId(activeCourseModules[0]?.id || '');
                    setIsQuizModalOpen(true);
                  }}
                  className="px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-2xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>Nuevo Examen</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeCourseQuizzes.map(quiz => {
                  const quizMod = modules.find(m => m.id === quiz.moduleId);

                  return (
                    <div key={quiz.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-2xs flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800">
                            {quizMod ? quizMod.title : 'Evaluación General'}
                          </span>
                          <span className="text-[11px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                            Mín. {quiz.passingScore} pts
                          </span>
                        </div>

                        <h4 className="font-bold text-slate-900 text-sm">
                          {quiz.title}
                        </h4>

                        <p className="text-xs text-slate-600 line-clamp-2">
                          {quiz.description}
                        </p>

                        <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs space-y-1">
                          <div className="flex items-center justify-between text-slate-600 text-[11px]">
                            <span>Preguntas configuradas:</span>
                            <strong className="text-slate-800">{quiz.questions.length}</strong>
                          </div>
                          <div className="flex items-center justify-between text-slate-600 text-[11px]">
                            <span>Tiempo límite asignado:</span>
                            <strong className="text-slate-800">{quiz.timeLimitMinutes} minutos</strong>
                          </div>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                        <span className="text-[11px] text-slate-500">
                          {quiz.questions.length} preguntas formuladas
                        </span>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingQuiz(quiz);
                              setQuizModalModuleId(quiz.moduleId || '');
                              setIsQuizModalOpen(true);
                            }}
                            className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 font-semibold rounded-lg text-xs flex items-center gap-1"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Editar</span>
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`¿Eliminar el examen "${quiz.title}"?`)) {
                                deleteQuiz(quiz.id);
                              }
                            }}
                            className="p-1 text-slate-400 hover:text-red-600 rounded-lg"
                            title="Eliminar examen"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {activeCourseQuizzes.length === 0 && (
                  <div className="col-span-2 bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-2">
                    <HelpCircle className="w-8 h-8 text-slate-300 mx-auto" />
                    <p className="text-xs text-slate-500">
                      No hay exámenes o evaluaciones registradas para este curso todavía.
                    </p>
                    <button
                      onClick={() => {
                        setEditingQuiz(null);
                        setQuizModalModuleId(activeCourseModules[0]?.id || '');
                        setIsQuizModalOpen(true);
                      }}
                      className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs"
                    >
                      + Crear Primer Examen
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Subtab: Grading Submissions */}
      {activeSubTab === 'grading' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Bandeja de Calificación y Retroalimentación de Tareas
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Revisa los archivos enviados por los estudiantes, asigna puntaje sobre 20 y brinda observaciones pedagógicas.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Estudiante</th>
                    <th className="px-4 py-3">Curso / Tarea</th>
                    <th className="px-4 py-3">Fecha de Entrega</th>
                    <th className="px-4 py-3">Archivo / Comentarios</th>
                    <th className="px-4 py-3">Estado / Nota</th>
                    <th className="px-4 py-3 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {mySubmissions.map(sub => {
                    const student = users.find(u => u.id === sub.studentId);
                    const task = tasks.find(t => t.id === sub.taskId);
                    const course = courses.find(c => c.id === sub.courseId);

                    return (
                      <tr key={sub.id} className="hover:bg-slate-50/70 transition">
                        <td className="px-4 py-3 font-semibold text-slate-900">
                          <div className="flex items-center gap-2">
                            {student && (
                              <img src={student.avatar} alt={student.name} className="w-6 h-6 rounded-full object-cover" />
                            )}
                            <div>
                              <div>{student?.name || 'Estudiante'}</div>
                              <div className="text-[10px] text-slate-400">{student?.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-800">{task?.title}</div>
                          <div className="text-[10px] text-blue-600">{course?.title}</div>
                        </td>
                        <td className="px-4 py-3 text-slate-500">
                          {new Date(sub.submittedAt).toLocaleDateString('es-ES', {
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </td>
                        <td className="px-4 py-3 max-w-xs">
                          {sub.fileName && (
                            <span className="inline-flex items-center gap-1 font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded text-[11px]">
                              <FileText className="w-3 h-3" />
                              {sub.fileName}
                            </span>
                          )}
                          <p className="text-[11px] text-slate-600 line-clamp-1 mt-0.5 italic">
                            "{sub.comments}"
                          </p>
                        </td>
                        <td className="px-4 py-3">
                          {sub.status === 'graded' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 text-[11px]">
                              <CheckCircle2 className="w-3 h-3" />
                              Nota: {sub.score} / {task?.maxScore || 20}
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full font-bold bg-amber-100 text-amber-800 text-[11px]">
                              Pendiente de Revisión
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => {
                              setGradingSubmission(sub);
                              setGradeScore(sub.score || 18);
                              setGradeFeedback(sub.feedback || '');
                            }}
                            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition"
                          >
                            {sub.status === 'graded' ? 'Modificar Nota' : 'Calificar Tarea'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {mySubmissions.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        No hay entregas pendientes en tus cursos asignados.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Subtab: Scheduled Zoom Sessions */}
      {activeSubTab === 'zoom' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Programación de Clases Virtuales (Zoom)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Crea enlaces de reunión sincrónica vinculados directamente al aula virtual del estudiante.
              </p>
            </div>
            <button
              onClick={() => setShowZoomModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 transition shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Agendar Nueva Sesión Zoom</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {zoomSessions.filter(z => myCourseIds.includes(z.courseId)).map(session => {
              const course = courses.find(c => c.id === session.courseId);

              return (
                <div key={session.id} className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-2xs">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">
                        {course?.title}
                      </span>
                      <h3 className="font-bold text-slate-900 text-base mt-0.5">
                        {session.title}
                      </h3>
                    </div>
                    <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-full">
                      Programada
                    </span>
                  </div>

                  <p className="text-xs text-slate-600">
                    {session.description}
                  </p>

                  <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Fecha:</span>
                      <span className="font-bold text-slate-800">{session.date}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Hora:</span>
                      <span className="font-bold text-slate-800">{session.startTime}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">ID:</span>
                      <span className="font-mono font-bold text-slate-800 text-[11px]">{session.meetingId}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-2">
                    <a
                      href={session.zoomLink}
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition"
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>Iniciar como Anfitrión</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Subtab: Students Progress Monitoring */}
      {activeSubTab === 'students' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Seguimiento del Avance de los Estudiantes
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Consulta en tiempo real el porcentaje de avance, lecciones completadas y calificaciones obtenidas por cada alumno.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Estudiante</th>
                    <th className="px-4 py-3">Curso Matriculado</th>
                    <th className="px-4 py-3">Progreso de Lecciones</th>
                    <th className="px-4 py-3">% de Avance</th>
                    <th className="px-4 py-3">Estado Académico</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {enrollments.filter(e => myCourseIds.includes(e.courseId)).map(enr => {
                    const student = users.find(u => u.id === enr.studentId);
                    const course = courses.find(c => c.id === enr.courseId);
                    const progress = getCourseProgress(enr.courseId, enr.studentId);

                    return (
                      <tr key={enr.id} className="hover:bg-slate-50/60">
                        <td className="px-4 py-3 font-semibold text-slate-900">
                          <div className="flex items-center gap-2">
                            {student && (
                              <img src={student.avatar} alt={student.name} className="w-7 h-7 rounded-full object-cover" />
                            )}
                            <div>
                              <div>{student?.name}</div>
                              <div className="text-[10px] text-slate-400">{student?.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-700">
                          {course?.title}
                        </td>
                        <td className="px-4 py-3 text-slate-600">
                          {progress.completedLessons} de {progress.totalLessons} lecciones
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 w-8">{progress.percent}%</span>
                            <div className="w-24 bg-slate-100 h-2 rounded-full overflow-hidden">
                              <div
                                className={`h-2 rounded-full ${progress.percent >= 100 ? 'bg-emerald-500' : 'bg-blue-600'}`}
                                style={{ width: `${progress.percent}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          {progress.isCompleted ? (
                            <span className="px-2.5 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 text-[10px]">
                              Graduado / Certificado
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full font-bold bg-blue-100 text-blue-800 text-[10px]">
                              En Curso
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Grading Modal */}
      {gradingSubmission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900">
              Calificar Entrega de Tarea
            </h3>
            <p className="text-xs text-slate-500">
              Registra la nota y feedback formativo para el estudiante.
            </p>

            <form onSubmit={handleSaveGrade} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nota Asignada (0 a 20 puntos):
                </label>
                <input
                  type="number"
                  min="0"
                  max="20"
                  value={gradeScore}
                  onChange={e => setGradeScore(Number(e.target.value))}
                  required
                  className="w-full text-sm font-bold p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Observaciones y Retroalimentación Pedagógica:
                </label>
                <textarea
                  rows={4}
                  value={gradeFeedback}
                  onChange={e => setGradeFeedback(e.target.value)}
                  placeholder="Excelente análisis de requisitos, se recomienda profundizar en..."
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setGradingSubmission(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm"
                >
                  Guardar Calificación
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Course Modal */}
      <EditCourseModal
        course={editingCourse}
        isOpen={!!editingCourse}
        onClose={() => setEditingCourse(null)}
      />

      {/* Module Modal (Create & Edit) */}
      {activeCourse && (
        <ModuleModal
          courseId={activeCourse.id}
          module={editingModule}
          isOpen={isModuleModalOpen}
          onClose={() => {
            setIsModuleModalOpen(false);
            setEditingModule(null);
          }}
        />
      )}

      {/* Lesson Modal (Create & Edit with rich didactic materials) */}
      {activeCourse && (
        <LessonModal
          courseId={activeCourse.id}
          moduleId={lessonModalModuleId || (activeCourseModules[0]?.id || '')}
          lesson={editingLesson}
          isOpen={isLessonModalOpen}
          onClose={() => {
            setIsLessonModalOpen(false);
            setEditingLesson(null);
          }}
        />
      )}

      {/* Task Modal (Create & Edit with file attachments) */}
      {activeCourse && (
        <TaskModal
          courseId={activeCourse.id}
          defaultModuleId={taskModalModuleId || (activeCourseModules[0]?.id || '')}
          task={editingTask}
          isOpen={isTaskModalOpen}
          onClose={() => {
            setIsTaskModalOpen(false);
            setEditingTask(null);
          }}
        />
      )}

      {/* Quiz Modal (Create & Edit with question builder) */}
      {activeCourse && (
        <QuizModal
          courseId={activeCourse.id}
          defaultModuleId={quizModalModuleId || (activeCourseModules[0]?.id || '')}
          quiz={editingQuiz}
          isOpen={isQuizModalOpen}
          onClose={() => {
            setIsQuizModalOpen(false);
            setEditingQuiz(null);
          }}
        />
      )}

      {/* New Zoom Modal */}
      {showZoomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Video className="w-4 h-4 text-emerald-600" />
                <span>Programar Clase Virtual en Zoom</span>
              </h3>
              <button
                onClick={() => setShowZoomModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-500">
              Crea una sesión sincrónica de Zoom para el curso <strong>{activeCourse?.title}</strong>.
            </p>
            <form onSubmit={handleCreateZoom} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Título de la Sesión:</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Clase Magistral: Taller en Vivo de Análisis de Datos"
                  value={newZoomTitle}
                  onChange={e => setNewZoomTitle(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Fecha:</label>
                  <input
                    type="date"
                    required
                    value={newZoomDate}
                    onChange={e => setNewZoomDate(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Hora Inicio:</label>
                  <input
                    type="time"
                    required
                    value={newZoomTime}
                    onChange={e => setNewZoomTime(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Minutos:</label>
                  <input
                    type="number"
                    value={newZoomDuration}
                    onChange={e => setNewZoomDuration(Number(e.target.value))}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Enlace de Zoom Directo:</label>
                <input
                  type="url"
                  required
                  value={newZoomLink}
                  onChange={e => setNewZoomLink(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">ID de Reunión:</label>
                  <input
                    type="text"
                    value={newZoomId}
                    onChange={e => setNewZoomId(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Contraseña:</label>
                  <input
                    type="text"
                    value={newZoomPasscode}
                    onChange={e => setNewZoomPasscode(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowZoomModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm"
                >
                  Agendar Sesión Zoom
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
