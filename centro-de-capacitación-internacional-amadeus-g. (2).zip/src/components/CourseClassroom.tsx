import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Circle,
  Play,
  FileText,
  Video,
  CheckSquare,
  HelpCircle,
  Download,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Award,
  Clock,
  Send,
  Upload,
  Calendar,
  AlertCircle,
  Sparkles,
  RefreshCw,
  Eye
} from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';
import { Course, Lesson, Task, Quiz, ZoomSession } from '../types';

interface CourseClassroomProps {
  courseId: string;
  onBack: () => void;
  onOpenZoomModal?: (session: ZoomSession) => void;
}

export const CourseClassroom: React.FC<CourseClassroomProps> = ({
  courseId,
  onBack,
  onOpenZoomModal
}) => {
  const {
    courses,
    modules,
    lessons,
    tasks,
    taskSubmissions,
    quizzes,
    quizAttempts,
    zoomSessions,
    currentUser,
    users,
    enrollments,
    toggleLessonCompletion,
    submitTask,
    submitQuizAttempt,
    getCourseProgress,
    getCertificateForCourse,
    setActiveCertificateModal
  } = usePlatform();

  const course = courses.find(c => c.id === courseId);
  const instructor = users.find(u => u.id === course?.instructorId);
  const courseModules = modules.filter(m => m.courseId === courseId).sort((a, b) => a.order - b.order);
  const courseLessons = lessons.filter(l => l.courseId === courseId).sort((a, b) => a.order - b.order);

  // Active lesson state
  const [selectedLessonId, setSelectedLessonId] = useState<string>(() => {
    return courseLessons.length > 0 ? courseLessons[0].id : '';
  });

  // Task submission form state
  const [taskComments, setTaskComments] = useState('');
  const [taskFileName, setTaskFileName] = useState('');
  const [taskFileUploading, setTaskFileUploading] = useState(false);
  const [taskSuccessMsg, setTaskSuccessMsg] = useState(false);

  // Quiz state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [currentAttemptResult, setCurrentAttemptResult] = useState<any>(null);

  if (!course) {
    return (
      <div className="p-8 text-center">
        <p className="text-slate-500">Curso no encontrado.</p>
        <button onClick={onBack} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg">
          Volver
        </button>
      </div>
    );
  }

  const activeLesson = courseLessons.find(l => l.id === selectedLessonId) || courseLessons[0];
  const activeModule = courseModules.find(m => m.id === activeLesson?.moduleId);

  const enrollment = enrollments.find(e => e.studentId === currentUser.id && e.courseId === courseId);
  const completedLessonIds = enrollment?.completedLessonIds || [];
  const isLessonCompleted = activeLesson ? completedLessonIds.includes(activeLesson.id) : false;

  const progress = getCourseProgress(courseId, currentUser.id);
  const certificate = getCertificateForCourse(courseId, currentUser.id);

  // Linked items
  const linkedTask: Task | undefined = activeLesson?.linkedTaskId
    ? tasks.find(t => t.id === activeLesson.linkedTaskId)
    : tasks.find(t => t.lessonId === activeLesson?.id);

  const studentTaskSubmission = linkedTask
    ? taskSubmissions.find(s => s.taskId === linkedTask.id && s.studentId === currentUser.id)
    : undefined;

  const linkedQuiz: Quiz | undefined = activeLesson?.linkedQuizId
    ? quizzes.find(q => q.id === activeLesson.linkedQuizId)
    : quizzes.find(q => q.lessonId === activeLesson?.id);

  const studentQuizAttempt = linkedQuiz
    ? quizAttempts.find(a => a.quizId === linkedQuiz.id && a.studentId === currentUser.id)
    : undefined;

  const linkedZoom: ZoomSession | undefined = activeLesson?.linkedZoomId
    ? zoomSessions.find(z => z.id === activeLesson.linkedZoomId)
    : undefined;

  // Handle lesson navigation
  const currentIndex = courseLessons.findIndex(l => l.id === activeLesson?.id);
  const prevLesson = currentIndex > 0 ? courseLessons[currentIndex - 1] : null;
  const nextLesson = currentIndex < courseLessons.length - 1 ? courseLessons[currentIndex + 1] : null;

  const handleSimulatedFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setTaskFileUploading(true);
      setTimeout(() => {
        setTaskFileName(file.name);
        setTaskFileUploading(false);
      }, 600);
    }
  };

  const handleTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!linkedTask) return;
    if (!taskComments.trim() && !taskFileName) {
      alert('Por favor agrega un comentario o adjunta un archivo para tu entrega.');
      return;
    }

    submitTask(linkedTask.id, taskComments, taskFileName || 'Entrega_Trabajo_Final.pdf');
    setTaskSuccessMsg(true);
    setTimeout(() => setTaskSuccessMsg(false), 3000);
  };

  const handleQuizSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!linkedQuiz) return;

    // Check if all answered
    const unanswered = linkedQuiz.questions.some(q => selectedAnswers[q.id] === undefined);
    if (unanswered) {
      if (!confirm('Aún tienes preguntas sin responder. ¿Deseas enviar el examen de todas formas?')) {
        return;
      }
    }

    const result = submitQuizAttempt(linkedQuiz.id, selectedAnswers);
    setCurrentAttemptResult(result);
    setQuizSubmitted(true);
  };

  const getLessonIcon = (type: Lesson['type'], isCompleted: boolean) => {
    if (isCompleted) {
      return <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />;
    }
    switch (type) {
      case 'video':
        return <Play className="w-4 h-4 text-blue-500 flex-shrink-0" />;
      case 'document':
        return <FileText className="w-4 h-4 text-slate-500 flex-shrink-0" />;
      case 'zoom':
        return <Video className="w-4 h-4 text-indigo-500 flex-shrink-0" />;
      case 'task':
        return <CheckSquare className="w-4 h-4 text-amber-500 flex-shrink-0" />;
      case 'quiz':
        return <HelpCircle className="w-4 h-4 text-purple-500 flex-shrink-0" />;
      default:
        return <Circle className="w-4 h-4 text-slate-300 flex-shrink-0" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Aula Virtual Header */}
      <div className="bg-slate-900 text-white border-b border-slate-800 px-4 sm:px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 hover:text-white transition flex items-center gap-1 text-xs"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Volver a Mis Cursos</span>
            </button>
            <div className="border-l border-slate-700 pl-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-400 block">
                Aula Virtual Oficial
              </span>
              <h1 className="text-base sm:text-lg font-bold text-white leading-tight">
                {course.title}
              </h1>
            </div>
          </div>

          {/* Progress Indicator & Certificate Trigger */}
          <div className="flex items-center gap-4 bg-slate-800/80 px-4 py-2 rounded-xl border border-slate-700">
            <div className="text-right">
              <div className="flex items-center gap-1.5 justify-end">
                <span className="text-xs text-slate-300">Progreso:</span>
                <span className="text-xs font-bold text-white">{progress.percent}%</span>
              </div>
              <div className="w-28 sm:w-36 bg-slate-700 rounded-full h-2 mt-1 overflow-hidden">
                <div
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${progress.percent}%` }}
                ></div>
              </div>
            </div>

            {certificate ? (
              <button
                onClick={() => setActiveCertificateModal(certificate)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-lg text-xs shadow-md transition animate-pulse"
              >
                <Award className="w-4 h-4" />
                <span>Ver Certificado</span>
              </button>
            ) : progress.percent >= 100 ? (
              <div className="flex items-center gap-1 text-xs text-emerald-400 font-semibold">
                <Sparkles className="w-4 h-4" />
                <span>¡Curso Completado!</span>
              </div>
            ) : (
              <span className="text-[11px] text-slate-400">
                {progress.completedLessons}/{progress.totalLessons} lecciones
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Classroom Layout */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 flex-1 flex flex-col lg:flex-row gap-6">
        {/* Left Sidebar: Syllabus / Modules & Lessons Tree */}
        <aside className="w-full lg:w-80 flex-shrink-0 bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden flex flex-col h-auto lg:h-[calc(100vh-140px)]">
          <div className="p-4 bg-slate-50 border-b border-slate-200">
            <h2 className="font-bold text-slate-900 text-sm flex items-center justify-between">
              <span>Contenido del Programa</span>
              <span className="text-xs font-normal text-slate-500">
                {courseLessons.length} lecciones
              </span>
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Docente: {instructor ? instructor.name : 'Docente Asignado'}
            </p>
          </div>

          <div className="overflow-y-auto flex-1 p-3 space-y-4">
            {courseModules.map((mod, modIdx) => {
              const modLessons = courseLessons.filter(l => l.moduleId === mod.id);
              const modCompleted = modLessons.filter(l => completedLessonIds.includes(l.id)).length;

              return (
                <div key={mod.id} className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/50">
                  <div className="px-3 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">
                        Módulo {modIdx + 1}
                      </span>
                      <h3 className="text-xs font-bold text-slate-800 leading-snug line-clamp-1">
                        {mod.title.replace(/^Módulo \d+:\s*/, '')}
                      </h3>
                    </div>
                    <span className="text-[10px] bg-white px-2 py-0.5 rounded-full text-slate-600 font-semibold border border-slate-200">
                      {modCompleted}/{modLessons.length}
                    </span>
                  </div>

                  <div className="divide-y divide-slate-100">
                    {modLessons.map(lesson => {
                      const completed = completedLessonIds.includes(lesson.id);
                      const isSelected = lesson.id === activeLesson?.id;

                      return (
                        <button
                          key={lesson.id}
                          onClick={() => {
                            setSelectedLessonId(lesson.id);
                            setQuizSubmitted(false);
                            setCurrentAttemptResult(null);
                          }}
                          className={`w-full text-left px-3 py-2.5 flex items-start gap-2.5 transition text-xs ${
                            isSelected
                              ? 'bg-blue-50/90 text-blue-900 font-semibold border-l-4 border-blue-600'
                              : 'hover:bg-white text-slate-700'
                          }`}
                        >
                          <div className="mt-0.5">
                            {getLessonIcon(lesson.type, completed)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={`line-clamp-2 leading-tight ${isSelected ? 'font-bold' : ''}`}>
                              {lesson.title}
                            </p>
                            <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-500">
                              <span className="flex items-center gap-0.5">
                                <Clock className="w-3 h-3 text-slate-400" />
                                {lesson.durationMinutes} min
                              </span>
                              <span className="capitalize text-slate-500">
                                • {lesson.type === 'video' ? 'Video' : lesson.type === 'document' ? 'Lectura' : lesson.type === 'zoom' ? 'Clase Zoom' : lesson.type === 'task' ? 'Tarea' : 'Examen'}
                              </span>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </aside>

        {/* Right Stage: Active Lesson Content */}
        <main className="flex-1 flex flex-col min-w-0">
          {activeLesson ? (
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden flex flex-col flex-1">
              {/* Lesson Top Banner */}
              <div className="p-6 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800">
                      {activeModule?.title || 'Contenido Principal'}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {activeLesson.durationMinutes} minutos
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                    {activeLesson.title}
                  </h2>
                </div>

                {/* Mark as Completed Toggle Button */}
                <button
                  onClick={() => toggleLessonCompletion(activeLesson.id, courseId)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shadow-xs ${
                    isLessonCompleted
                      ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border border-emerald-300'
                      : 'bg-blue-600 hover:bg-blue-700 text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isLessonCompleted ? 'Lección Completada' : 'Marcar como Completada'}</span>
                </button>
              </div>

              {/* Dynamic Lesson Body */}
              <div className="p-6 flex-1 space-y-6">
                {/* 1. Video Lesson Type */}
                {activeLesson.type === 'video' && (
                  <div className="space-y-4">
                    <div className="aspect-video w-full rounded-xl overflow-hidden bg-slate-950 shadow-md">
                      {activeLesson.videoUrl?.includes('youtube.com') || activeLesson.videoUrl?.includes('youtu.be') ? (
                        <iframe
                          src={activeLesson.videoUrl}
                          title={activeLesson.title}
                          className="w-full h-full border-0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        ></iframe>
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center">
                          <Play className="w-16 h-16 text-blue-500 mb-3 animate-pulse" />
                          <p className="text-sm font-medium text-white">Reproductor de Video de Capacitación</p>
                          <p className="text-xs text-slate-400 mt-1 max-w-md">
                            Video streaming interactivo de alta definición alojado en el servidor del aula.
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Resumen de la Sesión
                      </h4>
                      <p className="text-sm text-slate-700 leading-relaxed">
                        {activeLesson.description}
                      </p>
                    </div>
                  </div>
                )}

                {/* 2. Document Lesson Type */}
                {activeLesson.type === 'document' && (
                  <div className="space-y-6">
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 prose prose-slate max-w-none">
                      <div className="whitespace-pre-line text-sm text-slate-800 leading-relaxed font-sans">
                        {activeLesson.documentContent || activeLesson.description}
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. Zoom Live Class Session */}
                {activeLesson.type === 'zoom' && (
                  <div className="bg-gradient-to-br from-indigo-900 via-blue-900 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-lg space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-indigo-700/50 pb-6">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center shadow-lg">
                          <Video className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <span className="text-[11px] font-bold text-blue-300 uppercase tracking-wider">
                            Videoconferencia Zoom Oficial
                          </span>
                          <h3 className="text-lg font-bold text-white">
                            {linkedZoom?.title || 'Clase Sincrónica en Directo'}
                          </h3>
                        </div>
                      </div>

                      <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                        Sesión Programada
                      </span>
                    </div>

                    <p className="text-sm text-slate-200 leading-relaxed">
                      {linkedZoom?.description || activeLesson.description}
                    </p>

                    {linkedZoom && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/10 text-xs">
                        <div>
                          <span className="text-slate-400 block mb-0.5">Fecha y Hora:</span>
                          <span className="font-bold text-white">
                            {linkedZoom.date} a las {linkedZoom.startTime} hrs
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block mb-0.5">ID de la Reunión:</span>
                          <code className="font-mono bg-black/30 px-2 py-0.5 rounded text-white font-bold">
                            {linkedZoom.meetingId}
                          </code>
                        </div>
                        <div>
                          <span className="text-slate-400 block mb-0.5">Código de Acceso:</span>
                          <code className="font-mono bg-black/30 px-2 py-0.5 rounded text-white font-bold">
                            {linkedZoom.passcode}
                          </code>
                        </div>
                      </div>
                    )}

                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <a
                        href={linkedZoom?.zoomLink || 'https://zoom.us'}
                        target="_blank"
                        rel="noreferrer"
                        className="px-5 py-2.5 bg-blue-500 hover:bg-blue-400 text-white font-bold rounded-xl text-sm transition shadow-lg flex items-center gap-2"
                      >
                        <Video className="w-4 h-4" />
                        Unirse a la Clase en Zoom
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>

                      {onOpenZoomModal && linkedZoom && (
                        <button
                          onClick={() => onOpenZoomModal(linkedZoom)}
                          className="px-4 py-2.5 bg-white/15 hover:bg-white/25 text-white font-semibold rounded-xl text-sm transition border border-white/20 flex items-center gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          Simular Sala de Clase
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 4. Practical Task Assignment */}
                {activeLesson.type === 'task' && linkedTask && (
                  <div className="space-y-6">
                    {/* Task Overview */}
                    <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-6">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200 pb-3 mb-4">
                        <div className="flex items-center gap-2">
                          <CheckSquare className="w-5 h-5 text-amber-700" />
                          <h3 className="font-bold text-amber-950 text-base">
                            {linkedTask.title}
                          </h3>
                        </div>
                        <div className="flex items-center gap-3 text-xs">
                          <span className="bg-amber-200/80 text-amber-900 font-bold px-2.5 py-0.5 rounded-full">
                            Puntaje Máximo: {linkedTask.maxScore} pts
                          </span>
                          <span className="text-slate-600 font-medium">
                            Entrega hasta: {new Date(linkedTask.dueDate).toLocaleDateString('es-ES')}
                          </span>
                        </div>
                      </div>

                      <div className="whitespace-pre-line text-sm text-slate-800 leading-relaxed font-sans mb-4">
                        {linkedTask.instructions}
                      </div>

                      {linkedTask.attachedFileName && (
                        <div className="mt-4 pt-3 border-t border-amber-200/80 flex items-center justify-between">
                          <div className="flex items-center gap-2 text-xs text-amber-900">
                            <FileText className="w-4 h-4 text-amber-700" />
                            <span className="font-medium">Material Guía: {linkedTask.attachedFileName}</span>
                          </div>
                          <button
                            onClick={() => alert(`Descargando plantilla adjunta: ${linkedTask.attachedFileName}`)}
                            className="text-xs font-semibold text-blue-700 hover:text-blue-900 flex items-center gap-1"
                          >
                            <Download className="w-3.5 h-3.5" />
                            Descargar Plantilla
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Student Delivery Status / Form */}
                    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                      <h4 className="font-bold text-slate-900 text-sm mb-4 flex items-center justify-between">
                        <span>Estado de Entrega del Estudiante</span>
                        {studentTaskSubmission ? (
                          <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                            studentTaskSubmission.status === 'graded'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {studentTaskSubmission.status === 'graded' ? 'Calificado' : 'Entregado para Revisión'}
                          </span>
                        ) : (
                          <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-amber-100 text-amber-800">
                            Pendiente de Envío
                          </span>
                        )}
                      </h4>

                      {/* If already graded, show grade & feedback */}
                      {studentTaskSubmission?.status === 'graded' && (
                        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-emerald-900 uppercase">
                              Calificación Obtenida
                            </span>
                            <span className="text-lg font-black text-emerald-700">
                              {studentTaskSubmission.score} / {linkedTask.maxScore} pts
                            </span>
                          </div>
                          {studentTaskSubmission.feedback && (
                            <div className="text-xs text-emerald-950 pt-2 border-t border-emerald-200">
                              <span className="font-bold block mb-0.5">Observaciones del Docente:</span>
                              <p className="italic">{studentTaskSubmission.feedback}</p>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Submission form */}
                      <form onSubmit={handleTaskSubmit} className="space-y-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            Comentarios o Enlace del Trabajo (Drive / GitHub / Notion):
                          </label>
                          <textarea
                            rows={3}
                            value={taskComments}
                            onChange={e => setTaskComments(e.target.value)}
                            placeholder={studentTaskSubmission?.comments || 'Escribe aquí tu sustentación, reflexiones o pega el enlace a tu documento...'}
                            className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            Archivo Adjunto de la Tarea (PDF, Word, Zip):
                          </label>
                          <div className="flex items-center gap-3">
                            <label className="cursor-pointer px-4 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-2 transition">
                              <Upload className="w-4 h-4 text-slate-500" />
                              <span>{taskFileUploading ? 'Cargando...' : 'Seleccionar Archivo'}</span>
                              <input
                                type="file"
                                onChange={handleSimulatedFileUpload}
                                className="hidden"
                                accept=".pdf,.doc,.docx,.zip,.rar,.xlsx"
                              />
                            </label>
                            {taskFileName && (
                              <span className="text-xs text-slate-700 font-medium bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200 flex items-center gap-1.5">
                                <FileText className="w-3.5 h-3.5 text-blue-600" />
                                {taskFileName}
                              </span>
                            )}
                            {studentTaskSubmission?.fileName && !taskFileName && (
                              <span className="text-xs text-slate-500">
                                Archivo entregado: {studentTaskSubmission.fileName}
                              </span>
                            )}
                          </div>
                        </div>

                        {taskSuccessMsg && (
                          <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2 animate-fadeIn">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span>¡Tu tarea ha sido enviada con éxito y registrada en el sistema!</span>
                          </div>
                        )}

                        <div className="pt-2 flex items-center justify-end">
                          <button
                            type="submit"
                            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center gap-2 transition shadow-sm"
                          >
                            <Send className="w-4 h-4" />
                            <span>{studentTaskSubmission ? 'Actualizar Entrega' : 'Enviar Tarea'}</span>
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}

                {/* 5. Online Quiz / Examination */}
                {activeLesson.type === 'quiz' && linkedQuiz && (
                  <div className="space-y-6">
                    {/* Quiz Header Card */}
                    <div className="bg-purple-50/70 border border-purple-200 rounded-2xl p-6">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-200 pb-3 mb-3">
                        <div className="flex items-center gap-2.5">
                          <HelpCircle className="w-6 h-6 text-purple-700" />
                          <div>
                            <h3 className="font-bold text-purple-950 text-base leading-tight">
                              {linkedQuiz.title}
                            </h3>
                            <p className="text-xs text-purple-700 mt-0.5">
                              Evaluación Online con Calificación Inmediata
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          <span className="bg-purple-200 text-purple-900 font-bold px-3 py-1 rounded-full">
                            Nota Mínima: {linkedQuiz.passingScore} pts
                          </span>
                          <span className="bg-white border border-purple-200 text-slate-700 font-semibold px-3 py-1 rounded-full flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-purple-600" />
                            {linkedQuiz.timeLimitMinutes} min
                          </span>
                        </div>
                      </div>

                      <p className="text-sm text-slate-700 leading-relaxed">
                        {linkedQuiz.description}
                      </p>
                    </div>

                    {/* Quiz Questions or Result Screen */}
                    {(studentQuizAttempt || quizSubmitted) ? (
                      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6 shadow-xs">
                        {/* Result banner */}
                        {(() => {
                          const result = currentAttemptResult || studentQuizAttempt;
                          if (!result) return null;
                          return (
                            <div className={`p-6 rounded-2xl border text-center space-y-2 ${
                              result.passed
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                                : 'bg-red-50 border-red-200 text-red-950'
                            }`}>
                              <div className="w-12 h-12 mx-auto rounded-full flex items-center justify-center bg-white shadow-sm">
                                {result.passed ? (
                                  <CheckCircle2 className="w-7 h-7 text-emerald-600" />
                                ) : (
                                  <AlertCircle className="w-7 h-7 text-red-600" />
                                )}
                              </div>
                              <h4 className="text-lg font-black">
                                {result.passed ? '¡Felicitaciones! Has Aprobado el Examen' : 'Evaluación No Aprobada'}
                              </h4>
                              <p className="text-sm">
                                Puntaje obtenido: <span className="font-extrabold text-base">{result.score}</span> de {result.maxScore} puntos
                              </p>
                              <div className="pt-2">
                                <button
                                  onClick={() => {
                                    setQuizSubmitted(false);
                                    setCurrentAttemptResult(null);
                                    setSelectedAnswers({});
                                  }}
                                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition"
                                >
                                  <RefreshCw className="w-3.5 h-3.5" />
                                  Rendir Nuevamente
                                </button>
                              </div>
                            </div>
                          );
                        })()}

                        {/* Question by question feedback */}
                        <div className="space-y-4 pt-2">
                          <h5 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                            Revisión de Preguntas y Respuestas:
                          </h5>
                          {linkedQuiz.questions.map((q, qIndex) => {
                            const result = currentAttemptResult || studentQuizAttempt;
                            const studentAns = result?.answers[q.id];
                            const isCorrect = studentAns === q.correctOptionIndex;

                            return (
                              <div
                                key={q.id}
                                className={`p-4 rounded-xl border text-xs space-y-2 ${
                                  isCorrect ? 'bg-emerald-50/50 border-emerald-200' : 'bg-red-50/50 border-red-200'
                                }`}
                              >
                                <div className="flex items-start justify-between gap-2">
                                  <span className="font-bold text-slate-900 text-sm">
                                    {qIndex + 1}. {q.question}
                                  </span>
                                  <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                                    isCorrect ? 'bg-emerald-200 text-emerald-900' : 'bg-red-200 text-red-900'
                                  }`}>
                                    {isCorrect ? `+${q.points} pts` : '0 pts'}
                                  </span>
                                </div>

                                <div className="space-y-1.5 mt-2">
                                  {q.options.map((opt, optIndex) => (
                                    <div
                                      key={optIndex}
                                      className={`p-2 rounded-lg flex items-center justify-between ${
                                        optIndex === q.correctOptionIndex
                                          ? 'bg-emerald-200/70 font-semibold text-emerald-950'
                                          : studentAns === optIndex
                                          ? 'bg-red-200/70 font-medium text-red-950 line-through'
                                          : 'bg-white text-slate-600'
                                      }`}
                                    >
                                      <span>{opt}</span>
                                      {optIndex === q.correctOptionIndex && (
                                        <span className="text-[10px] uppercase font-bold text-emerald-800">
                                          (Correcta)
                                        </span>
                                      )}
                                    </div>
                                  ))}
                                </div>

                                {q.explanation && (
                                  <p className="text-[11px] text-slate-600 bg-white/60 p-2 rounded border border-slate-200 italic mt-1">
                                    <strong>Fundamentación pedagógica:</strong> {q.explanation}
                                  </p>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ) : (
                      <form onSubmit={handleQuizSubmit} className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6 shadow-xs">
                        <div className="space-y-6">
                          {linkedQuiz.questions.map((q, qIndex) => (
                            <div key={q.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                              <div className="flex items-start justify-between gap-3">
                                <span className="font-bold text-slate-900 text-sm leading-snug">
                                  {qIndex + 1}. {q.question}
                                </span>
                                <span className="text-[11px] font-semibold bg-white px-2 py-0.5 rounded text-purple-700 border border-purple-200">
                                  {q.points} pts
                                </span>
                              </div>

                              <div className="space-y-2">
                                {q.options.map((opt, optIdx) => (
                                  <label
                                    key={optIdx}
                                    className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition text-xs ${
                                      selectedAnswers[q.id] === optIdx
                                        ? 'bg-purple-50 border-purple-500 font-semibold text-purple-950 shadow-xs ring-1 ring-purple-400'
                                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                                    }`}
                                  >
                                    <input
                                      type="radio"
                                      name={`question_${q.id}`}
                                      checked={selectedAnswers[q.id] === optIdx}
                                      onChange={() => {
                                        setSelectedAnswers(prev => ({
                                          ...prev,
                                          [q.id]: optIdx
                                        }));
                                      }}
                                      className="text-purple-600 focus:ring-purple-500"
                                    />
                                    <span>{opt}</span>
                                  </label>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="pt-2 flex items-center justify-between">
                          <span className="text-xs text-slate-500">
                            Preguntas respondidas: {Object.keys(selectedAnswers).length} de {linkedQuiz.questions.length}
                          </span>
                          <button
                            type="submit"
                            className="px-6 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs shadow-md transition"
                          >
                            Finalizar y Enviar Examen
                          </button>
                        </div>
                      </form>
                    )}
                  </div>
                )}

                {/* Additional Downloadable Resources */}
                {activeLesson.resources && activeLesson.resources.length > 0 && (
                  <div className="mt-8 pt-6 border-t border-slate-200">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
                      <Download className="w-4 h-4 text-blue-600" />
                      Materiales y Documentos Descargables:
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {activeLesson.resources.map(res => (
                        <div
                          key={res.id}
                          className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs hover:bg-slate-100 transition"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <FileText className="w-4 h-4 text-blue-600 flex-shrink-0" />
                            <div className="truncate">
                              <span className="font-semibold text-slate-800 block truncate">{res.title}</span>
                              <span className="text-[10px] text-slate-500">{res.size || 'Archivo PDF'}</span>
                            </div>
                          </div>
                          <button
                            onClick={() => alert(`Descarga iniciada para: ${res.title}`)}
                            className="px-3 py-1 bg-white hover:bg-blue-50 text-blue-700 border border-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1 shadow-2xs"
                          >
                            <Download className="w-3 h-3" />
                            <span>Descargar</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Classroom Bottom Navigation Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
                <button
                  disabled={!prevLesson}
                  onClick={() => {
                    if (prevLesson) {
                      setSelectedLessonId(prevLesson.id);
                      setQuizSubmitted(false);
                      setCurrentAttemptResult(null);
                    }
                  }}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition ${
                    prevLesson
                      ? 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-300'
                      : 'opacity-40 cursor-not-allowed text-slate-400'
                  }`}
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Lección Anterior</span>
                </button>

                <div className="hidden sm:block text-xs text-slate-500 font-medium">
                  Lección {currentIndex + 1} de {courseLessons.length}
                </div>

                <button
                  disabled={!nextLesson}
                  onClick={() => {
                    if (nextLesson) {
                      setSelectedLessonId(nextLesson.id);
                      setQuizSubmitted(false);
                      setCurrentAttemptResult(null);
                    }
                  }}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
                    nextLesson
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
                      : 'opacity-40 cursor-not-allowed bg-slate-200 text-slate-400'
                  }`}
                >
                  <span>Siguiente Lección</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
              <p className="text-slate-500">Selecciona una lección para comenzar.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
