import React from 'react';
import {
  GraduationCap,
  Users,
  BookOpen,
  Calendar,
  Award,
  Settings,
  RotateCcw,
  CheckSquare,
  Shield,
  FileText,
  Video,
  LogOut,
  UserCheck
} from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';
import { UserRole } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenCatalog: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab, onOpenCatalog }) => {
  const { currentUser, centerSettings, resetAllData, certificates, logout } = usePlatform();

  const myCertificatesCount = certificates.filter(c => c.studentId === currentUser.id).length;

  const handleLogout = () => {
    logout();
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return <span className="bg-purple-100 text-purple-800 text-[11px] font-bold px-2 py-0.5 rounded-full border border-purple-200">ADMINISTRADOR</span>;
      case 'instructor':
        return <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2 py-0.5 rounded-full border border-emerald-200">INSTRUCTOR</span>;
      case 'student':
        return <span className="bg-blue-100 text-blue-800 text-[11px] font-bold px-2 py-0.5 rounded-full border border-blue-200">ESTUDIANTE</span>;
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Banner with Active Role Session & Logout */}
      <div className="bg-slate-900 text-slate-200 px-4 py-1.5 text-xs flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-medium text-slate-300">
            {centerSettings.name}
          </span>
          <span className="hidden md:inline text-slate-500">|</span>
          <span className="hidden md:inline text-slate-400">
            {centerSettings.tagline}
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 text-[11px] hidden sm:inline">Sesión activa:</span>
            <div className="flex items-center gap-1.5 bg-slate-800 px-2 py-1 rounded text-white font-medium text-xs border border-slate-700">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="truncate max-w-[140px] sm:max-w-none">{currentUser.name}</span>
              <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-900/60 px-1.5 py-0.2 rounded">
                {currentUser.role === 'admin' ? 'Admin' : currentUser.role === 'instructor' ? 'Docente' : 'Estudiante'}
              </span>
            </div>
          </div>

          <button
            onClick={handleLogout}
            title="Cerrar sesión de la plataforma"
            className="flex items-center gap-1 text-[11px] text-rose-300 hover:text-white bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 px-2.5 py-1 rounded transition font-medium cursor-pointer"
          >
            <LogOut className="w-3 h-3" />
            <span>Cerrar Sesión</span>
          </button>

          <button
            onClick={() => {
              if (confirm('¿Deseas reiniciar los datos de prueba de la plataforma educativa?')) {
                resetAllData();
              }
            }}
            title="Reiniciar datos de demostración"
            className="hidden sm:flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-1 rounded transition hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reiniciar Demo</span>
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (currentUser.role === 'admin') setCurrentTab('admin_dashboard');
                else if (currentUser.role === 'instructor') setCurrentTab('instructor_courses');
                else setCurrentTab('student_courses');
              }}
              className="flex items-center gap-3 text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <span className="text-lg font-bold text-slate-900 tracking-tight block leading-tight">
                  AMADEUS G. <span className="text-blue-600 font-extrabold">Virtual</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium block truncate max-w-[280px]">
                  {centerSettings.name}
                </span>
              </div>
            </button>
          </div>

          {/* Navigation Links based on Role */}
          <nav className="hidden md:flex items-center gap-1">
            {/* Student Navigation */}
            {currentUser.role === 'student' && (
              <>
                <button
                  onClick={() => setCurrentTab('student_courses')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'student_courses' || currentTab === 'classroom'
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  Mis Cursos
                </button>

                <button
                  onClick={() => setCurrentTab('student_tasks')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'student_tasks'
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <CheckSquare className="w-4 h-4" />
                  Tareas & Exámenes
                </button>

                <button
                  onClick={() => setCurrentTab('student_zoom')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'student_zoom'
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  Clases Zoom
                </button>

                <button
                  onClick={() => setCurrentTab('student_certificates')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'student_certificates'
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Award className="w-4 h-4 text-amber-500" />
                  Mis Certificados
                  {myCertificatesCount > 0 && (
                    <span className="bg-amber-100 text-amber-800 text-xs font-bold px-1.5 py-0.2 rounded-full">
                      {myCertificatesCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={onOpenCatalog}
                  className="ml-2 flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs transition"
                >
                  Explorar Catálogo
                </button>
              </>
            )}

            {/* Instructor Navigation */}
            {currentUser.role === 'instructor' && (
              <>
                <button
                  onClick={() => setCurrentTab('instructor_courses')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'instructor_courses'
                      ? 'bg-emerald-50 text-emerald-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  Mis Cursos Asignados
                </button>

                <button
                  onClick={() => setCurrentTab('instructor_grading')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'instructor_grading'
                      ? 'bg-emerald-50 text-emerald-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <CheckSquare className="w-4 h-4" />
                  Calificar Tareas
                </button>

                <button
                  onClick={() => setCurrentTab('instructor_zoom')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'instructor_zoom'
                      ? 'bg-emerald-50 text-emerald-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  Programar Zoom
                </button>

                <button
                  onClick={() => setCurrentTab('instructor_students')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'instructor_students'
                      ? 'bg-emerald-50 text-emerald-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  Seguimiento de Alumnos
                </button>
              </>
            )}

            {/* Administrator Navigation */}
            {currentUser.role === 'admin' && (
              <>
                <button
                  onClick={() => setCurrentTab('admin_dashboard')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'admin_dashboard'
                      ? 'bg-purple-50 text-purple-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  Panel Central
                </button>

                <button
                  onClick={() => setCurrentTab('admin_courses')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'admin_courses'
                      ? 'bg-purple-50 text-purple-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  Cursos
                </button>

                <button
                  onClick={() => setCurrentTab('admin_users')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'admin_users'
                      ? 'bg-purple-50 text-purple-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  Usuarios & Roles
                </button>

                <button
                  onClick={() => setCurrentTab('admin_enrollments')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'admin_enrollments'
                      ? 'bg-purple-50 text-purple-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  Inscripciones
                </button>

                <button
                  onClick={() => setCurrentTab('admin_certificates')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'admin_certificates'
                      ? 'bg-purple-50 text-purple-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Award className="w-4 h-4 text-amber-600" />
                  Certificados
                </button>

                <button
                  onClick={() => setCurrentTab('admin_settings')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
                    currentTab === 'admin_settings'
                      ? 'bg-purple-50 text-purple-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  Configuración
                </button>
              </>
            )}
          </nav>

          {/* User Profile Mini Card and Logout Action */}
          <div className="flex items-center gap-2.5">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs font-bold text-slate-900 leading-tight">{currentUser.name}</span>
              <div className="mt-0.5">{getRoleBadge(currentUser.role)}</div>
            </div>
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-slate-200"
            />
            <button
              onClick={handleLogout}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 hover:border-rose-300 bg-white hover:bg-rose-50 text-slate-700 hover:text-rose-700 text-xs font-semibold shadow-xs transition cursor-pointer"
              title="Cerrar sesión de la cuenta actual"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-500" />
              <span>Cerrar Sesión</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="md:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-100 text-xs">
          <button
            onClick={handleLogout}
            className="px-2.5 py-1.5 rounded-full whitespace-nowrap bg-rose-50 text-rose-700 border border-rose-200 font-semibold flex items-center gap-1 shrink-0"
          >
            <LogOut className="w-3 h-3 text-rose-600" />
            Salir
          </button>
          {currentUser.role === 'student' && (
            <>
              <button
                onClick={() => setCurrentTab('student_courses')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'student_courses' ? 'bg-blue-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Mis Cursos
              </button>
              <button
                onClick={() => setCurrentTab('student_tasks')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'student_tasks' ? 'bg-blue-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Tareas
              </button>
              <button
                onClick={() => setCurrentTab('student_zoom')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'student_zoom' ? 'bg-blue-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Clases Zoom
              </button>
              <button
                onClick={() => setCurrentTab('student_certificates')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'student_certificates' ? 'bg-amber-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Certificados ({myCertificatesCount})
              </button>
              <button
                onClick={onOpenCatalog}
                className="px-3 py-1.5 rounded-full whitespace-nowrap bg-slate-800 text-white"
              >
                Catálogo
              </button>
            </>
          )}

          {currentUser.role === 'instructor' && (
            <>
              <button
                onClick={() => setCurrentTab('instructor_courses')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'instructor_courses' ? 'bg-emerald-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Cursos
              </button>
              <button
                onClick={() => setCurrentTab('instructor_grading')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'instructor_grading' ? 'bg-emerald-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Calificar
              </button>
              <button
                onClick={() => setCurrentTab('instructor_zoom')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'instructor_zoom' ? 'bg-emerald-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Zoom
              </button>
              <button
                onClick={() => setCurrentTab('instructor_students')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'instructor_students' ? 'bg-emerald-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Alumnos
              </button>
            </>
          )}

          {currentUser.role === 'admin' && (
            <>
              <button
                onClick={() => setCurrentTab('admin_dashboard')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'admin_dashboard' ? 'bg-purple-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Panel
              </button>
              <button
                onClick={() => setCurrentTab('admin_courses')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'admin_courses' ? 'bg-purple-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Cursos
              </button>
              <button
                onClick={() => setCurrentTab('admin_users')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'admin_users' ? 'bg-purple-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Usuarios
              </button>
              <button
                onClick={() => setCurrentTab('admin_enrollments')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'admin_enrollments' ? 'bg-purple-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Inscripciones
              </button>
              <button
                onClick={() => setCurrentTab('admin_certificates')}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap ${currentTab === 'admin_certificates' ? 'bg-purple-600 text-white font-semibold' : 'bg-slate-100 text-slate-700'}`}
              >
                Certificados
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
