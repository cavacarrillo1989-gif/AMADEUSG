import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Filter,
  ShieldCheck,
  GraduationCap,
  BookOpen,
  Edit2,
  Trash2,
  KeyRound,
  CheckCircle2,
  X,
  Eye,
  EyeOff,
  Copy,
  AlertCircle,
  Sparkles,
  BookCheck,
  RefreshCw,
  UserX,
  ExternalLink
} from 'lucide-react';
import { usePlatform } from '../../context/PlatformContext';
import { User, UserRole, Course } from '../../types';

export const AdminUsersManager: React.FC = () => {
  const {
    currentUser,
    users,
    courses,
    enrollments,
    createUser,
    updateUser,
    deleteUser,
    enrollInCourse,
    unenrollCourse
  } = usePlatform();

  // RBAC Security Check
  if (currentUser.role !== 'admin') {
    return (
      <div className="bg-rose-50 border border-rose-200 rounded-2xl p-8 text-center text-rose-800">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h2 className="text-xl font-bold">Acceso Denegado (RBAC)</h2>
        <p className="text-sm mt-1 text-rose-600">
          Este módulo de Gestión de Usuarios y Matrículas está reservado exclusivamente para la Dirección y Administradores de la plataforma.
        </p>
      </div>
    );
  }

  // State: Filter and Search
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  // State: Create User Modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formRole, setFormRole] = useState<'student' | 'instructor' | 'admin'>('student');
  const [formTitle, setFormTitle] = useState('');
  const [selectedCourseIds, setSelectedCourseIds] = useState<string[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [createSuccessModal, setCreateSuccessModal] = useState<{
    user: User;
    assignedCourses: string[];
  } | null>(null);

  // State: Edit User Modal
  const [userToEdit, setUserToEdit] = useState<User | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('student');

  // State: Reset Password Modal
  const [userToResetPassword, setUserToResetPassword] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);

  // Helper to copy to clipboard
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopyFeedback(`${label} copiado al portapapeles`);
    setTimeout(() => setCopyFeedback(null), 2500);
  };

  // Helper to generate username automatically from name or email
  const handleAutoGenerateUsername = (name: string, email: string) => {
    if (name.trim()) {
      const parts = name.trim().toLowerCase().split(/\s+/);
      if (parts.length >= 2) {
        return `${parts[0]}.${parts[1].replace(/[^a-z0-9]/g, '')}`;
      }
      return parts[0].replace(/[^a-z0-9]/g, '');
    }
    if (email.trim()) {
      return email.split('@')[0].toLowerCase().replace(/[^a-z0-9._-]/g, '');
    }
    return '';
  };

  // Helper to generate a random secure password
  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#';
    let res = '';
    for (let i = 0; i < 9; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
  };

  // Open Create Modal and set sensible defaults
  const handleOpenCreateModal = () => {
    setFormName('');
    setFormEmail('');
    setFormUsername('');
    setFormPassword('educacion' + Math.floor(100 + Math.random() * 900));
    setFormRole('student');
    setFormTitle('Estudiante Regular');
    setSelectedCourseIds([]);
    setShowPassword(false);
    setShowCreateModal(true);
  };

  // Handle Create User Submit
  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanName = formName.trim();
    const cleanEmail = formEmail.trim().toLowerCase();
    const cleanUsername = formUsername.trim().toLowerCase() || handleAutoGenerateUsername(cleanName, cleanEmail);
    const cleanPassword = formPassword.trim();

    if (!cleanName || !cleanEmail || !cleanPassword) {
      alert('Por favor completa los campos obligatorios.');
      return;
    }

    // Check duplicate email or username
    const emailExists = users.some(u => u.email.toLowerCase() === cleanEmail);
    if (emailExists) {
      alert(`El correo electrónico ${cleanEmail} ya se encuentra registrado en el sistema.`);
      return;
    }

    const usernameExists = users.some(u => u.username?.toLowerCase() === cleanUsername);
    if (usernameExists) {
      alert(`El nombre de usuario "${cleanUsername}" ya está en uso. Por favor elige otro.`);
      return;
    }

    // Select default avatar according to role
    let defaultAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';
    if (formRole === 'instructor') {
      defaultAvatar = 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80';
    } else if (formRole === 'admin') {
      defaultAvatar = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80';
    }

    const newUser = createUser({
      name: cleanName,
      email: cleanEmail,
      username: cleanUsername,
      password: cleanPassword,
      role: formRole,
      avatar: defaultAvatar,
      title: formTitle.trim() || (formRole === 'student' ? 'Estudiante' : formRole === 'instructor' ? 'Docente Especialista' : 'Administrador Académico')
    });

    // If student and courses were selected, auto-enroll them immediately
    const assignedTitles: string[] = [];
    if (formRole === 'student' && selectedCourseIds.length > 0) {
      selectedCourseIds.forEach(cId => {
        enrollInCourse(cId, newUser.id);
        const course = courses.find(c => c.id === cId);
        if (course) assignedTitles.push(course.title);
      });
    }

    setShowCreateModal(false);
    setCreateSuccessModal({
      user: newUser,
      assignedCourses: assignedTitles
    });
  };

  // Open Edit User Modal
  const handleOpenEditModal = (u: User) => {
    setUserToEdit(u);
    setEditName(u.name);
    setEditEmail(u.email);
    setEditUsername(u.username || u.email.split('@')[0]);
    setEditTitle(u.title || '');
    setEditRole(u.role);
  };

  // Handle Edit User Submit
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userToEdit) return;

    const cleanName = editName.trim();
    const cleanEmail = editEmail.trim().toLowerCase();
    const cleanUsername = editUsername.trim().toLowerCase();

    if (!cleanName || !cleanEmail || !cleanUsername) {
      alert('Por favor completa todos los campos requeridos.');
      return;
    }

    // Check duplicate email
    const duplicateEmail = users.some(u => u.id !== userToEdit.id && u.email.toLowerCase() === cleanEmail);
    if (duplicateEmail) {
      alert('Este correo electrónico ya pertenece a otro usuario.');
      return;
    }

    // Check duplicate username
    const duplicateUsername = users.some(u => u.id !== userToEdit.id && u.username?.toLowerCase() === cleanUsername);
    if (duplicateUsername) {
      alert('Este nombre de usuario ya pertenece a otro usuario.');
      return;
    }

    updateUser(userToEdit.id, {
      name: cleanName,
      email: cleanEmail,
      username: cleanUsername,
      title: editTitle.trim(),
      role: editRole
    });

    setUserToEdit(null);
    setCopyFeedback('Usuario actualizado satisfactoriamente');
    setTimeout(() => setCopyFeedback(null), 2500);
  };

  // Open Reset Password Modal
  const handleOpenResetPasswordModal = (u: User) => {
    setUserToResetPassword(u);
    setNewPassword(generateRandomPassword());
    setShowResetPassword(false);
    setResetSuccessMessage(null);
  };

  // Handle Reset Password Submit
  const handleResetPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userToResetPassword) return;

    const cleanPass = newPassword.trim();
    if (!cleanPass) {
      alert('La contraseña no puede estar vacía.');
      return;
    }

    updateUser(userToResetPassword.id, {
      password: cleanPass
    });

    setResetSuccessMessage(`Contraseña actualizada con éxito para ${userToResetPassword.name}.`);
  };

  // Handle Delete User
  const handleDeleteUser = (u: User) => {
    if (u.id === currentUser.id) {
      alert('No puedes eliminar tu propio usuario de administrador mientras tengas la sesión activa.');
      return;
    }

    const confirmMsg = `¿Estás seguro de que deseas revocar y eliminar permanentemente el acceso del usuario ${u.name} (${u.email})? Se cancelarán también sus matrículas registradas.`;
    if (window.confirm(confirmMsg)) {
      deleteUser(u.id);
      setCopyFeedback(`Acceso de ${u.name} eliminado exitosamente`);
      setTimeout(() => setCopyFeedback(null), 2500);
    }
  };

  // Filtered Users List
  const filteredUsers = users.filter(u => {
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      (u.username && u.username.toLowerCase().includes(q)) ||
      (u.title && u.title.toLowerCase().includes(q));

    return matchesRole && matchesSearch;
  });

  // Role Counts
  const totalStudents = users.filter(u => u.role === 'student').length;
  const totalInstructors = users.filter(u => u.role === 'instructor').length;
  const totalAdmins = users.filter(u => u.role === 'admin').length;

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {copyFeedback && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs font-medium border border-slate-700 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{copyFeedback}</span>
        </div>
      )}

      {/* Header and Quick Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Gestor Integral de Usuarios y Control RBAC
            </h2>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700 border border-purple-200">
              Solo Administrador
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Crea, edita y supervisa credenciales de acceso para Estudiantes, Instructores y Administradores con asignación directa de cursos.
          </p>
        </div>

        <button
          onClick={handleOpenCreateModal}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>Crear Nuevo Usuario</span>
        </button>
      </div>

      {/* Role Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div
          onClick={() => setRoleFilter('all')}
          className={`p-3.5 rounded-xl border cursor-pointer transition ${
            roleFilter === 'all'
              ? 'bg-purple-50/80 border-purple-300 ring-2 ring-purple-200'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Todos los Usuarios</span>
            <Users className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">{users.length}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Directorio completo</div>
        </div>

        <div
          onClick={() => setRoleFilter('student')}
          className={`p-3.5 rounded-xl border cursor-pointer transition ${
            roleFilter === 'student'
              ? 'bg-blue-50/80 border-blue-300 ring-2 ring-blue-200'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Estudiantes</span>
            <BookOpen className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-extrabold text-blue-700 mt-1">{totalStudents}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Alumnos matriculados</div>
        </div>

        <div
          onClick={() => setRoleFilter('instructor')}
          className={`p-3.5 rounded-xl border cursor-pointer transition ${
            roleFilter === 'instructor'
              ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-200'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Docentes / Instructores</span>
            <GraduationCap className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-700 mt-1">{totalInstructors}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Cuerpo docente activo</div>
        </div>

        <div
          onClick={() => setRoleFilter('admin')}
          className={`p-3.5 rounded-xl border cursor-pointer transition ${
            roleFilter === 'admin'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-200'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Administradores</span>
            <ShieldCheck className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">{totalAdmins}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Dirección y soporte</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por nombre, correo o usuario..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
          <span className="text-xs text-slate-500 font-medium flex items-center gap-1 shrink-0">
            <Filter className="w-3.5 h-3.5" /> Filtrar:
          </span>
          <button
            onClick={() => setRoleFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition shrink-0 ${
              roleFilter === 'all'
                ? 'bg-purple-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Todos ({users.length})
          </button>
          <button
            onClick={() => setRoleFilter('student')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition shrink-0 ${
              roleFilter === 'student'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Estudiantes ({totalStudents})
          </button>
          <button
            onClick={() => setRoleFilter('instructor')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition shrink-0 ${
              roleFilter === 'instructor'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Instructores ({totalInstructors})
          </button>
          <button
            onClick={() => setRoleFilter('admin')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition shrink-0 ${
              roleFilter === 'admin'
                ? 'bg-purple-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Admins ({totalAdmins})
          </button>
        </div>
      </div>

      {/* Interactive Users Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3.5">Usuario / Perfil</th>
                <th className="px-4 py-3.5">Nombre de Usuario</th>
                <th className="px-4 py-3.5">Correo Electrónico</th>
                <th className="px-4 py-3.5">Rol RBAC</th>
                <th className="px-4 py-3.5">Cursos Asignados</th>
                <th className="px-4 py-3.5">Fecha Registro</th>
                <th className="px-4 py-3.5 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-400">
                    No se encontraron usuarios con los criterios de búsqueda especificados.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => {
                  const studentEnrollments = enrollments.filter(e => e.studentId === u.id);
                  const instructorCourses = courses.filter(c => c.instructorId === u.id);

                  return (
                    <tr key={u.id} className="hover:bg-slate-50/80 transition">
                      {/* User Info */}
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={u.avatar}
                            alt={u.name}
                            className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200 shrink-0"
                          />
                          <div>
                            <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                              <span>{u.name}</span>
                              {u.id === currentUser.id && (
                                <span className="px-1.5 py-0.2 rounded text-[10px] bg-purple-100 text-purple-700 font-semibold">
                                  Tú
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500 font-medium">
                              {u.title || (u.role === 'admin' ? 'Administrador' : u.role === 'instructor' ? 'Docente' : 'Estudiante')}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Username */}
                      <td className="px-4 py-3.5">
                        <div className="inline-flex items-center gap-1.5 bg-slate-100 px-2 py-0.5 rounded-md font-mono text-[11px] text-slate-700">
                          <span>@{u.username || u.email.split('@')[0]}</span>
                          <button
                            onClick={() => handleCopy(u.username || u.email.split('@')[0], 'Usuario')}
                            title="Copiar nombre de usuario"
                            className="text-slate-400 hover:text-slate-600 cursor-pointer"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        </div>
                      </td>

                      {/* Email */}
                      <td className="px-4 py-3.5 font-mono text-slate-600 text-[11px]">
                        <div className="flex items-center gap-1">
                          <span className="truncate max-w-[170px]">{u.email}</span>
                          <button
                            onClick={() => handleCopy(u.email, 'Correo')}
                            title="Copiar correo"
                            className="text-slate-400 hover:text-slate-600 cursor-pointer"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        </div>
                      </td>

                      {/* Role Badge */}
                      <td className="px-4 py-3.5">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase inline-flex items-center gap-1 ${
                            u.role === 'admin'
                              ? 'bg-purple-100 text-purple-800 border border-purple-200'
                              : u.role === 'instructor'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : 'bg-blue-100 text-blue-800 border border-blue-200'
                          }`}
                        >
                          {u.role === 'admin' && <ShieldCheck className="w-3 h-3" />}
                          {u.role === 'instructor' && <GraduationCap className="w-3 h-3" />}
                          {u.role === 'student' && <BookOpen className="w-3 h-3" />}
                          <span>{u.role === 'admin' ? 'Administrador' : u.role === 'instructor' ? 'Instructor' : 'Estudiante'}</span>
                        </span>
                      </td>

                      {/* Assigned Courses */}
                      <td className="px-4 py-3.5">
                        {u.role === 'student' ? (
                          <div className="flex items-center gap-1">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-100">
                              {studentEnrollments.length} matriculados
                            </span>
                          </div>
                        ) : u.role === 'instructor' ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
                            {instructorCourses.length} a cargo
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">Global (Todos)</span>
                        )}
                      </td>

                      {/* Registration Date */}
                      <td className="px-4 py-3.5 text-slate-500 font-mono text-[11px]">
                        {u.registeredAt || '2025-01-15'}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Reset Password */}
                          <button
                            onClick={() => handleOpenResetPasswordModal(u)}
                            title="Restablecer o ver contraseña"
                            className="p-1.5 rounded-lg text-amber-700 hover:bg-amber-50 border border-transparent hover:border-amber-200 transition cursor-pointer"
                          >
                            <KeyRound className="w-4 h-4" />
                          </button>

                          {/* Edit User */}
                          <button
                            onClick={() => handleOpenEditModal(u)}
                            title="Editar datos del usuario"
                            className="p-1.5 rounded-lg text-blue-700 hover:bg-blue-50 border border-transparent hover:border-blue-200 transition cursor-pointer"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {/* Delete User */}
                          {u.id !== currentUser.id && (
                            <button
                              onClick={() => handleDeleteUser(u)}
                              title="Eliminar usuario y revocar accesos"
                              className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: Crear Nuevo Usuario con Asignación de Cursos */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-5 my-8 border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-100 text-purple-700">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Registrar Nuevo Usuario en la Plataforma
                  </h3>
                  <p className="text-xs text-slate-500">
                    Configura las credenciales institucionales y roles correspondientes.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              {/* Name and Role */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nombres y Apellidos Completos *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Lic. Rocío Palacios"
                    value={formName}
                    onChange={(e) => {
                      setFormName(e.target.value);
                      if (!formUsername) {
                        setFormUsername(handleAutoGenerateUsername(e.target.value, formEmail));
                      }
                    }}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Rol Institucional *
                  </label>
                  <select
                    value={formRole}
                    onChange={(e) => {
                      const newR = e.target.value as 'student' | 'instructor' | 'admin';
                      setFormRole(newR);
                      if (newR === 'student') setFormTitle('Estudiante Regular');
                      else if (newR === 'instructor') setFormTitle('Docente Especialista');
                      else setFormTitle('Coordinador Administrativo');
                    }}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-hidden bg-white"
                  >
                    <option value="student">Estudiante (Acceso a cursos y tareas)</option>
                    <option value="instructor">Instructor / Docente (Calificaciones y Zoom)</option>
                    <option value="admin">Administrador (Gestión total del centro)</option>
                  </select>
                </div>
              </div>

              {/* Email and Username */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Correo Electrónico *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="rocio.palacios@amadeusg.edu.pe"
                    value={formEmail}
                    onChange={(e) => {
                      setFormEmail(e.target.value);
                      if (!formUsername) {
                        setFormUsername(handleAutoGenerateUsername(formName, e.target.value));
                      }
                    }}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      Nombre de Usuario (Login) *
                    </label>
                    <button
                      type="button"
                      onClick={() => setFormUsername(handleAutoGenerateUsername(formName, formEmail))}
                      className="text-[10px] text-purple-600 hover:underline font-semibold"
                    >
                      Sugerir
                    </button>
                  </div>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400 text-xs font-mono">
                      @
                    </span>
                    <input
                      type="text"
                      required
                      placeholder="rocio.palacios"
                      value={formUsername}
                      onChange={(e) => setFormUsername(e.target.value)}
                      className="w-full text-xs pl-7 pr-3 p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-hidden font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Password and Title */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      Contraseña Inicial *
                    </label>
                    <button
                      type="button"
                      onClick={() => setFormPassword(generateRandomPassword())}
                      className="text-[10px] text-purple-600 hover:underline font-semibold"
                    >
                      Generar aleatoria
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={formPassword}
                      onChange={(e) => setFormPassword(e.target.value)}
                      className="w-full text-xs p-2.5 pr-8 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-hidden font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Cargo / Especialidad (Opcional)
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: Especialista en Ciberseguridad"
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Course Assignment section (Only for Students) */}
              {formRole === 'student' && (
                <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900">
                      <BookCheck className="w-4 h-4 text-blue-600" />
                      <span>Asignación Opcional a Cursos Disponibles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedCourseIds(courses.map(c => c.id))}
                        className="text-[10px] text-blue-700 hover:underline font-semibold"
                      >
                        Marcar todos
                      </button>
                      <span className="text-slate-300 text-xs">|</span>
                      <button
                        type="button"
                        onClick={() => setSelectedCourseIds([])}
                        className="text-[10px] text-blue-700 hover:underline font-semibold"
                      >
                        Limpiar
                      </button>
                    </div>
                  </div>

                  <p className="text-[11px] text-blue-700">
                    El alumno quedará matriculado de inmediato en los programas seleccionados:
                  </p>

                  <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                    {courses.map(course => {
                      const isChecked = selectedCourseIds.includes(course.id);
                      return (
                        <label
                          key={course.id}
                          className={`flex items-start gap-2.5 p-2 rounded-lg border text-xs cursor-pointer transition ${
                            isChecked
                              ? 'bg-blue-100/70 border-blue-300 text-blue-950 font-medium'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedCourseIds(prev => [...prev, course.id]);
                              } else {
                                setSelectedCourseIds(prev => prev.filter(id => id !== course.id));
                              }
                            }}
                            className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="truncate font-semibold text-[11px]">{course.title}</div>
                            <div className="text-[10px] text-slate-500">
                              {course.category} • {course.durationHours} hrs
                            </div>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700 transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Crear y Guardar Usuario</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Modal de Confirmación con Resumen de Credenciales */}
      {createSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-emerald-200 animate-fadeIn">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-2">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-extrabold text-slate-900">
                ¡Usuario Creado Exitosamente!
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Las credenciales ya están activas y guardadas para inicio de sesión inmediato.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Nombre:</span>
                <span className="font-bold text-slate-900">{createSuccessModal.user.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Rol:</span>
                <span className="font-bold text-purple-700 uppercase text-[11px]">{createSuccessModal.user.role}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Usuario:</span>
                <span className="font-mono font-bold text-slate-900">@{createSuccessModal.user.username}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Correo:</span>
                <span className="font-mono font-bold text-slate-900">{createSuccessModal.user.email}</span>
              </div>
              <div className="flex justify-between items-center bg-amber-50 p-2 rounded-lg border border-amber-200">
                <span className="text-amber-800 font-semibold">Contraseña:</span>
                <span className="font-mono font-bold text-amber-900">{createSuccessModal.user.password}</span>
              </div>

              {createSuccessModal.assignedCourses.length > 0 && (
                <div className="pt-2 border-t border-slate-200">
                  <span className="text-slate-500 block mb-1">Cursos Matriculados ({createSuccessModal.assignedCourses.length}):</span>
                  <ul className="list-disc list-inside text-[11px] text-blue-700 font-medium space-y-0.5">
                    {createSuccessModal.assignedCourses.map((t, idx) => (
                      <li key={idx} className="truncate">{t}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  const summary = `Acceso AMADEUS G. Virtual:\nNombre: ${createSuccessModal.user.name}\nUsuario: ${createSuccessModal.user.username}\nCorreo: ${createSuccessModal.user.email}\nContraseña: ${createSuccessModal.user.password}\nRol: ${createSuccessModal.user.role}`;
                  handleCopy(summary, 'Credenciales completas');
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar Datos</span>
              </button>
              <button
                type="button"
                onClick={() => setCreateSuccessModal(null)}
                className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
              >
                Listo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Editar Usuario */}
      {userToEdit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-blue-100 text-blue-700">
                  <Edit2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Editar Datos de Usuario
                  </h3>
                  <p className="text-xs text-slate-500">
                    Modifica perfil, cargo institucional o rol RBAC.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setUserToEdit(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nombres y Apellidos *
                </label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Correo Electrónico *
                </label>
                <input
                  type="email"
                  required
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nombre de Usuario *
                  </label>
                  <input
                    type="text"
                    required
                    value={editUsername}
                    onChange={(e) => setEditUsername(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Rol RBAC *
                  </label>
                  <select
                    value={editRole}
                    onChange={(e) => setEditRole(e.target.value as UserRole)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden bg-white"
                  >
                    <option value="student">Estudiante</option>
                    <option value="instructor">Instructor</option>
                    <option value="admin">Administrador</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Cargo / Especialidad
                </label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setUserToEdit(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700 transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-sm transition"
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: Restablecer Contraseña */}
      {userToResetPassword && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-100 text-amber-700">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Restablecer Contraseña
                  </h3>
                  <p className="text-xs text-slate-500">
                    Para: <span className="font-bold text-slate-800">{userToResetPassword.name}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setUserToResetPassword(null);
                  setResetSuccessMessage(null);
                }}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {resetSuccessMessage ? (
              <div className="space-y-4 py-2">
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span className="font-semibold">{resetSuccessMessage}</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1.5 font-mono">
                  <div>Usuario: <span className="font-bold">@{userToResetPassword.username || userToResetPassword.email.split('@')[0]}</span></div>
                  <div>Nueva Clave: <span className="font-bold text-amber-700">{newPassword}</span></div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopy(`Usuario: ${userToResetPassword.username}\nContraseña: ${newPassword}`, 'Credenciales')}
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Datos</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setUserToResetPassword(null);
                      setResetSuccessMessage(null);
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition"
                  >
                    Cerrar
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      Nueva Contraseña
                    </label>
                    <button
                      type="button"
                      onClick={() => setNewPassword(generateRandomPassword())}
                      className="text-[10px] text-purple-600 hover:underline font-semibold"
                    >
                      Generar aleatoria
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showResetPassword ? 'text' : 'password'}
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full text-xs p-2.5 pr-8 rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-hidden font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowResetPassword(!showResetPassword)}
                      className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600"
                    >
                      {showResetPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-2.5 text-[11px] text-amber-800">
                  Al confirmar, el usuario podrá ingresar inmediatamente en el Login con esta nueva clave.
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setUserToResetPassword(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700 transition"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-sm transition"
                  >
                    Actualizar Contraseña
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
