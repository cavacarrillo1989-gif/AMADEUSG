import React, { useState } from 'react';
import {
  DollarSign,
  CreditCard,
  Building2,
  Phone,
  Search,
  CheckCircle2,
  Clock,
  Download,
  ExternalLink,
  Filter,
  FileText,
  ShieldCheck,
  TrendingUp,
  Receipt
} from 'lucide-react';
import { usePlatform } from '../../context/PlatformContext';
import { PaymentTransaction } from '../../types';

export const AdminPaymentsTab: React.FC = () => {
  const { transactions, centerSettings } = usePlatform();
  const [searchTerm, setSearchTerm] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('all');
  const [selectedTx, setSelectedTx] = useState<PaymentTransaction | null>(null);

  const totalRevenue = transactions.reduce((sum, tx) => sum + (tx.status === 'completed' ? tx.amount : 0), 0);
  const totalCompleted = transactions.filter(t => t.status === 'completed').length;
  const averageTicket = totalCompleted > 0 ? (totalRevenue / totalCompleted).toFixed(2) : '0.00';

  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch =
      tx.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.courseTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.transactionRef.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesMethod = methodFilter === 'all' || tx.method === methodFilter;

    return matchesSearch && matchesMethod;
  });

  const getMethodBadge = (tx: PaymentTransaction) => {
    switch (tx.method) {
      case 'credit_card':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <CreditCard className="w-3 h-3" />
            <span>Tarjeta **** {tx.cardLastFour || 'XXXX'}</span>
          </span>
        );
      case 'bank_transfer':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
            <Building2 className="w-3 h-3" />
            <span>Transf. {tx.bankName || 'Bancaria'}</span>
          </span>
        );
      case 'paypal':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-sky-50 text-sky-700 border border-sky-200">
            <DollarSign className="w-3 h-3" />
            <span>PayPal Express</span>
          </span>
        );
      case 'whatsapp_advisor':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <Phone className="w-3 h-3" />
            <span>Asesor WhatsApp</span>
          </span>
        );
      default:
        return <span className="text-xs text-slate-600">{tx.method}</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Recaudación Total</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">${totalRevenue} USD</p>
          <span className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            Cobros verificados en plataforma
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Transacciones Exitosas</span>
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalCompleted}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Matrículas pagadas</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Ticket Promedio</span>
            <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">${averageTicket} USD</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Por inscripción confirmada</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">WhatsApp Contacto</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Phone className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-mono font-black text-slate-900 mt-2">0997342614</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Línea de soporte y cobros</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xs">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            placeholder="Buscar por alumno, curso o comprobante..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full text-xs p-2.5 pl-9 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={methodFilter}
            onChange={e => setMethodFilter(e.target.value)}
            className="text-xs p-2.5 rounded-xl border border-slate-300 bg-white"
          >
            <option value="all">Todos los Métodos de Pago</option>
            <option value="credit_card">Tarjeta Débito/Crédito</option>
            <option value="bank_transfer">Transferencia Bancaria</option>
            <option value="paypal">PayPal</option>
            <option value="whatsapp_advisor">Asesor WhatsApp</option>
          </select>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold uppercase border-b border-slate-200 text-[10px] tracking-wider">
              <tr>
                <th className="p-4">Recibo / Referencia</th>
                <th className="p-4">Estudiante</th>
                <th className="p-4">Curso Adquirido</th>
                <th className="p-4">Método</th>
                <th className="p-4">Fecha</th>
                <th className="p-4 text-right">Monto</th>
                <th className="p-4 text-center">Estado</th>
                <th className="p-4 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    No se encontraron transacciones con los criterios seleccionados.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-50/70 transition">
                    <td className="p-4">
                      <div className="font-mono font-bold text-slate-900">{tx.receiptNumber}</div>
                      <div className="font-mono text-[10px] text-slate-400">{tx.transactionRef}</div>
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-slate-900">{tx.studentName}</div>
                      <div className="text-[11px] text-slate-500">{tx.studentEmail}</div>
                    </td>
                    <td className="p-4">
                      <div className="font-semibold text-slate-800 line-clamp-1 max-w-[220px]">
                        {tx.courseTitle}
                      </div>
                    </td>
                    <td className="p-4">{getMethodBadge(tx)}</td>
                    <td className="p-4 text-slate-500">
                      {new Date(tx.paymentDate).toLocaleDateString()}
                    </td>
                    <td className="p-4 text-right font-bold text-slate-900">
                      ${tx.amount} <span className="text-[10px] text-slate-500 font-normal">USD</span>
                    </td>
                    <td className="p-4 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        <CheckCircle2 className="w-3 h-3" />
                        Aprobado
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => setSelectedTx(tx)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold transition"
                      >
                        Ver Recibo
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction Receipt Modal */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-5 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    Recibo Oficial de Recaudación
                  </h3>
                  <p className="text-[10px] text-slate-500">{centerSettings.name}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedTx(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-3">
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">N° de Recibo:</span>
                <span className="font-mono font-bold text-blue-700">{selectedTx.receiptNumber}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Ref. Transacción:</span>
                <span className="font-mono font-bold text-slate-800">{selectedTx.transactionRef}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Estudiante:</span>
                <span className="font-bold text-slate-900">{selectedTx.studentName}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Correo:</span>
                <span className="text-slate-800">{selectedTx.studentEmail}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Programa:</span>
                <span className="font-bold text-slate-900 text-right max-w-[260px]">{selectedTx.courseTitle}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Método de Pago:</span>
                <span className="capitalize text-slate-800">
                  {selectedTx.method === 'credit_card' && `Tarjeta Crédito/Débito (**** ${selectedTx.cardLastFour})`}
                  {selectedTx.method === 'bank_transfer' && `Transferencia (${selectedTx.bankName || 'Bancaria'})`}
                  {selectedTx.method === 'paypal' && 'PayPal Express'}
                  {selectedTx.method === 'whatsapp_advisor' && 'Asesor Académico WhatsApp'}
                </span>
              </div>
              {selectedTx.voucherFileName && (
                <div className="flex justify-between border-b border-slate-200 pb-2">
                  <span className="text-slate-500">Comprobante Adjunto:</span>
                  <span className="font-mono text-emerald-700 font-semibold">{selectedTx.voucherFileName}</span>
                </div>
              )}
              <div className="flex justify-between pt-1 text-sm font-black">
                <span className="text-slate-900">Total Recaudado:</span>
                <span className="text-emerald-600">${selectedTx.amount} USD</span>
              </div>
            </div>

            <div className="flex gap-2">
              <a
                href={`https://wa.me/593997342614?text=${encodeURIComponent(
                  `Hola, consulto sobre el recibo ${selectedTx.receiptNumber} de ${selectedTx.studentName} para el curso ${selectedTx.courseTitle}.`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>WhatsApp: 0997342614</span>
              </a>
              <button
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Imprimir Recibo</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
