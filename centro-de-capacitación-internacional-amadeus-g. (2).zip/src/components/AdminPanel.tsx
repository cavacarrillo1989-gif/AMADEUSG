import React, { useState } from 'react';
import {
  Shield,
  BookOpen,
  Users,
  Award,
  Settings,
  Plus,
  Edit2,
  Trash2,
  CheckCircle,
  FileText,
  Search,
  Check,
  TrendingUp,
  UserCheck,
  Building,
  ExternalLink
} from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';
import { Course, User, UserRole, Certificate } from '../types';
import { EditCourseModal } from './modals/EditCourseModal';
import { AdminPaymentsTab } from './admin/AdminPaymentsTab';
import { AdminUsersManager } from './admin/AdminUsersManager';

interface AdminPanelProps {
  onOpenClassroom: (courseId: string) => void;
  onNavigateTab?: (tab: string) => void;
  activeSubTab?: 'dashboard' | 'courses' | 'users' | 'enrollments' | 'certificates' | 'settings' | 'payments';
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  onOpenClassroom,
  onNavigateTab,
  activeSubTab = 'dashboard'
}) => {
  const {
    currentUser,
    courses,
    users,
    enrollments,
    certificates,
    centerSettings,
    updateCenterSettings,
    createCourse,
    updateCourse,
    deleteCourse,
    createUser,
    enrollInCourse,
    unenrollCourse,
    setActiveCertificateModal
  } = usePlatform();

  // Create course modal state
  const [showCourseModal, setShowCourseModal] = useState(false);
  const [courseTitle, setCourseTitle] = useState('');
  const [courseDesc, setCourseDesc] = useState('');
  const [courseShortDesc, setCourseShortDesc] = useState('');
  const [courseImage, setCourseImage] = useState('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&auto=format&fit=crop&q=80');
  const [courseInstructorId, setCourseInstructorId] = useState(users.find(u => u.role === 'instructor')?.id || '');
  const [courseHours, setCourseHours] = useState(40);
  const [courseCategory, setCourseCategory] = useState('Tecnología');
  const [courseLevel, setCourseLevel] = useState<'Básico' | 'Intermedio' | 'Avanzado'>('Intermedio');

  // Enrollment selection
  const [selectedStudentToEnroll, setSelectedStudentToEnroll] = useState('');
  const [selectedCourseToEnroll, setSelectedCourseToEnroll] = useState('');

  // Course editing state
  const [courseToEdit, setCourseToEdit] = useState<Course | null>(null);

  // Certificate verification tester
  const [verifySearchCode, setVerifySearchCode] = useState('');
  const [verificationResult, setVerificationResult] = useState<Certificate | null | 'not_found'>(null);

  // Stats calculation
  const totalStudents = users.filter(u => u.role === 'student').length;
  const totalInstructors = users.filter(u => u.role === 'instructor').length;
  const totalEnrollments = enrollments.length;
  const completedEnrollments = enrollments.filter(e => e.isCompleted).length;
  const completionRate = totalEnrollments > 0 ? Math.round((completedEnrollments / totalEnrollments) * 100) : 0;

  const handleCreateCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseTitle.trim()) return;

    createCourse({
      title: courseTitle,
      slug: courseTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
      description: courseDesc,
      shortDescription: courseShortDesc || courseDesc.substring(0, 120),
      image: courseImage,
      instructorId: courseInstructorId || users[0].id,
      durationHours: courseHours,
      category: courseCategory,
      level: courseLevel,
      status: 'published',
      passingScorePercent: 70
    });

    setCourseTitle('');
    setCourseDesc('');
    setShowCourseModal(false);
    alert('Curso creado con éxito en la plataforma.');
  };

  const handleQuickEnroll = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentToEnroll || !selectedCourseToEnroll) {
      alert('Selecciona un estudiante y un curso.');
      return;
    }
    enrollInCourse(selectedCourseToEnroll, selectedStudentToEnroll);
    alert('Estudiante matriculado satisfactoriamente.');
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = verifySearchCode.trim().toUpperCase();
    const found = certificates.find(c => c.certificateCode.toUpperCase() === cleanCode);
    setVerificationResult(found || 'not_found');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md">
        <div>
          <span className="text-xs font-bold text-purple-400 uppercase tracking-wider block">
            Dirección Académica y Gestión General
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            Panel de Control Administrativo
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            Control integral del Centro de Capacitación: supervisión de cursos, matrícula de estudiantes, emisión de certificados y parámetros institucionales.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCourseModal(true)}
            className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Crear Nuevo Curso</span>
          </button>
          <button
            onClick={() => {
              if (onNavigateTab) {
                onNavigateTab('admin_users');
              }
            }}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition border border-slate-700 cursor-pointer"
          >
            <Users className="w-4 h-4 text-purple-400" />
            <span>Gestor de Usuarios</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Estudiantes</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalStudents}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Alumnos registrados</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Cursos Activos</span>
            <BookOpen className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{courses.length}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">{courses.filter(c => c.status === 'published').length} publicados</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Matrículas</span>
            <UserCheck className="w-4 h-4 text-purple-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalEnrollments}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Tasa de éxito: {completionRate}%</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Certificados</span>
            <Award className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-amber-600 mt-2">{certificates.length}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Diplomas oficiales expedidos</span>
        </div>
      </div>

      {/* Subtab: Dashboard Overview */}
      {activeSubTab === 'dashboard' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Quick Enrolled summary */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">
                Cursos Ofertados y Estado de Publicación
              </h3>
              <button
                onClick={() => setShowCourseModal(true)}
                className="text-xs font-bold text-purple-600 hover:text-purple-800"
              >
                + Añadir Curso
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {courses.map(course => {
                const instructor = users.find(u => u.id === course.instructorId);
                const enrCount = enrollments.filter(e => e.courseId === course.id).length;

                return (
                  <div key={course.id} className="py-3 flex items-center justify-between text-xs gap-3">
                    <div className="flex items-center gap-3">
                      <img src={course.image} alt={course.title} className="w-12 h-10 rounded-lg object-cover" />
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">{course.title}</h4>
                        <span className="text-slate-500 text-[11px]">
                          Docente: {instructor?.name} • {course.durationHours} hrs lectivas • {enrCount} alumnos inscritos
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        course.status === 'published' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {course.status === 'published' ? 'Publicado' : 'Borrador'}
                      </span>
                      <button
                        onClick={() => setCourseToEdit(course)}
                        className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg text-xs"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => onOpenClassroom(course.id)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-xs"
                      >
                        Ver Aula
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Enroll Widget */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-purple-600" />
              <span>Matrícula Rápida de Alumnos</span>
            </h3>
            <p className="text-xs text-slate-500">
              Asigna acceso inmediato al aula virtual a cualquier estudiante.
            </p>

            <form onSubmit={handleQuickEnroll} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Estudiante:</label>
                <select
                  value={selectedStudentToEnroll}
                  onChange={e => setSelectedStudentToEnroll(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                >
                  <option value="">Selecciona estudiante...</option>
                  {users.filter(u => u.role === 'student').map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.email})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Curso:</label>
                <select
                  value={selectedCourseToEnroll}
                  onChange={e => setSelectedCourseToEnroll(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                >
                  <option value="">Selecciona curso...</option>
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs shadow-sm transition"
              >
                Matricular en el Aula
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Subtab: Courses Management */}
      {activeSubTab === 'courses' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Gestión Integral de Cursos de Capacitación
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Crea, edita, cambia el estado y asigna los docentes responsables.
              </p>
            </div>
            <button
              onClick={() => setShowCourseModal(true)}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Nuevo Curso</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map(course => {
              const instructor = users.find(u => u.id === course.instructorId);

              return (
                <div key={course.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs flex flex-col justify-between">
                  <div>
                    <div className="relative h-40 w-full bg-slate-100">
                      <img src={course.image} alt={course.title} className="w-full h-full object-cover" />
                      <div className="absolute top-3 right-3 flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          course.status === 'published' ? 'bg-emerald-500 text-white' : 'bg-slate-700 text-white'
                        }`}>
                          {course.status === 'published' ? 'Publicado' : 'Borrador'}
                        </span>
                      </div>
                    </div>

                    <div className="p-5 space-y-2">
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">
                        {course.category} • Nivel {course.level}
                      </span>
                      <h3 className="font-bold text-slate-900 text-base leading-snug">
                        {course.title}
                      </h3>
                      <p className="text-xs text-slate-500 line-clamp-2">
                        {course.description}
                      </p>
                      <div className="pt-2 text-xs text-slate-600 flex items-center justify-between border-t border-slate-100">
                        <span>Docente: <strong>{instructor?.name}</strong></span>
                        <span className="font-semibold text-slate-800">{course.durationHours} hrs</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2">
                    <button
                      onClick={() => onOpenClassroom(course.id)}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs"
                    >
                      Aula Virtual
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setCourseToEdit(course)}
                        className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1"
                        title="Editar título, descripción, nivel, horas y docente"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Editar</span>
                      </button>
                      <button
                        onClick={() => {
                          const newStatus = course.status === 'published' ? 'draft' : 'published';
                          updateCourse(course.id, { status: newStatus });
                        }}
                        className="px-2.5 py-1.5 bg-white hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold"
                      >
                        {course.status === 'published' ? 'Pausar' : 'Publicar'}
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`¿Eliminar el curso "${course.title}"?`)) {
                            deleteCourse(course.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Subtab: Users and Roles - Dedicated RBAC Manager */}
      {activeSubTab === 'users' && (
        <AdminUsersManager />
      )}

      {/* Subtab: Enrollments */}
      {activeSubTab === 'enrollments' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Registro General de Matrículas e Inscripciones
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Supervisión de cada estudiante en sus cursos asignados.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Estudiante</th>
                  <th className="px-4 py-3">Curso Matriculado</th>
                  <th className="px-4 py-3">Fecha Inscripción</th>
                  <th className="px-4 py-3">Estado Académico</th>
                  <th className="px-4 py-3 text-right">Gestión</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {enrollments.map(enr => {
                  const student = users.find(u => u.id === enr.studentId);
                  const course = courses.find(c => c.id === enr.courseId);

                  return (
                    <tr key={enr.id} className="hover:bg-slate-50/60">
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        {student?.name}
                      </td>
                      <td className="px-4 py-3 text-slate-700">
                        {course?.title}
                      </td>
                      <td className="px-4 py-3 text-slate-500">
                        {enr.enrolledAt}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          enr.isCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {enr.isCompleted ? 'Graduado' : 'Cursando'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => {
                            if (confirm(`¿Desinscribir a ${student?.name} del curso ${course?.title}?`)) {
                              unenrollCourse(enr.courseId, enr.studentId);
                            }
                          }}
                          className="text-red-600 hover:text-red-800 font-semibold"
                        >
                          Eliminar Matrícula
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab: Certificates Registry & Public Verifier */}
      {activeSubTab === 'certificates' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Registro Central de Certificados Emitidos y Validador Público
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Auditoría de acreditaciones laborales emitidas con código de validación infalsificable.
            </p>
          </div>

          {/* Verification Code Tester */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-6">
            <h3 className="font-bold text-amber-950 text-sm mb-1 flex items-center gap-2">
              <Search className="w-4 h-4 text-amber-700" />
              <span>Verificador de Autenticidad de Certificado</span>
            </h3>
            <p className="text-xs text-amber-800 mb-3">
              Ingresa el código oficial impreso en el diploma (ejemplo: <code>AMADEUS-2025-AGL-89412</code>) para comprobar validez:
            </p>

            <form onSubmit={handleVerifyCode} className="flex gap-2 max-w-md">
              <input
                type="text"
                placeholder="Código ej: AMADEUS-2025-AGL-89412"
                value={verifySearchCode}
                onChange={e => setVerifySearchCode(e.target.value)}
                className="flex-1 text-xs p-2.5 rounded-xl border border-amber-300 font-mono font-bold uppercase focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs"
              >
                Verificar
              </button>
            </form>

            {verificationResult && verificationResult !== 'not_found' && (
              <div className="mt-4 p-4 bg-white rounded-xl border border-emerald-300 text-xs space-y-1 animate-fadeIn">
                <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-sm">
                  <CheckCircle className="w-4 h-4" />
                  <span>Certificado Auténtico y Vigente</span>
                </div>
                <p>Estudiante Acreditado: <strong>{verificationResult.studentName}</strong></p>
                <p>Programa: <strong>{verificationResult.courseTitle}</strong></p>
                <p>Horas Lectivas: <strong>{verificationResult.durationHours} horas pedagógicas</strong></p>
                <p>Emisión: <strong>{verificationResult.issueDate}</strong></p>
                <div className="pt-2">
                  <button
                    onClick={() => setActiveCertificateModal(verificationResult)}
                    className="text-xs font-bold text-blue-600 hover:underline"
                  >
                    Ver Diploma Digital Oficial →
                  </button>
                </div>
              </div>
            )}

            {verificationResult === 'not_found' && (
              <div className="mt-4 p-3 bg-red-100 text-red-800 rounded-xl text-xs font-semibold">
                No se encontró ningún certificado registrado con ese código de verificación.
              </div>
            )}
          </div>

          {/* Table of all certificates */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Código Oficial</th>
                  <th className="px-4 py-3">Estudiante Graduado</th>
                  <th className="px-4 py-3">Curso Acreditado</th>
                  <th className="px-4 py-3">Horas</th>
                  <th className="px-4 py-3">Fecha de Emisión</th>
                  <th className="px-4 py-3 text-right">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {certificates.map(cert => (
                  <tr key={cert.id} className="hover:bg-slate-50/60">
                    <td className="px-4 py-3 font-mono font-bold text-amber-900">
                      {cert.certificateCode}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900">
                      {cert.studentName}
                    </td>
                    <td className="px-4 py-3 text-slate-700">
                      {cert.courseTitle}
                    </td>
                    <td className="px-4 py-3 text-slate-600 font-semibold">
                      {cert.durationHours} hrs
                    </td>
                    <td className="px-4 py-3 text-slate-500">
                      {cert.issueDate}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => setActiveCertificateModal(cert)}
                        className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs shadow-xs"
                      >
                        Visualizar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab: Institutional Center Settings */}
      {activeSubTab === 'settings' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Parámetros Institucionales del Centro de Capacitación
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Configura los datos oficiales que aparecerán en la cabecera, firmas de diplomas y certificados.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 max-w-2xl space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Nombre Oficial del Centro:</label>
              <input
                type="text"
                value={centerSettings.name}
                onChange={e => updateCenterSettings({ name: e.target.value })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Lema o Slogan Institucional:</label>
              <input
                type="text"
                value={centerSettings.tagline}
                onChange={e => updateCenterSettings({ tagline: e.target.value })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Director Académico:</label>
                <input
                  type="text"
                  value={centerSettings.directorName}
                  onChange={e => updateCenterSettings({ directorName: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Cargo Oficial:</label>
                <input
                  type="text"
                  value={centerSettings.directorTitle}
                  onChange={e => updateCenterSettings({ directorTitle: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Resolución / Acreditación:</label>
                <input
                  type="text"
                  value={centerSettings.accreditationCode}
                  onChange={e => updateCenterSettings({ accreditationCode: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Teléfono Central:</label>
                <input
                  type="text"
                  value={centerSettings.contactPhone}
                  onChange={e => updateCenterSettings({ contactPhone: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Correo de Informes:</label>
              <input
                type="email"
                value={centerSettings.contactEmail}
                onChange={e => updateCenterSettings({ contactEmail: e.target.value })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
              />
            </div>

            <div className="pt-2">
              <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                Los cambios se guardan automáticamente en tiempo real.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Subtab: Payments & Revenue */}
      {activeSubTab === 'payments' && (
        <AdminPaymentsTab />
      )}

      {/* Modal New Course */}
      {showCourseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Crear Nuevo Curso de Capacitación</h3>
            <form onSubmit={handleCreateCourse} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Título del Curso:</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Certificación en Seguridad de la Información ISO 27001"
                  value={courseTitle}
                  onChange={e => setCourseTitle(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Descripción Completa:</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Programa intensivo orientado a..."
                  value={courseDesc}
                  onChange={e => setCourseDesc(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Instructor Responsable:</label>
                  <select
                    value={courseInstructorId}
                    onChange={e => setCourseInstructorId(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                  >
                    {users.filter(u => u.role === 'instructor').map(i => (
                      <option key={i.id} value={i.id}>{i.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Duración (Horas Lectivas):</label>
                  <input
                    type="number"
                    min="10"
                    value={courseHours}
                    onChange={e => setCourseHours(Number(e.target.value))}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Categoría:</label>
                  <input
                    type="text"
                    value={courseCategory}
                    onChange={e => setCourseCategory(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nivel:</label>
                  <select
                    value={courseLevel}
                    onChange={e => setCourseLevel(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                  >
                    <option value="Básico">Básico</option>
                    <option value="Intermedio">Intermedio</option>
                    <option value="Avanzado">Avanzado</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">URL de Imagen de Portada:</label>
                <input
                  type="text"
                  value={courseImage}
                  onChange={e => setCourseImage(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCourseModal(false)}
                  className="px-4 py-2 bg-slate-100 rounded-xl text-xs font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-600 text-white font-bold rounded-xl text-xs"
                >
                  Guardar y Publicar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Course Modal */}
      <EditCourseModal
        course={courseToEdit}
        isOpen={!!courseToEdit}
        onClose={() => setCourseToEdit(null)}
      />
    </div>
  );
};
