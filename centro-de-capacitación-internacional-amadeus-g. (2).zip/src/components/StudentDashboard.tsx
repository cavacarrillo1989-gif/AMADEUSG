import React from 'react';
import {
  BookOpen,
  Award,
  Video,
  CheckSquare,
  Clock,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  FileText,
  Calendar,
  Sparkles,
  Download,
  AlertCircle
} from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';
import { Course, ZoomSession } from '../types';

interface StudentDashboardProps {
  onSelectCourse: (courseId: string) => void;
  onOpenCatalog: () => void;
  onOpenZoomModal: (session: ZoomSession) => void;
  activeSubTab?: 'courses' | 'tasks' | 'zoom' | 'certificates';
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  onSelectCourse,
  onOpenCatalog,
  onOpenZoomModal,
  activeSubTab = 'courses'
}) => {
  const {
    currentUser,
    courses,
    enrollments,
    users,
    tasks,
    taskSubmissions,
    quizzes,
    quizAttempts,
    zoomSessions,
    certificates,
    getCourseProgress,
    setActiveCertificateModal,
    centerSettings
  } = usePlatform();

  // Courses enrolled by current student
  const myEnrollments = enrollments.filter(e => e.studentId === currentUser.id);
  const myCourses = courses.filter(c => myEnrollments.some(e => e.courseId === c.id));
  const myCertificates = certificates.filter(c => c.studentId === currentUser.id);

  // Overall metrics calculation
  const totalHours = myCourses.reduce((acc, c) => acc + c.durationHours, 0);
  const totalSubmissions = taskSubmissions.filter(s => s.studentId === currentUser.id).length;
  const gradedSubmissions = taskSubmissions.filter(s => s.studentId === currentUser.id && s.status === 'graded');
  const avgGrade = gradedSubmissions.length > 0
    ? (gradedSubmissions.reduce((acc, s) => acc + (s.score || 0), 0) / gradedSubmissions.length).toFixed(1)
    : '19.0';

  // Upcoming Zoom sessions for my courses
  const myCourseIds = myCourses.map(c => c.id);
  const myZoomSessions = zoomSessions.filter(z => myCourseIds.includes(z.courseId));

  // Tasks for enrolled courses
  const myTasks = tasks.filter(t => myCourseIds.includes(t.courseId));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-blue-200 text-xs font-semibold backdrop-blur-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Campus Virtual para Estudiantes</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
            Hola, {currentUser.name.split(' ')[0]} 👋
          </h1>
          <p className="text-sm sm:text-base text-blue-100/90 leading-relaxed">
            Bienvenido a tu panel de formación. Continúa el avance de tus aulas virtuales,
            revisa las retroalimentaciones de tus docentes y descarga tus certificados oficiales.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenCatalog}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs sm:text-sm shadow-md transition"
            >
              Explorar Nuevos Cursos
            </button>
            {myCertificates.length > 0 && (
              <button
                onClick={() => setActiveCertificateModal(myCertificates[0])}
                className="px-4 py-2 bg-white/15 hover:bg-white/25 text-white font-semibold rounded-xl text-xs sm:text-sm backdrop-blur-xs border border-white/20 transition flex items-center gap-1.5"
              >
                <Award className="w-4 h-4 text-amber-300" />
                <span>Ver Mi Certificado Oficial</span>
              </button>
            )}
          </div>
        </div>

        {/* Ambient background decoration */}
        <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-80 h-80 rounded-full bg-blue-500/10 blur-3xl pointer-events-none"></div>
      </div>

      {/* KPI Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Cursos Activos</span>
            <div className="p-2 bg-blue-50 text-blue-700 rounded-xl">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{myCourses.length}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Inscripciones confirmadas</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Horas Lectivas</span>
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalHours} hrs</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Acreditación acumulada</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Promedio Tareas</span>
            <div className="p-2 bg-purple-50 text-purple-700 rounded-xl">
              <CheckSquare className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{avgGrade} <span className="text-xs font-semibold text-slate-400">/ 20</span></p>
          <span className="text-[11px] text-slate-500 mt-1 block">{totalSubmissions} entregas realizadas</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Certificados</span>
            <div className="p-2 bg-amber-50 text-amber-700 rounded-xl">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-600 mt-2">{myCertificates.length}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Diplomas emitidos</span>
        </div>
      </div>

      {/* Main Content Areas according to subtab */}
      {activeSubTab === 'courses' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Mis Aulas Virtuales
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Accede al contenido, lecciones interactivas, tareas y material de estudio.
              </p>
            </div>
            <button
              onClick={onOpenCatalog}
              className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1"
            >
              <span>Ver más cursos</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {myCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myCourses.map(course => {
                const progress = getCourseProgress(course.id, currentUser.id);
                const instructor = users.find(u => u.id === course.instructorId);
                const cert = certificates.find(c => c.studentId === currentUser.id && c.courseId === course.id);

                return (
                  <div
                    key={course.id}
                    className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-shadow overflow-hidden flex flex-col"
                  >
                    {/* Course Banner Image */}
                    <div className="relative h-44 w-full bg-slate-200 overflow-hidden">
                      <img
                        src={course.image}
                        alt={course.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 left-3">
                        <span className="px-2.5 py-1 bg-slate-900/80 backdrop-blur-xs text-white text-[11px] font-bold rounded-lg uppercase tracking-wide">
                          {course.category}
                        </span>
                      </div>
                      <div className="absolute top-3 right-3">
                        <span className="px-2 py-0.5 bg-blue-600 text-white text-[11px] font-semibold rounded-md">
                          {course.durationHours} hrs
                        </span>
                      </div>
                    </div>

                    {/* Course Card Body */}
                    <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                      <div>
                        <h3 className="font-bold text-slate-900 text-base leading-snug line-clamp-2">
                          {course.title}
                        </h3>
                        <p className="text-xs text-slate-500 line-clamp-2 mt-1.5 leading-relaxed">
                          {course.shortDescription}
                        </p>
                      </div>

                      <div className="space-y-3 pt-2 border-t border-slate-100">
                        {/* Instructor Info */}
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          {instructor && (
                            <>
                              <img
                                src={instructor.avatar}
                                alt={instructor.name}
                                className="w-5 h-5 rounded-full object-cover"
                              />
                              <span className="font-medium truncate">{instructor.name}</span>
                            </>
                          )}
                        </div>

                        {/* Progress Bar */}
                        <div>
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="font-medium text-slate-600">Avance Académico:</span>
                            <span className="font-bold text-slate-900">{progress.percent}%</span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                            <div
                              className={`h-2 rounded-full transition-all duration-500 ${
                                progress.percent >= 100 ? 'bg-emerald-500' : 'bg-blue-600'
                              }`}
                              style={{ width: `${progress.percent}%` }}
                            ></div>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => onSelectCourse(course.id)}
                            className="flex-1 py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 shadow-xs"
                          >
                            <BookOpen className="w-4 h-4" />
                            <span>Ingresar al Aula</span>
                          </button>

                          {cert && (
                            <button
                              onClick={() => setActiveCertificateModal(cert)}
                              title="Ver Certificado Obtenido"
                              className="p-2.5 bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-xl transition border border-amber-300"
                            >
                              <Award className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8 space-y-4">
              <BookOpen className="w-12 h-12 text-slate-300 mx-auto" />
              <div>
                <h3 className="text-base font-bold text-slate-800">Aún no estás inscrito en ningún curso</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Explora el catálogo disponible de nuestro centro de capacitación e inscríbete para comenzar tu formación.
                </p>
              </div>
              <button
                onClick={onOpenCatalog}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs"
              >
                Ver Catálogo de Cursos
              </button>
            </div>
          )}
        </div>
      )}

      {/* Subtab: Tasks & Exams */}
      {activeSubTab === 'tasks' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Tareas y Evaluaciones Asignadas
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Consulta las fechas límite, envía tus trabajos y revisa las notas de tus profesores.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Tasks list */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-amber-600" />
                <span>Mis Tareas Prácticas</span>
              </h3>

              <div className="space-y-3">
                {myTasks.map(task => {
                  const sub = taskSubmissions.find(s => s.taskId === task.id && s.studentId === currentUser.id);
                  const course = courses.find(c => c.id === task.courseId);

                  return (
                    <div key={task.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">
                            {course?.title}
                          </span>
                          <h4 className="font-bold text-slate-900 text-xs sm:text-sm mt-0.5">
                            {task.title}
                          </h4>
                        </div>
                        {sub ? (
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            sub.status === 'graded' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {sub.status === 'graded' ? `Nota: ${sub.score}/${task.maxScore}` : 'Entregado'}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            Pendiente
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2">
                        {task.instructions.replace(/###/g, '')}
                      </p>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
                        <span className="text-[11px] text-slate-500">
                          Entrega: {new Date(task.dueDate).toLocaleDateString('es-ES')}
                        </span>
                        <button
                          onClick={() => onSelectCourse(task.courseId)}
                          className="text-xs font-semibold text-blue-600 hover:text-blue-800"
                        >
                          Ir al Aula y Enviar →
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quizzes list */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Award className="w-4 h-4 text-purple-600" />
                <span>Exámenes y Evaluaciones en Línea</span>
              </h3>

              <div className="space-y-3">
                {quizzes.filter(q => myCourseIds.includes(q.courseId)).map(quiz => {
                  const attempt = quizAttempts.find(a => a.quizId === quiz.id && a.studentId === currentUser.id);
                  const course = courses.find(c => c.id === quiz.courseId);

                  return (
                    <div key={quiz.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wider block">
                            {course?.title}
                          </span>
                          <h4 className="font-bold text-slate-900 text-xs sm:text-sm mt-0.5">
                            {quiz.title}
                          </h4>
                        </div>
                        {attempt ? (
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            attempt.passed ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {attempt.passed ? `Aprobado (${attempt.score}/${attempt.maxScore})` : `No Aprobado (${attempt.score}/${attempt.maxScore})`}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-700">
                            Por rendir
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
                        <span className="text-[11px] text-slate-500">
                          {quiz.questions.length} preguntas • Tiempo: {quiz.timeLimitMinutes} min
                        </span>
                        <button
                          onClick={() => onSelectCourse(quiz.courseId)}
                          className="text-xs font-semibold text-purple-600 hover:text-purple-800"
                        >
                          Rendir Examen →
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subtab: Zoom Live Classes */}
      {activeSubTab === 'zoom' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Clases Virtuales en Vivo (Zoom)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Horarios, enlaces directos e información de acceso para tus sesiones sincrónicas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {myZoomSessions.map(session => {
              const course = courses.find(c => c.id === session.courseId);

              return (
                <div key={session.id} className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-2xs">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">
                        {course?.title}
                      </span>
                      <h3 className="font-bold text-slate-900 text-base mt-0.5">
                        {session.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Instructor: <strong className="text-slate-700">{session.instructorName}</strong>
                      </p>
                    </div>
                    <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-full">
                      Programada
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {session.description}
                  </p>

                  <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Fecha:</span>
                      <span className="font-bold text-slate-800">{session.date}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Hora:</span>
                      <span className="font-bold text-slate-800">{session.startTime} hrs</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Duración:</span>
                      <span className="font-bold text-slate-800">{session.durationMinutes} min</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-2">
                    <a
                      href={session.zoomLink}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition"
                    >
                      <Video className="w-4 h-4" />
                      <span>Ingresar a Zoom</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    <button
                      onClick={() => onOpenZoomModal(session)}
                      className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition border border-slate-200"
                    >
                      Ver Credenciales
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Subtab: Certificates */}
      {activeSubTab === 'certificates' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Mis Certificados Oficiales de Capacitación
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Certificados digitales emitidos por {centerSettings.name} con validación QR y código único.
            </p>
          </div>

          {myCertificates.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {myCertificates.map(cert => (
                <div key={cert.id} className="bg-white rounded-2xl border-2 border-amber-200 p-6 shadow-sm space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                        <Award className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">
                          Acreditación Oficial
                        </span>
                        <h3 className="font-bold text-slate-900 text-base leading-snug">
                          {cert.courseTitle}
                        </h3>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-100 space-y-1 text-xs text-slate-700">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Estudiante:</span>
                      <span className="font-bold text-slate-900">{cert.studentName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Duración Académica:</span>
                      <span className="font-semibold text-slate-800">{cert.durationHours} horas pedagógicas</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Fecha de Emisión:</span>
                      <span className="font-semibold text-slate-800">{cert.issueDate}</span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-amber-200/60">
                      <span className="text-slate-500">Código de Verificación:</span>
                      <code className="font-mono font-bold text-amber-900">{cert.certificateCode}</code>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-2">
                    <button
                      onClick={() => setActiveCertificateModal(cert)}
                      className="flex-1 py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition"
                    >
                      <Award className="w-4 h-4" />
                      <span>Visualizar Diploma</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8 space-y-4">
              <Award className="w-12 h-12 text-slate-300 mx-auto" />
              <div>
                <h3 className="text-base font-bold text-slate-800">Aún no has completado un curso</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Completa el 100% de las lecciones, tareas y exámenes de tus cursos inscritos para que el sistema genere automáticamente tu certificado oficial en PDF.
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
