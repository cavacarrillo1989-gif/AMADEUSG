import React, { useState } from 'react';
import {
  X,
  Video,
  Mic,
  MicOff,
  VideoOff,
  Users,
  MessageSquare,
  Share2,
  ExternalLink,
  PhoneOff,
  CheckCircle,
  Copy
} from 'lucide-react';
import { ZoomSession } from '../types';

interface ZoomMeetingModalProps {
  session: ZoomSession | null;
  onClose: () => void;
}

export const ZoomMeetingModal: React.FC<ZoomMeetingModalProps> = ({ session, onClose }) => {
  if (!session) return null;

  const [inCall, setInCall] = useState(false);
  const [micOn, setMicOn] = useState(true);
  const [cameraOn, setCameraOn] = useState(true);
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(session.zoomLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl max-w-2xl w-full text-white overflow-hidden">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Video className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm leading-tight">{session.title}</h3>
              <p className="text-[11px] text-slate-400">Sala de Clase Virtual Sincrónica</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!inCall ? (
          <div className="p-6 sm:p-8 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                Sesión Programada
              </span>
              <h2 className="text-xl font-bold">{session.title}</h2>
              <p className="text-xs text-slate-300 leading-relaxed">{session.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-slate-800/80 p-4 rounded-2xl border border-slate-700 text-xs">
              <div>
                <span className="text-slate-400 block mb-0.5">Fecha y Hora:</span>
                <span className="font-bold text-white text-sm">{session.date} - {session.startTime} hrs</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5">Duración Estimada:</span>
                <span className="font-bold text-white text-sm">{session.durationMinutes} minutos</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5">ID de la Reunión Zoom:</span>
                <code className="font-mono bg-black/40 px-2 py-1 rounded text-white font-bold text-xs inline-block">
                  {session.meetingId}
                </code>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5">Contraseña de Acceso:</span>
                <code className="font-mono bg-black/40 px-2 py-1 rounded text-white font-bold text-xs inline-block">
                  {session.passcode}
                </code>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <a
                href={session.zoomLink}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition"
              >
                <Video className="w-4 h-4" />
                <span>Abrir en Zoom App / Navegador</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                onClick={() => setInCall(true)}
                className="px-5 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition"
              >
                <span>Simular Ingreso a la Sala</span>
              </button>

              <button
                onClick={handleCopyLink}
                className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-700"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copied ? 'Copiado' : 'Copiar Link'}</span>
              </button>
            </div>
          </div>
        ) : (
          /* Live Conference Simulation view */
          <div className="p-6 space-y-4">
            <div className="aspect-video bg-black rounded-2xl overflow-hidden relative flex items-center justify-center border border-slate-800">
              {/* Camera view simulation */}
              {cameraOn ? (
                <div className="text-center space-y-2">
                  <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center mx-auto text-2xl font-bold shadow-lg">
                    {session.instructorName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">{session.instructorName} (Docente Titular)</h4>
                    <span className="text-[11px] text-emerald-400 font-medium">Transmitiendo en vivo • Audio HD</span>
                  </div>
                </div>
              ) : (
                <div className="text-slate-500 text-xs">Cámara apagada</div>
              )}

              {/* Live Tag */}
              <div className="absolute top-3 left-3 bg-red-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                EN DIRECTO
              </div>
            </div>

            {/* Conference control bar */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setMicOn(!micOn)}
                className={`p-3 rounded-full ${micOn ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-red-600 text-white'}`}
              >
                {micOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              </button>
              <button
                onClick={() => setCameraOn(!cameraOn)}
                className={`p-3 rounded-full ${cameraOn ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-red-600 text-white'}`}
              >
                {cameraOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
              </button>
              <button
                onClick={() => alert('Abriendo chat de la sesión en vivo')}
                className="p-3 rounded-full bg-slate-800 text-white hover:bg-slate-700"
              >
                <MessageSquare className="w-4 h-4" />
              </button>
              <button
                onClick={() => setInCall(false)}
                className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs flex items-center gap-2"
              >
                <PhoneOff className="w-4 h-4" />
                <span>Finalizar Llamada</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
