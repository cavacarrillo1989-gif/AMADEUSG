import React, { useState } from 'react';
import { Phone, X, Send, Check, Copy } from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';

export const WhatsAppWidget: React.FC = () => {
  const { centerSettings } = usePlatform();
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [userMsg, setUserMsg] = useState('');

  const phoneDisplay = '0997342614';
  const internationalPhone = '593997342614';

  const defaultText = 'Hola Centro de Capacitación Internacional Amadeus G., deseo información sobre cursos y formas de pago.';

  const handleSend = (customText?: string) => {
    const textToSend = customText || userMsg || defaultText;
    const url = `https://wa.me/${internationalPhone}?text=${encodeURIComponent(textToSend)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(phoneDisplay);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Expanded Chat Popover */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-fadeIn">
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-bold text-base shadow-sm">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <span className="w-3 h-3 rounded-full bg-emerald-300 border-2 border-emerald-700 absolute bottom-0 right-0"></span>
              </div>
              <div>
                <h4 className="font-bold text-xs sm:text-sm leading-tight">
                  {centerSettings.name}
                </h4>
                <span className="text-[11px] text-emerald-100 flex items-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-ping"></span>
                  WhatsApp Oficial • En Línea
                </span>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 bg-slate-50 space-y-3 text-xs">
            {/* Direct Number Badge */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-200 flex items-center justify-between shadow-2xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block leading-none">Contacto Directo:</span>
                  <span className="font-mono font-bold text-slate-900 text-xs">{phoneDisplay}</span>
                </div>
              </div>
              <button
                onClick={handleCopyPhone}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-semibold flex items-center gap-1 transition"
                title="Copiar número"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copiado' : 'Copiar'}</span>
              </button>
            </div>

            {/* Chat Bubble */}
            <div className="bg-white p-3.5 rounded-2xl rounded-tl-none border border-slate-200 text-slate-700 shadow-2xs space-y-1.5">
              <div className="font-bold text-emerald-800 text-[11px]">Asesor de Admisiones Amadeus G.</div>
              <p className="leading-relaxed">
                ¡Hola! 👋 ¿Tienes preguntas sobre el temario, pasarela de pago o deseas matricularte? Escríbenos directamente y te responderemos de inmediato.
              </p>
              <div className="text-[9px] text-slate-400 text-right">Hoy • Horario de Atención Activo</div>
            </div>

            {/* Quick Topic Chips */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Consultas Rápidas Frecuentes:
              </span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => handleSend('Hola, deseo conocer el catálogo completo de cursos y costos.')}
                  className="px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-800 text-slate-600 rounded-xl border border-slate-200 text-[11px] transition text-left shadow-2xs"
                >
                  🎓 Ver catálogo y costos
                </button>
                <button
                  type="button"
                  onClick={() => handleSend('Hola, necesito ayuda con la pasarela de pago para matricularme.')}
                  className="px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-800 text-slate-600 rounded-xl border border-slate-200 text-[11px] transition text-left shadow-2xs"
                >
                  💳 Asistencia de pago
                </button>
                <button
                  type="button"
                  onClick={() => handleSend('Hola, deseo solicitar factura con RUC para mi empresa.')}
                  className="px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-800 text-slate-600 rounded-xl border border-slate-200 text-[11px] transition text-left shadow-2xs"
                >
                  🧾 Facturación con RUC
                </button>
              </div>
            </div>
          </div>

          {/* Footer Input */}
          <div className="p-3 bg-white border-t border-slate-200 space-y-2">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={userMsg}
                onChange={e => setUserMsg(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') handleSend();
                }}
                placeholder="Escribe tu mensaje aquí..."
                className="flex-1 text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={() => handleSend()}
                className="p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition shrink-0"
                title="Enviar por WhatsApp"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => handleSend()}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Abrir WhatsApp ({phoneDisplay})</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-3 rounded-full shadow-xl hover:shadow-2xl transition transform hover:-translate-y-0.5"
        aria-label="Contactar por WhatsApp"
      >
        <div className="relative">
          <Phone className="w-6 h-6" />
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 absolute -top-0.5 -right-0.5 animate-pulse"></span>
        </div>
        <div className="text-left leading-tight hidden sm:block">
          <span className="text-[10px] uppercase font-bold text-emerald-200 block tracking-wider">
            WhatsApp Asesoría
          </span>
          <span className="text-xs font-black">{phoneDisplay}</span>
        </div>
      </button>
    </div>
  );
};
