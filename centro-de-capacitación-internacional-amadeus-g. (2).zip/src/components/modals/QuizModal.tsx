import React, { useState, useEffect } from 'react';
import {
  X,
  HelpCircle,
  Clock,
  Award,
  Plus,
  Trash2,
  CheckCircle2,
  Check
} from 'lucide-react';
import { Quiz, QuizQuestion, CourseModule } from '../../types';
import { usePlatform } from '../../context/PlatformContext';

interface QuizModalProps {
  courseId: string;
  defaultModuleId?: string;
  quiz: Quiz | null;
  isOpen: boolean;
  onClose: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  courseId,
  defaultModuleId,
  quiz,
  isOpen,
  onClose
}) => {
  const { modules, createQuiz, updateQuiz } = usePlatform();
  const courseModules = modules.filter(m => m.courseId === courseId);

  const [title, setTitle] = useState('');
  const [moduleId, setModuleId] = useState('');
  const [description, setDescription] = useState('');
  const [timeLimitMinutes, setTimeLimitMinutes] = useState(20);
  const [passingScore, setPassingScore] = useState(14);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);

  useEffect(() => {
    if (quiz) {
      setTitle(quiz.title || '');
      setModuleId(quiz.moduleId || defaultModuleId || courseModules[0]?.id || '');
      setDescription(quiz.description || '');
      setTimeLimitMinutes(quiz.timeLimitMinutes || 20);
      setPassingScore(quiz.passingScore || 14);
      setQuestions(quiz.questions || []);
    } else {
      setTitle('');
      setModuleId(defaultModuleId || courseModules[0]?.id || '');
      setDescription('Evaluación modular para comprobar los conocimientos adquiridos.');
      setTimeLimitMinutes(20);
      setPassingScore(14);
      setQuestions([
        {
          id: `q_${Date.now()}_1`,
          question: '¿Cuál es el propósito fundamental de este módulo?',
          options: [
            'Establecer el marco teórico y metodológico de aplicación',
            'Finalizar el proyecto sin planificación previa',
            'Omitir las etapas de control y calidad',
            'Ninguna de las anteriores'
          ],
          correctOptionIndex: 0,
          points: 5,
          explanation: 'El marco teórico y metodológico asegura el rigor y la trazabilidad del proceso.'
        },
        {
          id: `q_${Date.now()}_2`,
          question: '¿Qué herramienta permite supervisar el avance continuo?',
          options: [
            'Tablero visual de seguimiento y métricas de desempeño',
            'Ignorar los reportes semanales',
            'Delegar sin criterios de aceptación',
            'Documentación incompleta'
          ],
          correctOptionIndex: 0,
          points: 5,
          explanation: 'Los tableros visuales y métricas ofrecen visibilidad transparente en tiempo real.'
        }
      ]);
    }
  }, [quiz, defaultModuleId, courseId, isOpen]);

  if (!isOpen) return null;

  const handleAddQuestion = () => {
    const newQ: QuizQuestion = {
      id: `q_${Date.now()}_${questions.length + 1}`,
      question: '',
      options: ['Opción A', 'Opción B', 'Opción C', 'Opción D'],
      correctOptionIndex: 0,
      points: 5,
      explanation: ''
    };
    setQuestions(prev => [...prev, newQ]);
  };

  const handleRemoveQuestion = (qId: string) => {
    if (questions.length <= 1) {
      alert('La evaluación debe contener al menos una pregunta.');
      return;
    }
    setQuestions(prev => prev.filter(q => q.id !== qId));
  };

  const handleQuestionChange = (qId: string, field: keyof QuizQuestion, val: any) => {
    setQuestions(prev => prev.map(q => q.id === qId ? { ...q, [field]: val } : q));
  };

  const handleOptionChange = (qId: string, optIdx: number, text: string) => {
    setQuestions(prev => prev.map(q => {
      if (q.id === qId) {
        const newOpts = [...q.options];
        newOpts[optIdx] = text;
        return { ...q, options: newOpts };
      }
      return q;
    }));
  };

  const totalPoints = questions.reduce((acc, q) => acc + (Number(q.points) || 0), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !courseId) return;

    if (questions.some(q => !q.question.trim())) {
      alert('Por favor completa el texto de todas las preguntas.');
      return;
    }

    const payload = {
      courseId,
      moduleId: moduleId || undefined,
      title: title.trim(),
      description: description.trim(),
      timeLimitMinutes: Number(timeLimitMinutes) || 20,
      passingScore: Number(passingScore) || Math.round(totalPoints * 0.7),
      questions
    };

    if (quiz) {
      updateQuiz(quiz.id, payload);
    } else {
      createQuiz(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-8">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                {quiz ? 'Editar Examen / Evaluación' : 'Crear Nueva Evaluación del Módulo'}
              </h3>
              <p className="text-xs text-slate-500">
                Diseña el cuestionario con preguntas de opción múltiple, tiempo y puntaje mínimo.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Título y Módulo */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Título del Examen / Evaluación *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Ej: Examen Parcial: Evaluación de Competencias del Módulo 1"
                className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Módulo Asociado
              </label>
              <select
                value={moduleId}
                onChange={e => setModuleId(e.target.value)}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 bg-white font-medium"
              >
                <option value="">General del Curso</option>
                {courseModules.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Tiempo y Puntaje */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-purple-600" />
                Tiempo Límite (minutos)
              </label>
              <input
                type="number"
                min="5"
                max="180"
                value={timeLimitMinutes}
                onChange={e => setTimeLimitMinutes(Number(e.target.value))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-purple-600" />
                Puntaje Mínimo Aprobatorio
              </label>
              <input
                type="number"
                min="1"
                max="100"
                value={passingScore}
                onChange={e => setPassingScore(Number(e.target.value))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
              />
            </div>

            <div className="bg-purple-50 p-2.5 rounded-xl border border-purple-200 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-bold text-purple-800 tracking-wider">
                Puntaje Acumulado
              </span>
              <span className="text-lg font-black text-purple-950">
                {totalPoints} puntos totales
              </span>
            </div>
          </div>

          {/* Descripción */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Instrucciones Previas para el Alumno
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Instrucciones sobre el número de intentos, tiempo y requisitos de aprobación..."
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
            />
          </div>

          {/* Preguntas Builder */}
          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/60 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Preguntas del Examen ({questions.length})
                </h4>
                <p className="text-[11px] text-slate-500">
                  Marca el botón de radio junto a la alternativa correcta.
                </p>
              </div>

              <button
                type="button"
                onClick={handleAddQuestion}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-2xs transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Agregar Pregunta</span>
              </button>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
              {questions.map((q, qIdx) => (
                <div key={q.id} className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-2xs">
                  <div className="flex items-start justify-between gap-3">
                    <span className="text-xs font-black text-purple-700 pt-1">
                      Pregunta #{qIdx + 1}
                    </span>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <label className="text-[10px] font-bold text-slate-500">Puntos:</label>
                        <input
                          type="number"
                          min="1"
                          max="20"
                          value={q.points}
                          onChange={e => handleQuestionChange(q.id, 'points', Number(e.target.value))}
                          className="w-14 text-xs p-1 rounded-lg border border-slate-300 text-center font-bold"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveQuestion(q.id)}
                        className="p-1 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                        title="Eliminar pregunta"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <input
                    type="text"
                    required
                    value={q.question}
                    onChange={e => handleQuestionChange(q.id, 'question', e.target.value)}
                    placeholder="Escribe el enunciado de la pregunta aquí..."
                    className="w-full text-xs p-2 rounded-xl border border-slate-300 font-medium"
                  />

                  {/* Opciones */}
                  <div className="space-y-2 pt-1">
                    <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">
                      Alternativas (selecciona la correcta):
                    </span>
                    {q.options.map((opt, optIdx) => (
                      <div key={optIdx} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name={`correct_${q.id}`}
                          checked={q.correctOptionIndex === optIdx}
                          onChange={() => handleQuestionChange(q.id, 'correctOptionIndex', optIdx)}
                          className="text-purple-600 focus:ring-purple-500 w-4 h-4"
                        />
                        <input
                          type="text"
                          required
                          value={opt}
                          onChange={e => handleOptionChange(q.id, optIdx, e.target.value)}
                          placeholder={`Opción ${String.fromCharCode(65 + optIdx)}`}
                          className={`flex-1 text-xs p-2 rounded-lg border ${
                            q.correctOptionIndex === optIdx
                              ? 'border-purple-400 bg-purple-50/50 font-semibold text-purple-900'
                              : 'border-slate-300'
                          }`}
                        />
                      </div>
                    ))}
                  </div>

                  {/* Explicación didáctica */}
                  <div>
                    <input
                      type="text"
                      value={q.explanation}
                      onChange={e => handleQuestionChange(q.id, 'explanation', e.target.value)}
                      placeholder="Explicación o justificación pedagógica de la respuesta correcta (opcional)..."
                      className="w-full text-[11px] p-2 rounded-lg border border-slate-200 bg-slate-50 text-slate-600 italic"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs shadow-md transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{quiz ? 'Guardar Cambios del Examen' : 'Crear Examen'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
