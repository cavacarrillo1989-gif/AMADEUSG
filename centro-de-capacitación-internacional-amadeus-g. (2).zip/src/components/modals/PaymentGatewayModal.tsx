import React, { useState } from 'react';
import {
  X,
  CreditCard,
  Building2,
  Phone,
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  Upload,
  FileCheck,
  Copy,
  ExternalLink,
  DollarSign,
  Calendar,
  User,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { Course, PaymentMethod, PaymentTransaction } from '../../types';
import { usePlatform } from '../../context/PlatformContext';

interface PaymentGatewayModalProps {
  course: Course | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (courseId: string) => void;
}

export const PaymentGatewayModal: React.FC<PaymentGatewayModalProps> = ({
  course,
  isOpen,
  onClose,
  onSuccess
}) => {
  const { currentUser, processPayment, centerSettings } = usePlatform();

  const [activeTab, setActiveTab] = useState<PaymentMethod>('credit_card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedTransaction, setCompletedTransaction] = useState<PaymentTransaction | null>(null);
  const [copiedAccount, setCopiedAccount] = useState<string | null>(null);

  // Credit card form state
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState(currentUser?.name || '');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');

  // Bank transfer state
  const [selectedBank, setSelectedBank] = useState('Banco Pichincha');
  const [voucherFile, setVoucherFile] = useState<File | null>(null);
  const [transferRef, setTransferRef] = useState('');

  if (!isOpen || !course) return null;

  const finalPrice = course.discountPrice || course.price || 49;
  const regularPrice = course.price || (finalPrice + 20);
  const savings = regularPrice - finalPrice;

  const whatsappNumber = '0997342614';
  const whatsappUrl = `https://wa.me/593997342614?text=${encodeURIComponent(
    `Hola Centro de Capacitación Amadeus G., deseo información sobre la inscripción y pago del curso: "${course.title}" ($${finalPrice} USD). ¿Podrían brindarme asesoría?`
  )}`;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAccount(id);
    setTimeout(() => setCopiedAccount(null), 2500);
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 16);
    const formatted = val.replace(/(\d{4})(?=\d)/g, '$1 ');
    setCardNumber(formatted);
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (val.length >= 3) {
      val = `${val.slice(0, 2)}/${val.slice(2)}`;
    }
    setCardExpiry(val);
  };

  const handleCreditCardPay = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      const cleanNum = cardNumber.replace(/\s/g, '');
      const lastFour = cleanNum.slice(-4) || '8842';

      const tx = processPayment({
        courseId: course.id,
        amount: finalPrice,
        method: 'credit_card',
        cardLastFour: lastFour
      });

      setIsProcessing(false);
      setCompletedTransaction(tx);
    }, 1200);
  };

  const handleBankTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      const tx = processPayment({
        courseId: course.id,
        amount: finalPrice,
        method: 'bank_transfer',
        bankName: selectedBank,
        voucherFileName: voucherFile ? voucherFile.name : `Comprobante_${transferRef || 'Bancario'}.pdf`
      });

      setIsProcessing(false);
      setCompletedTransaction(tx);
    }, 1200);
  };

  const handlePayPalSubmit = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const tx = processPayment({
        courseId: course.id,
        amount: finalPrice,
        method: 'paypal'
      });
      setIsProcessing(false);
      setCompletedTransaction(tx);
    }, 1000);
  };

  const handleClose = () => {
    setCompletedTransaction(null);
    setIsProcessing(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 my-8 border border-slate-200">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-slate-900">
                  Pasarela de Pago Segura
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-emerald-200">
                  SSL 256-BIT
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {centerSettings.name}
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Successful Payment State */}
        {completedTransaction ? (
          <div className="space-y-6 text-center py-4 animate-fadeIn">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider bg-emerald-50 px-3 py-1 rounded-full">
                ¡Matrícula Confirmada y Pago Aprobado!
              </span>
              <h3 className="text-2xl font-black text-slate-900 mt-2">
                {course.title}
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                Tu acceso al aula virtual, lecciones en video, tareas, foros, exámenes y sesiones Zoom ya se encuentra 100% activo.
              </p>
            </div>

            {/* Receipt Summary Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 text-left text-xs space-y-3 max-w-lg mx-auto">
              <div className="flex justify-between pb-2 border-b border-slate-200 font-bold text-slate-700">
                <span>Comprobante de Pago Electrónico</span>
                <span className="text-blue-700 font-mono">{completedTransaction.receiptNumber}</span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-slate-600">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Estudiante:</span>
                  <span className="font-semibold text-slate-800">{currentUser.name}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Código Transacción:</span>
                  <span className="font-mono text-slate-800 font-semibold">{completedTransaction.transactionRef}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Método de Pago:</span>
                  <span className="font-semibold text-slate-800 capitalize">
                    {completedTransaction.method === 'credit_card' && `Tarjeta **** ${completedTransaction.cardLastFour}`}
                    {completedTransaction.method === 'bank_transfer' && `Transferencia (${completedTransaction.bankName})`}
                    {completedTransaction.method === 'paypal' && 'PayPal Express'}
                    {completedTransaction.method === 'whatsapp_advisor' && 'Asesor WhatsApp'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Monto Total:</span>
                  <span className="font-bold text-emerald-600 text-sm">${completedTransaction.amount} USD</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition"
              >
                <Phone className="w-4 h-4" />
                <span>Notificar por WhatsApp: {whatsappNumber}</span>
              </a>

              <button
                onClick={() => {
                  handleClose();
                  onSuccess(course.id);
                }}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition"
              >
                <span>Entrar al Aula Virtual Ahora</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Course Summary Banner */}
            <div className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-2xl p-4 sm:p-5 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md">
              <div className="flex items-center gap-3">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-16 h-16 rounded-xl object-cover border border-white/20 shrink-0"
                />
                <div>
                  <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider block">
                    {course.category} • {course.durationHours} Horas Lectivas
                  </span>
                  <h3 className="font-bold text-sm sm:text-base leading-tight text-white line-clamp-1">
                    {course.title}
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    Certificación Oficial con respaldo de {centerSettings.name}
                  </p>
                </div>
              </div>

              {/* Price display */}
              <div className="text-right shrink-0 bg-white/10 px-4 py-2 rounded-xl border border-white/10 w-full sm:w-auto flex sm:flex-col justify-between items-center sm:items-end">
                <div className="text-left sm:text-right">
                  <span className="text-[10px] text-slate-300 line-through mr-1 sm:mr-0 sm:block">
                    ${regularPrice} USD
                  </span>
                  <div className="text-xl font-black text-amber-400">
                    ${finalPrice} <span className="text-xs text-white font-normal">USD</span>
                  </div>
                </div>
                {savings > 0 && (
                  <span className="bg-emerald-500/30 text-emerald-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-emerald-400/30">
                    Ahorras ${savings} USD
                  </span>
                )}
              </div>
            </div>

            {/* Payment Method Selector Tabs */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-2">
                Selecciona tu Método de Pago Preferido:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('credit_card')}
                  className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition ${
                    activeTab === 'credit_card'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-800 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-blue-600" />
                  <span>Tarjeta Déb./Créd.</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('bank_transfer')}
                  className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition ${
                    activeTab === 'bank_transfer'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-800 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Building2 className="w-5 h-5 text-indigo-600" />
                  <span>Transferencia / Dep.</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('paypal')}
                  className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition ${
                    activeTab === 'paypal'
                      ? 'border-blue-600 bg-blue-50/70 text-blue-800 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <DollarSign className="w-5 h-5 text-sky-600" />
                  <span>PayPal / Digital</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('whatsapp_advisor')}
                  className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition ${
                    activeTab === 'whatsapp_advisor'
                      ? 'border-emerald-600 bg-emerald-50/70 text-emerald-800 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <Phone className="w-5 h-5 text-emerald-600" />
                  <span>WhatsApp: {whatsappNumber}</span>
                </button>
              </div>
            </div>

            {/* TAB 1: Credit / Debit Card */}
            {activeTab === 'credit_card' && (
              <form onSubmit={handleCreditCardPay} className="space-y-4 animate-fadeIn">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-semibold text-slate-700">Tarjetas aceptadas:</span>
                    <div className="flex items-center gap-1 text-[10px] font-bold text-slate-600">
                      <span className="px-1.5 py-0.5 bg-blue-100 text-blue-800 rounded">VISA</span>
                      <span className="px-1.5 py-0.5 bg-amber-100 text-amber-800 rounded">MASTERCARD</span>
                      <span className="px-1.5 py-0.5 bg-cyan-100 text-cyan-800 rounded">AMEX</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Número de Tarjeta:
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        placeholder="4500 0000 0000 0000"
                        value={cardNumber}
                        onChange={handleCardNumberChange}
                        className="w-full text-xs font-mono p-2.5 pl-9 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                      <CreditCard className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Nombre del Titular (tal como figura en la tarjeta):
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        placeholder="Ej: JUAN CARLOS PÉREZ"
                        value={cardHolder}
                        onChange={e => setCardHolder(e.target.value.toUpperCase())}
                        className="w-full text-xs p-2.5 pl-9 rounded-xl border border-slate-300 uppercase focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Expiración (MM/AA):
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="12/28"
                        value={cardExpiry}
                        onChange={handleExpiryChange}
                        className="w-full text-xs font-mono p-2.5 rounded-xl border border-slate-300 text-center focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Código CVV / CVC:
                      </label>
                      <div className="relative">
                        <input
                          type="password"
                          required
                          maxLength={4}
                          placeholder="•••"
                          value={cardCvv}
                          onChange={e => setCardCvv(e.target.value.replace(/\D/g, ''))}
                          className="w-full text-xs font-mono p-2.5 rounded-xl border border-slate-300 text-center focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                        <ShieldCheck className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-emerald-600" />
                    Transacción cifrada y segura con tokenización directa
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-bold rounded-xl text-sm shadow-md flex items-center justify-center gap-2 transition"
                >
                  {isProcessing ? (
                    <span>Procesando pago seguro...</span>
                  ) : (
                    <>
                      <span>Pagar y Activar Matrícula (${finalPrice} USD)</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* TAB 2: Bank Transfer */}
            {activeTab === 'bank_transfer' && (
              <form onSubmit={handleBankTransferSubmit} className="space-y-4 animate-fadeIn">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">
                      Cuentas Bancarias Oficiales de Recaudación:
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      RUC: 1792834019001
                    </span>
                  </div>

                  {/* Bank Accounts list */}
                  <div className="space-y-2">
                    {/* Pichincha */}
                    <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-900">Banco Pichincha</div>
                        <div className="text-[11px] text-slate-500">
                          Cta. Corriente: <span className="font-mono font-bold text-slate-800">2100845912</span>
                        </div>
                        <div className="text-[10px] text-slate-400">Titular: Centro de Capacitación Amadeus G.</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopy('2100845912', 'pichincha')}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition"
                      >
                        {copiedAccount === 'pichincha' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedAccount === 'pichincha' ? 'Copiado' : 'Copiar'}</span>
                      </button>
                    </div>

                    {/* Guayaquil */}
                    <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-900">Banco Guayaquil</div>
                        <div className="text-[11px] text-slate-500">
                          Cta. Ahorros: <span className="font-mono font-bold text-slate-800">0034928174</span>
                        </div>
                        <div className="text-[10px] text-slate-400">Titular: Centro de Capacitación Amadeus G.</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopy('0034928174', 'guayaquil')}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition"
                      >
                        {copiedAccount === 'guayaquil' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedAccount === 'guayaquil' ? 'Copiado' : 'Copiar'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Banco Emisor:
                      </label>
                      <select
                        value={selectedBank}
                        onChange={e => setSelectedBank(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
                      >
                        <option value="Banco Pichincha">Banco Pichincha</option>
                        <option value="Banco Guayaquil">Banco Guayaquil</option>
                        <option value="Banco del Pacífico">Banco del Pacífico</option>
                        <option value="Produbanco">Produbanco</option>
                        <option value="Otro Banco / Cooperativa">Otro Banco / Cooperativa</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        N° de Comprobante / Referencia:
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Ej: 8941203"
                        value={transferRef}
                        onChange={e => setTransferRef(e.target.value)}
                        className="w-full text-xs font-mono p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Adjuntar Comprobante o Captura (Opcional):
                    </label>
                    <div className="border-2 border-dashed border-slate-300 rounded-xl p-3 text-center bg-white hover:bg-slate-50 transition cursor-pointer relative">
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={e => setVoucherFile(e.target.files?.[0] || null)}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                      <div className="flex items-center justify-center gap-2 text-xs text-slate-600">
                        {voucherFile ? (
                          <>
                            <FileCheck className="w-4 h-4 text-emerald-600" />
                            <span className="font-bold text-emerald-700 truncate max-w-[240px]">{voucherFile.name}</span>
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 text-slate-400" />
                            <span>Haz clic para subir foto o PDF del comprobante</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition"
                  >
                    <Phone className="w-4 h-4" />
                    <span>Enviar Comprobante al WhatsApp ({whatsappNumber})</span>
                  </a>

                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition"
                  >
                    {isProcessing ? 'Validando...' : 'Registrar Pago y Activar'}
                  </button>
                </div>
              </form>
            )}

            {/* TAB 3: PayPal */}
            {activeTab === 'paypal' && (
              <div className="space-y-4 animate-fadeIn text-center">
                <div className="bg-sky-50/70 border border-sky-200 rounded-2xl p-6 space-y-3">
                  <div className="w-12 h-12 bg-sky-100 text-sky-600 rounded-2xl flex items-center justify-center mx-auto">
                    <DollarSign className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Checkout Internacional con PayPal
                  </h4>
                  <p className="text-xs text-slate-600 max-w-sm mx-auto">
                    Paga de forma rápida y segura en dólares con tu saldo de cuenta PayPal o cualquier tarjeta internacional autorizada.
                  </p>
                  <div className="text-xl font-black text-slate-900 pt-1">
                    Total a Pagar: <span className="text-blue-600">${finalPrice} USD</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handlePayPalSubmit}
                  disabled={isProcessing}
                  className="w-full py-3 bg-[#0070BA] hover:bg-[#005ea6] text-white font-bold rounded-xl text-sm shadow-md flex items-center justify-center gap-2 transition"
                >
                  {isProcessing ? 'Conectando con PayPal...' : 'Continuar con PayPal'}
                </button>
              </div>
            )}

            {/* TAB 4: WhatsApp Advisor Direct */}
            {activeTab === 'whatsapp_advisor' && (
              <div className="space-y-4 animate-fadeIn">
                <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        Atención Personalizada e Inscripciones por WhatsApp
                      </h4>
                      <p className="text-xs text-slate-600">
                        Número Oficial Directo: <span className="font-black text-emerald-800 text-sm">{whatsappNumber}</span>
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    Si requieres coordinar el pago mediante <strong>facturación corporativa con RUC</strong>, facilidades de pago en cuotas, depósito físico en ventanilla, o necesitas asistencia directa de un asesor académico:
                  </p>

                  <div className="bg-white p-3 rounded-xl border border-emerald-100 text-xs text-slate-700 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Teléfono / WhatsApp Asesoría:</span>
                      <span className="font-mono font-black text-slate-900 text-sm">{whatsappNumber}</span>
                      <span className="text-[10px] text-emerald-700 ml-2 font-medium">Línea Activa</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(whatsappNumber, 'wsp')}
                      className="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition"
                    >
                      {copiedAccount === 'wsp' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedAccount === 'wsp' ? 'Copiado' : 'Copiar'}</span>
                    </button>
                  </div>
                </div>

                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm shadow-md flex items-center justify-center gap-2 transition"
                >
                  <Phone className="w-4 h-4" />
                  <span>Abrir Conversación en WhatsApp ({whatsappNumber})</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
