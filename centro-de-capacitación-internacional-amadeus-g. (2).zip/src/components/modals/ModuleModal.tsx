import React, { useState, useEffect } from 'react';
import { X, Layers, Check } from 'lucide-react';
import { CourseModule } from '../../types';
import { usePlatform } from '../../context/PlatformContext';

interface ModuleModalProps {
  courseId: string;
  module: CourseModule | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ModuleModal: React.FC<ModuleModalProps> = ({
  courseId,
  module,
  isOpen,
  onClose
}) => {
  const { createModule, updateModule, modules } = usePlatform();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [order, setOrder] = useState(1);

  useEffect(() => {
    if (module) {
      setTitle(module.title || '');
      setDescription(module.description || '');
      setOrder(module.order || 1);
    } else {
      const currentCount = modules.filter(m => m.courseId === courseId).length;
      setTitle(`Módulo ${currentCount + 1}: `);
      setDescription('');
      setOrder(currentCount + 1);
    }
  }, [module, courseId, modules, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !courseId) return;

    if (module) {
      updateModule(module.id, {
        title: title.trim(),
        description: description.trim(),
        order: Number(order) || 1
      });
    } else {
      createModule({
        courseId,
        title: title.trim(),
        description: description.trim(),
        order: Number(order) || 1
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                {module ? 'Editar Módulo de Clase' : 'Nuevo Módulo de Clase'}
              </h3>
              <p className="text-xs text-slate-500">
                Organiza las lecciones, evaluaciones y materiales didácticos.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Título del Módulo *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Ej: Módulo 1: Fundamentos y Metodologías Ágiles"
              className="w-full text-sm p-3 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Orden de Visualización
            </label>
            <input
              type="number"
              min="1"
              max="50"
              value={order}
              onChange={e => setOrder(Number(e.target.value))}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Descripción u Objetivos del Módulo
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe los temas centrales que se abordarán en este módulo..."
              className="w-full text-xs p-3 rounded-xl border border-slate-300 leading-relaxed focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{module ? 'Guardar Cambios' : 'Crear Módulo'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
