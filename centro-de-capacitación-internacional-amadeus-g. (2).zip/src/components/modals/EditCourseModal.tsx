import React, { useState, useEffect } from 'react';
import { X, BookOpen, Clock, Award, User, Tag, Image, Check } from 'lucide-react';
import { Course, User as UserType } from '../../types';
import { usePlatform } from '../../context/PlatformContext';

interface EditCourseModalProps {
  course: Course | null;
  isOpen: boolean;
  onClose: () => void;
}

export const EditCourseModal: React.FC<EditCourseModalProps> = ({
  course,
  isOpen,
  onClose
}) => {
  const { users, updateCourse } = usePlatform();
  const instructors = users.filter(u => u.role === 'instructor');

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [category, setCategory] = useState('Tecnología');
  const [level, setLevel] = useState<'Básico' | 'Intermedio' | 'Avanzado'>('Intermedio');
  const [durationHours, setDurationHours] = useState(40);
  const [instructorId, setInstructorId] = useState('');
  const [image, setImage] = useState('');
  const [status, setStatus] = useState<'published' | 'draft' | 'archived'>('published');
  const [passingScorePercent, setPassingScorePercent] = useState(70);

  useEffect(() => {
    if (course) {
      setTitle(course.title || '');
      setDescription(course.description || '');
      setShortDescription(course.shortDescription || '');
      setCategory(course.category || 'Tecnología');
      setLevel(course.level || 'Intermedio');
      setDurationHours(course.durationHours || 40);
      setInstructorId(course.instructorId || instructors[0]?.id || '');
      setImage(course.image || '');
      setStatus(course.status || 'published');
      setPassingScorePercent(course.passingScorePercent || 70);
    }
  }, [course]);

  if (!isOpen || !course) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    updateCourse(course.id, {
      title: title.trim(),
      description: description.trim(),
      shortDescription: shortDescription.trim() || description.substring(0, 120),
      category,
      level,
      durationHours: Number(durationHours) || 40,
      instructorId: instructorId || instructors[0]?.id || '',
      image: image.trim() || course.image,
      status,
      passingScorePercent: Number(passingScorePercent) || 70
    });

    onClose();
  };

  const sampleImages = [
    { label: 'Gestión y Proyectos', url: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&auto=format&fit=crop&q=80' },
    { label: 'Tecnología y AI', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80' },
    { label: 'Finanzas y Datos', url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80' },
    { label: 'Educación y Liderazgo', url: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800&auto=format&fit=crop&q=80' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-8">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Editar Información del Curso
              </h3>
              <p className="text-xs text-slate-500">
                Actualiza los datos curriculares, docente a cargo y configuración académica.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Título */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Título Oficial del Curso *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Ej: Especialización Internacional en Gestión de Proyectos Ágiles"
              className="w-full text-sm p-3 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Categoría, Nivel y Horas */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-blue-600" />
                Categoría
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white"
              >
                <option value="Tecnología">Tecnología</option>
                <option value="Gestión & Negocios">Gestión & Negocios</option>
                <option value="Finanzas">Finanzas</option>
                <option value="Salud">Salud</option>
                <option value="Derecho & Normativa">Derecho & Normativa</option>
                <option value="Habilidades Blandas">Habilidades Blandas</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-blue-600" />
                Nivel Académico
              </label>
              <select
                value={level}
                onChange={e => setLevel(e.target.value as any)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white"
              >
                <option value="Básico">Básico</option>
                <option value="Intermedio">Intermedio</option>
                <option value="Avanzado">Avanzado</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                Horas Lectivas
              </label>
              <input
                type="number"
                min="1"
                max="500"
                value={durationHours}
                onChange={e => setDurationHours(Number(e.target.value))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          {/* Docente Asignado y Estado */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-blue-600" />
                Docente / Instructor Asignado *
              </label>
              <select
                value={instructorId}
                onChange={e => setInstructorId(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white font-medium"
              >
                {instructors.map(inst => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.title || 'Docente'})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Estado del Curso
              </label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as any)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white font-medium"
              >
                <option value="published">Publicado (Visible en el Aula)</option>
                <option value="draft">Borrador (En preparación)</option>
                <option value="archived">Archivado</option>
              </select>
            </div>
          </div>

          {/* Descripción corta */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Descripción Breve (Resumen para la tarjeta)
            </label>
            <input
              type="text"
              value={shortDescription}
              onChange={e => setShortDescription(e.target.value)}
              placeholder="Resumen en una línea del curso..."
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
            />
          </div>

          {/* Descripción completa */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Descripción Curricular Completa *
            </label>
            <textarea
              rows={4}
              required
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Detalla los objetivos de aprendizaje, competencias y perfil de egreso..."
              className="w-full text-xs p-3 rounded-xl border border-slate-300 leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Imagen de Portada */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Image className="w-3.5 h-3.5 text-blue-600" />
                URL de Imagen de Portada
              </span>
              <span className="text-[10px] text-slate-500 font-normal">URL directa HTTPS</span>
            </label>
            <input
              type="url"
              value={image}
              onChange={e => setImage(e.target.value)}
              placeholder="https://images.unsplash.com/..."
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-mono"
            />
            {/* Quick image selection pills */}
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <span className="text-[10px] text-slate-500 font-semibold">Predefinidas:</span>
              {sampleImages.map((s, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => setImage(s.url)}
                  className="px-2 py-0.5 rounded-lg text-[10px] bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-800 border border-slate-200 transition"
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Botones de acción */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-md transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Guardar Cambios del Curso</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
