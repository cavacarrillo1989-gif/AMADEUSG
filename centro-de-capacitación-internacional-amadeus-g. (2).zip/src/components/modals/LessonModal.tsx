import React, { useState, useEffect } from 'react';
import {
  X,
  BookOpen,
  Video,
  FileText,
  CheckSquare,
  HelpCircle,
  Link,
  Plus,
  Trash2,
  Upload,
  ExternalLink,
  Presentation,
  Paperclip,
  Check,
  Calendar
} from 'lucide-react';
import { Lesson, LessonType, LessonResource, ResourceType, CourseModule, Task, Quiz, ZoomSession } from '../../types';
import { usePlatform } from '../../context/PlatformContext';

interface LessonModalProps {
  courseId: string;
  moduleId?: string;
  lesson: Lesson | null;
  isOpen: boolean;
  onClose: () => void;
}

export const LessonModal: React.FC<LessonModalProps> = ({
  courseId,
  moduleId: defaultModuleId,
  lesson,
  isOpen,
  onClose
}) => {
  const {
    modules,
    tasks,
    quizzes,
    zoomSessions,
    createLesson,
    updateLesson,
    createZoomSession
  } = usePlatform();

  const courseModules = modules.filter(m => m.courseId === courseId);
  const courseTasks = tasks.filter(t => t.courseId === courseId);
  const courseQuizzes = quizzes.filter(q => q.courseId === courseId);
  const courseZoomSessions = zoomSessions.filter(z => z.courseId === courseId);

  // Lesson basic fields
  const [title, setTitle] = useState('');
  const [selectedModuleId, setSelectedModuleId] = useState('');
  const [lessonType, setLessonType] = useState<LessonType>('video');
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [description, setDescription] = useState('');
  const [order, setOrder] = useState(1);

  // Type-specific fields
  const [videoUrl, setVideoUrl] = useState('https://www.youtube.com/embed/502ILHjX9EE');
  const [documentContent, setDocumentContent] = useState('');
  const [linkedTaskId, setLinkedTaskId] = useState('');
  const [linkedQuizId, setLinkedQuizId] = useState('');
  const [linkedZoomId, setLinkedZoomId] = useState('');

  // Zoom quick fields if creating zoom lesson
  const [zoomDate, setZoomDate] = useState('2026-09-28');
  const [zoomTime, setZoomTime] = useState('19:30');
  const [zoomMeetingId, setZoomMeetingId] = useState('849 2048 1023');
  const [zoomPasscode, setZoomPasscode] = useState('AMADEUS2026');
  const [zoomLink, setZoomLink] = useState('https://zoom.us/j/84920481023');

  // Didactic materials / Resources list
  const [resources, setResources] = useState<LessonResource[]>([]);
  
  // New resource input state
  const [newResTitle, setNewResTitle] = useState('');
  const [newResType, setNewResType] = useState<ResourceType>('pdf');
  const [newResUrl, setNewResUrl] = useState('');
  const [newResSize, setNewResSize] = useState('');
  const [showAddResForm, setShowAddResForm] = useState(false);

  useEffect(() => {
    if (lesson) {
      setTitle(lesson.title || '');
      setSelectedModuleId(lesson.moduleId || defaultModuleId || courseModules[0]?.id || '');
      setLessonType(lesson.type || 'video');
      setDurationMinutes(lesson.durationMinutes || 30);
      setDescription(lesson.description || '');
      setOrder(lesson.order || 1);
      setVideoUrl(lesson.videoUrl || 'https://www.youtube.com/embed/502ILHjX9EE');
      setDocumentContent(lesson.documentContent || '');
      setLinkedTaskId(lesson.linkedTaskId || '');
      setLinkedQuizId(lesson.linkedQuizId || '');
      setLinkedZoomId(lesson.linkedZoomId || '');
      setResources(lesson.resources || []);
    } else {
      setTitle('');
      setSelectedModuleId(defaultModuleId || courseModules[0]?.id || '');
      setLessonType('video');
      setDurationMinutes(30);
      setDescription('');
      setOrder(1);
      setVideoUrl('https://www.youtube.com/embed/502ILHjX9EE');
      setDocumentContent('');
      setLinkedTaskId('');
      setLinkedQuizId('');
      setLinkedZoomId('');
      setResources([]);
    }
  }, [lesson, defaultModuleId, courseId, isOpen]);

  if (!isOpen) return null;

  // Handle simulated or real local file attachment
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeInMb = (file.size / (1024 * 1024)).toFixed(1);
    const sizeStr = file.size > 1024 * 1024 ? `${sizeInMb} MB` : `${Math.round(file.size / 1024)} KB`;

    // Guess type from extension
    const ext = file.name.split('.').pop()?.toLowerCase();
    let detectedType: ResourceType = 'pdf';
    if (ext === 'pdf') detectedType = 'pdf';
    else if (['doc', 'docx'].includes(ext || '')) detectedType = 'doc';
    else if (['ppt', 'pptx'].includes(ext || '')) detectedType = 'slide';
    else if (['mp4', 'mkv', 'mov'].includes(ext || '')) detectedType = 'video';

    // Create a local blob URL or dummy data URL
    const fileUrl = URL.createObjectURL(file);

    setNewResTitle(file.name);
    setNewResType(detectedType);
    setNewResUrl(fileUrl);
    setNewResSize(sizeStr);
    setShowAddResForm(true);
  };

  const handleAddResource = () => {
    if (!newResTitle.trim()) return;

    const newRes: LessonResource = {
      id: `res_${Date.now()}`,
      title: newResTitle.trim(),
      type: newResType,
      url: newResUrl.trim() || '#',
      size: newResSize.trim() || (newResType === 'pdf' ? '2.4 MB' : newResType === 'slide' ? '8.5 MB' : 'Enlace Web'),
      fileName: newResTitle.trim()
    };

    setResources(prev => [...prev, newRes]);
    setNewResTitle('');
    setNewResUrl('');
    setNewResSize('');
    setShowAddResForm(false);
  };

  const handleRemoveResource = (resId: string) => {
    setResources(prev => prev.filter(r => r.id !== resId));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !selectedModuleId || !courseId) return;

    let finalZoomId = linkedZoomId;
    // If lesson is zoom and no session was linked, create one automatically
    if (lessonType === 'zoom' && !finalZoomId) {
      const zoom = createZoomSession({
        courseId,
        moduleId: selectedModuleId,
        title: `Clase Sincrónica: ${title.trim()}`,
        description: description.trim() || 'Sesión en vivo de videoconferencia vía Zoom.',
        date: zoomDate,
        startTime: zoomTime,
        durationMinutes,
        zoomLink: zoomLink.trim() || 'https://zoom.us',
        meetingId: zoomMeetingId.trim() || '849 2048 1023',
        passcode: zoomPasscode.trim() || 'AMADEUS2026',
        instructorName: 'Docente Especialista',
        status: 'upcoming'
      });
      finalZoomId = zoom.id;
    }

    const payload = {
      courseId,
      moduleId: selectedModuleId,
      title: title.trim(),
      description: description.trim() || (documentContent ? documentContent.substring(0, 150) : 'Contenido curricular de la lección.'),
      durationMinutes: Number(durationMinutes) || 30,
      type: lessonType,
      order: Number(order) || 1,
      videoUrl: lessonType === 'video' ? videoUrl.trim() : undefined,
      documentContent: lessonType === 'document' ? documentContent.trim() : undefined,
      linkedTaskId: lessonType === 'task' ? linkedTaskId || undefined : undefined,
      linkedQuizId: lessonType === 'quiz' ? linkedQuizId || undefined : undefined,
      linkedZoomId: lessonType === 'zoom' ? finalZoomId || undefined : undefined,
      resources: resources.length > 0 ? resources : undefined
    };

    if (lesson) {
      updateLesson(lesson.id, payload);
    } else {
      createLesson(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-8">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center">
              {lessonType === 'video' && <Video className="w-5 h-5" />}
              {lessonType === 'document' && <FileText className="w-5 h-5" />}
              {lessonType === 'zoom' && <Video className="w-5 h-5" />}
              {lessonType === 'task' && <CheckSquare className="w-5 h-5" />}
              {lessonType === 'quiz' && <HelpCircle className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                {lesson ? 'Editar Lección de Clase' : 'Nueva Lección de Clase'}
              </h3>
              <p className="text-xs text-slate-500">
                Configura contenidos, materiales didácticos (PDF, diapositivas, enlaces) y actividades.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Título y Módulo */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Título de la Lección *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Ej: Sesión 1: Arquitectura y Fundamentos de la Metodología"
                className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Módulo Asignado *
              </label>
              <select
                required
                value={selectedModuleId}
                onChange={e => setSelectedModuleId(e.target.value)}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 bg-white font-medium"
              >
                {courseModules.map((m, idx) => (
                  <option key={m.id} value={m.id}>
                    {m.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Tipo de Lección y Duración */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Tipo Principal de Contenido
              </label>
              <div className="grid grid-cols-5 gap-1.5 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setLessonType('video')}
                  className={`py-2 px-1 text-[11px] font-bold rounded-lg flex flex-col items-center gap-1 transition ${
                    lessonType === 'video' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Video</span>
                </button>
                <button
                  type="button"
                  onClick={() => setLessonType('document')}
                  className={`py-2 px-1 text-[11px] font-bold rounded-lg flex flex-col items-center gap-1 transition ${
                    lessonType === 'document' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Lectura</span>
                </button>
                <button
                  type="button"
                  onClick={() => setLessonType('zoom')}
                  className={`py-2 px-1 text-[11px] font-bold rounded-lg flex flex-col items-center gap-1 transition ${
                    lessonType === 'zoom' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Zoom</span>
                </button>
                <button
                  type="button"
                  onClick={() => setLessonType('task')}
                  className={`py-2 px-1 text-[11px] font-bold rounded-lg flex flex-col items-center gap-1 transition ${
                    lessonType === 'task' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  <span>Tarea</span>
                </button>
                <button
                  type="button"
                  onClick={() => setLessonType('quiz')}
                  className={`py-2 px-1 text-[11px] font-bold rounded-lg flex flex-col items-center gap-1 transition ${
                    lessonType === 'quiz' ? 'bg-white text-purple-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Examen</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Duración Estimada (min)
              </label>
              <input
                type="number"
                min="5"
                max="300"
                value={durationMinutes}
                onChange={e => setDurationMinutes(Number(e.target.value))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          {/* Type-Specific configuration box */}
          {lessonType === 'video' && (
            <div className="bg-blue-50/60 border border-blue-200 rounded-2xl p-4 space-y-3">
              <label className="block text-xs font-bold text-blue-900">
                Enlace a Video (YouTube Embed o MP4)
              </label>
              <input
                type="text"
                value={videoUrl}
                onChange={e => setVideoUrl(e.target.value)}
                placeholder="https://www.youtube.com/embed/..."
                className="w-full text-xs p-2.5 rounded-xl border border-blue-300 bg-white font-mono"
              />
              <span className="text-[11px] text-blue-700 block">
                Formatos soportados: URL embed de YouTube, Vimeo o archivo de video en la nube.
              </span>
            </div>
          )}

          {lessonType === 'document' && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
              <label className="block text-xs font-bold text-slate-800">
                Contenido del Documento / Lectura Didáctica
              </label>
              <textarea
                rows={5}
                value={documentContent}
                onChange={e => setDocumentContent(e.target.value)}
                placeholder="Escribe el contenido teórico, definiciones, artículos o instrucciones detalladas de la sesión..."
                className="w-full text-xs p-3 rounded-xl border border-slate-300 font-sans leading-relaxed bg-white"
              />
            </div>
          )}

          {lessonType === 'zoom' && (
            <div className="bg-indigo-50/60 border border-indigo-200 rounded-2xl p-4 space-y-3">
              <span className="text-xs font-bold text-indigo-900 block">
                Parámetros de la Clase Sincrónica Zoom
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Enlace de Reunión Zoom:
                  </label>
                  <input
                    type="url"
                    value={zoomLink}
                    onChange={e => setZoomLink(e.target.value)}
                    placeholder="https://zoom.us/j/..."
                    className="w-full text-xs p-2 rounded-lg border border-indigo-300 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    ID de Reunión:
                  </label>
                  <input
                    type="text"
                    value={zoomMeetingId}
                    onChange={e => setZoomMeetingId(e.target.value)}
                    placeholder="849 2048 1023"
                    className="w-full text-xs p-2 rounded-lg border border-indigo-300 bg-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Código de Acceso (Passcode):
                  </label>
                  <input
                    type="text"
                    value={zoomPasscode}
                    onChange={e => setZoomPasscode(e.target.value)}
                    placeholder="AMADEUS2026"
                    className="w-full text-xs p-2 rounded-lg border border-indigo-300 bg-white font-mono uppercase"
                  />
                </div>
                <div className="flex gap-2">
                  <div className="flex-1">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Fecha:
                    </label>
                    <input
                      type="date"
                      value={zoomDate}
                      onChange={e => setZoomDate(e.target.value)}
                      className="w-full text-xs p-2 rounded-lg border border-indigo-300 bg-white"
                    />
                  </div>
                  <div className="w-24">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Hora:
                    </label>
                    <input
                      type="time"
                      value={zoomTime}
                      onChange={e => setZoomTime(e.target.value)}
                      className="w-full text-xs p-2 rounded-lg border border-indigo-300 bg-white"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {lessonType === 'task' && (
            <div className="bg-amber-50/60 border border-amber-200 rounded-2xl p-4 space-y-2">
              <label className="block text-xs font-bold text-amber-900">
                Vincular con Tarea Evaluada del Curso
              </label>
              <select
                value={linkedTaskId}
                onChange={e => setLinkedTaskId(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-amber-300 bg-white"
              >
                <option value="">Selecciona tarea existente o crea una nueva...</option>
                {courseTasks.map(t => (
                  <option key={t.id} value={t.id}>
                    {t.title} ({t.maxScore} pts)
                  </option>
                ))}
              </select>
              <span className="text-[11px] text-amber-800 block">
                Los alumnos completarán la entrega de la tarea directamente desde esta lección en el aula.
              </span>
            </div>
          )}

          {lessonType === 'quiz' && (
            <div className="bg-purple-50/60 border border-purple-200 rounded-2xl p-4 space-y-2">
              <label className="block text-xs font-bold text-purple-900">
                Vincular con Examen / Evaluación en Línea
              </label>
              <select
                value={linkedQuizId}
                onChange={e => setLinkedQuizId(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-purple-300 bg-white"
              >
                <option value="">Selecciona examen existente...</option>
                {courseQuizzes.map(q => (
                  <option key={q.id} value={q.id}>
                    {q.title} ({q.questions.length} preguntas, {q.passingScore} pts mín.)
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Descripción o Instrucciones de la Lección
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Breve explicación de los objetivos o temas a revisar..."
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
            />
          </div>

          {/* ================= DIDACTIC MATERIALS / ATTACHMENTS ================= */}
          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Paperclip className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Material Didáctico y Recursos Adjuntos
                </h4>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold">
                  {resources.length}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <label className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 transition shadow-2xs">
                  <Upload className="w-3.5 h-3.5 text-blue-600" />
                  <span>Subir Archivo (PDF/DOC/PPT)</span>
                  <input
                    type="file"
                    className="hidden"
                    accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.zip"
                    onChange={handleFileUpload}
                  />
                </label>

                <button
                  type="button"
                  onClick={() => setShowAddResForm(true)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Agregar Enlace o Recurso</span>
                </button>
              </div>
            </div>

            {/* List of Attached Didactic Materials */}
            {resources.length > 0 ? (
              <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl bg-white overflow-hidden">
                {resources.map(res => (
                  <div key={res.id} className="p-3 flex items-center justify-between text-xs hover:bg-slate-50">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        res.type === 'pdf' ? 'bg-red-100 text-red-700' :
                        res.type === 'slide' ? 'bg-amber-100 text-amber-700' :
                        res.type === 'doc' ? 'bg-blue-100 text-blue-700' :
                        res.type === 'zoom' ? 'bg-indigo-100 text-indigo-700' :
                        res.type === 'video' ? 'bg-emerald-100 text-emerald-700' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {res.type === 'pdf' && <FileText className="w-4 h-4" />}
                        {res.type === 'slide' && <Presentation className="w-4 h-4" />}
                        {res.type === 'doc' && <FileText className="w-4 h-4" />}
                        {res.type === 'zoom' && <Video className="w-4 h-4" />}
                        {res.type === 'video' && <Video className="w-4 h-4" />}
                        {res.type === 'link' && <Link className="w-4 h-4" />}
                        {res.type === 'other' && <Paperclip className="w-4 h-4" />}
                      </div>
                      <div className="min-w-0">
                        <span className="font-bold text-slate-900 block truncate">{res.title}</span>
                        <span className="text-[10px] text-slate-500 uppercase font-semibold">
                          Tipo: {res.type} • {res.size || 'Material Oficial'}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveResource(res.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                      title="Eliminar recurso"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center py-4 text-xs text-slate-400">
                Aún no hay archivos PDF, diapositivas o enlaces adjuntos a esta lección.
              </p>
            )}

            {/* Quick Add Resource Form Drawer */}
            {showAddResForm && (
              <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl space-y-3 mt-2">
                <span className="text-xs font-bold text-blue-900 block">
                  Adjuntar Nuevo Material Didáctico
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div className="sm:col-span-2">
                    <label className="block text-[10px] font-bold text-slate-700 mb-0.5">
                      Nombre / Título del Material *
                    </label>
                    <input
                      type="text"
                      value={newResTitle}
                      onChange={e => setNewResTitle(e.target.value)}
                      placeholder="Ej: Diapositivas Oficiales del Módulo en PDF"
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-0.5">
                      Tipo de Material
                    </label>
                    <select
                      value={newResType}
                      onChange={e => setNewResType(e.target.value as ResourceType)}
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="pdf">Archivo PDF</option>
                      <option value="slide">Presentación / Diapositivas (PPTX)</option>
                      <option value="doc">Documento Word (DOCX)</option>
                      <option value="link">Enlace Web o Drive</option>
                      <option value="video">Grabación / Video</option>
                      <option value="zoom">Enlace a Sala Zoom</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-0.5">
                      URL del Enlace o Archivo en la Nube
                    </label>
                    <input
                      type="text"
                      value={newResUrl}
                      onChange={e => setNewResUrl(e.target.value)}
                      placeholder="https://drive.google.com/... o enlace de descarga"
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-0.5">
                      Tamaño aproximado / Etiqueta
                    </label>
                    <input
                      type="text"
                      value={newResSize}
                      onChange={e => setNewResSize(e.target.value)}
                      placeholder="Ej: 3.5 MB, 45 diapositivas"
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAddResForm(false)}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleAddResource}
                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-2xs"
                  >
                    Confirmar y Adjuntar
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-md transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{lesson ? 'Guardar Cambios de la Lección' : 'Crear Lección'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
