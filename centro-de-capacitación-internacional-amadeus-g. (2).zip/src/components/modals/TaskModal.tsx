import React, { useState, useEffect } from 'react';
import { X, CheckSquare, Calendar, Award, FileText, Upload, Check } from 'lucide-react';
import { Task, CourseModule } from '../../types';
import { usePlatform } from '../../context/PlatformContext';

interface TaskModalProps {
  courseId: string;
  defaultModuleId?: string;
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
}

export const TaskModal: React.FC<TaskModalProps> = ({
  courseId,
  defaultModuleId,
  task,
  isOpen,
  onClose
}) => {
  const { modules, createTask, updateTask } = usePlatform();
  const courseModules = modules.filter(m => m.courseId === courseId);

  const [title, setTitle] = useState('');
  const [moduleId, setModuleId] = useState('');
  const [instructions, setInstructions] = useState('');
  const [maxScore, setMaxScore] = useState(20);
  const [dueDate, setDueDate] = useState('2026-11-15T23:59');
  const [attachedFileName, setAttachedFileName] = useState('');
  const [attachedFileUrl, setAttachedFileUrl] = useState('');

  useEffect(() => {
    if (task) {
      setTitle(task.title || '');
      setModuleId(task.moduleId || defaultModuleId || courseModules[0]?.id || '');
      setInstructions(task.instructions || '');
      setMaxScore(task.maxScore || 20);
      setDueDate(task.dueDate || '2026-11-15T23:59');
      setAttachedFileName(task.attachedFileName || '');
      setAttachedFileUrl(task.attachedFileUrl || '');
    } else {
      setTitle('');
      setModuleId(defaultModuleId || courseModules[0]?.id || '');
      setInstructions('');
      setMaxScore(20);
      setDueDate('2026-11-15T23:59');
      setAttachedFileName('');
      setAttachedFileUrl('');
    }
  }, [task, defaultModuleId, courseId, isOpen]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAttachedFileName(file.name);
    setAttachedFileUrl(URL.createObjectURL(file));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !courseId) return;

    const payload = {
      courseId,
      moduleId: moduleId || undefined,
      title: title.trim(),
      instructions: instructions.trim(),
      maxScore: Number(maxScore) || 20,
      dueDate: dueDate || new Date().toISOString(),
      attachedFileName: attachedFileName.trim() || undefined,
      attachedFileUrl: attachedFileUrl.trim() || undefined
    };

    if (task) {
      updateTask(task.id, payload);
    } else {
      createTask(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-8">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                {task ? 'Editar Tarea Evaluada' : 'Crear Nueva Tarea Práctica'}
              </h3>
              <p className="text-xs text-slate-500">
                Asigna consignas, rúbrica, puntaje y fecha límite para el módulo.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Título de la Tarea *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Ej: Tarea 1: Elaboración del Diagrama de Flujo y Casos de Uso"
              className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Módulo Asociado
              </label>
              <select
                value={moduleId}
                onChange={e => setModuleId(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white font-medium"
              >
                <option value="">General del Curso</option>
                {courseModules.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-amber-600" />
                Puntaje Máximo
              </label>
              <input
                type="number"
                min="1"
                max="100"
                value={maxScore}
                onChange={e => setMaxScore(Number(e.target.value))}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-amber-600" />
              Fecha y Hora Límite de Entrega
            </label>
            <input
              type="datetime-local"
              required
              value={dueDate}
              onChange={e => setDueDate(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Instrucciones y Rúbrica de Calificación *
            </label>
            <textarea
              rows={4}
              required
              value={instructions}
              onChange={e => setInstructions(e.target.value)}
              placeholder="Indica qué debe realizar el alumno, qué formato debe subir (PDF, ZIP, DOCX) y los criterios de evaluación..."
              className="w-full text-xs p-3 rounded-xl border border-slate-300 leading-relaxed focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Plantilla o material adjunto opcional */}
          <div className="bg-amber-50/60 border border-amber-200 rounded-2xl p-4 space-y-2">
            <label className="block text-xs font-bold text-amber-950 flex items-center gap-1">
              <FileText className="w-4 h-4 text-amber-700" />
              Material o Plantilla Guía para el Alumno (Opcional)
            </label>
            <p className="text-[11px] text-amber-800">
              Adjunta un archivo que el alumno pueda descargar como base para realizar la tarea.
            </p>

            <div className="flex items-center gap-2 pt-1">
              <label className="px-3 py-1.5 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 transition">
                <Upload className="w-3.5 h-3.5" />
                <span>Examinar Archivo</span>
                <input
                  type="file"
                  className="hidden"
                  accept=".pdf,.docx,.xlsx,.pptx,.zip"
                  onChange={handleFileUpload}
                />
              </label>

              {attachedFileName && (
                <span className="text-xs text-slate-700 font-medium truncate max-w-xs">
                  {attachedFileName}
                </span>
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-md transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{task ? 'Guardar Cambios' : 'Crear Tarea'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
