import React, { useState } from 'react';
import {
  GraduationCap,
  Lock,
  Mail,
  User as UserIcon,
  Eye,
  EyeOff,
  ShieldCheck,
  ArrowRight,
  BookOpen,
  Award,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  Sparkles,
  School,
  ExternalLink
} from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';
import { UserRole } from '../types';

interface LoginPageProps {
  onLoginSuccess?: (role: UserRole) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const { login, centerSettings } = usePlatform();

  // Selected role tab for targeted login
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');

  // Form inputs
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // States
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Test accounts definitions
  const testAccounts = [
    {
      role: 'student' as UserRole,
      roleName: 'Estudiante',
      roleBadgeBg: 'bg-blue-50 text-blue-700 border-blue-200',
      activeBorder: 'border-blue-500 ring-blue-500/20',
      badgeColor: 'bg-blue-600',
      icon: BookOpen,
      accounts: [
        {
          name: 'Sofía Castro',
          title: 'Alumna - Diplomados Ágiles',
          email: 'sofia.castro@empresa.com',
          username: 'sofia.estudiante',
          password: 'estudiante123',
          avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80'
        },
        {
          name: 'Mateo Gómez',
          title: 'Alumno - Ciencia de Datos',
          email: 'mateo.gomez@techdev.io',
          username: 'mateo.estudiante',
          password: 'estudiante123',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
        }
      ],
      description: 'Acceso a aulas virtuales interactivas, tareas, exámenes, sesiones Zoom y certificados oficiales.'
    },
    {
      role: 'instructor' as UserRole,
      roleName: 'Instructor / Docente',
      roleBadgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      activeBorder: 'border-emerald-500 ring-emerald-500/20',
      badgeColor: 'bg-emerald-600',
      icon: GraduationCap,
      accounts: [
        {
          name: 'Dra. Elena Ramos',
          title: 'Docente de Inteligencia Artificial',
          email: 'elena.ramos@amadeusg.edu.pe',
          username: 'elena.docente',
          password: 'docente123',
          avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
        },
        {
          name: 'Prof. Andrés Morales',
          title: 'Docente Scrum & Gestión Ágil',
          email: 'andres.morales@amadeusg.edu.pe',
          username: 'andres.docente',
          password: 'docente123',
          avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80'
        }
      ],
      description: 'Panel para calificación de tareas, publicación de contenido, programación de clases Zoom y seguimiento de alumnos.'
    },
    {
      role: 'admin' as UserRole,
      roleName: 'Administrador',
      roleBadgeBg: 'bg-purple-50 text-purple-700 border-purple-200',
      activeBorder: 'border-purple-500 ring-purple-500/20',
      badgeColor: 'bg-purple-600',
      icon: ShieldCheck,
      accounts: [
        {
          name: 'Ing. Carlos Mendoza',
          title: 'Director General Académico',
          email: 'director@amadeusg.edu.pe',
          username: 'admin',
          password: 'admin123',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
        }
      ],
      description: 'Control total de la institución: matrículas, emisión de certificados QR, gestión docente, finanzas y reportes.'
    }
  ];

  const handleFillCredentials = (email: string, pass: string, role: UserRole, autoSubmit: boolean = false) => {
    setIdentifier(email);
    setPassword(pass);
    setSelectedRole(role);
    setError(null);

    if (autoSubmit) {
      setIsLoading(true);
      setTimeout(() => {
        const result = login(email, pass, role);
        setIsLoading(false);
        if (result.success && result.user) {
          if (onLoginSuccess) {
            onLoginSuccess(result.user.role);
          }
        } else {
          setError(result.message || 'Error al iniciar sesión');
        }
      }, 300);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!identifier.trim()) {
      setError('Por favor ingresa tu usuario o correo electrónico.');
      return;
    }
    if (!password.trim()) {
      setError('Por favor ingresa tu contraseña.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const result = login(identifier, password, selectedRole);
      setIsLoading(false);

      if (result.success && result.user) {
        if (onLoginSuccess) {
          onLoginSuccess(result.user.role);
        }
      } else {
        setError(result.message || 'Error de autenticación. Verifica tus credenciales.');
      }
    }, 350);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-slate-100 flex flex-col justify-between selection:bg-blue-600 selection:text-white">
      {/* Top institution bar */}
      <header className="border-b border-slate-800/80 bg-slate-950/40 backdrop-blur-md px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center shadow-lg shadow-blue-500/20">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white tracking-tight text-base sm:text-lg">
                AMADEUS G. <span className="text-blue-400 font-extrabold">Virtual</span>
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <ShieldCheck className="w-3 h-3" /> Campus Acreditado
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-md hidden sm:block">
              {centerSettings.name}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-300">
          <span className="hidden md:flex items-center gap-1.5 text-slate-400">
            <School className="w-4 h-4 text-blue-400" />
            Portal Institucional RBAC
          </span>
          <a
            href="https://wa.me/593997342614"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs transition"
          >
            Soporte Académico
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>
        </div>
      </header>

      {/* Main Login Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-8 sm:py-12 flex flex-col items-center justify-center">
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Left Column: Form & Role Selector */}
          <div className="lg:col-span-6 xl:col-span-5 w-full">
            <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl shadow-2xl p-6 sm:p-8 backdrop-blur-xl">
              
              <div className="mb-6">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 mb-3">
                  <Sparkles className="w-3.5 h-3.5" />
                  Inicio de Sesión Centralizado
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Bienvenido al Aula Virtual
                </h1>
                <p className="text-sm text-slate-400 mt-1.5">
                  Ingresa tus credenciales para acceder a tus diplomados, calificaciones y herramientas.
                </p>
              </div>

              {/* Role Selector Tabs */}
              <div className="mb-6">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Selecciona tu Perfil de Ingreso
                </label>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-800/90 rounded-xl border border-slate-700">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedRole('student');
                      setError(null);
                    }}
                    className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 py-2.5 px-2 rounded-lg text-xs font-medium transition ${
                      selectedRole === 'student'
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30 font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
                    }`}
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Estudiante</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedRole('instructor');
                      setError(null);
                    }}
                    className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 py-2.5 px-2 rounded-lg text-xs font-medium transition ${
                      selectedRole === 'instructor'
                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/30 font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
                    }`}
                  >
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span>Instructor</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedRole('admin');
                      setError(null);
                    }}
                    className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 py-2.5 px-2 rounded-lg text-xs font-medium transition ${
                      selectedRole === 'admin'
                        ? 'bg-purple-600 text-white shadow-md shadow-purple-500/30 font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Admin</span>
                  </button>
                </div>

                <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                  <span>
                    {selectedRole === 'student' && 'Acceso exclusivo al panel de estudiante y cursos matriculados.'}
                    {selectedRole === 'instructor' && 'Acceso al módulo docente: revisión, notas y aulas en vivo.'}
                    {selectedRole === 'admin' && 'Acceso a la dirección general, gestión de usuarios y métricas.'}
                  </span>
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5 animate-fadeIn">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div className="flex-1 font-medium">{error}</div>
                </div>
              )}

              {/* Login Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Usuario o Correo Electrónico
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder={
                        selectedRole === 'student'
                          ? 'ej. sofia.castro@empresa.com o sofia.estudiante'
                          : selectedRole === 'instructor'
                          ? 'ej. elena.ramos@amadeusg.edu.pe o elena.docente'
                          : 'ej. director@amadeusg.edu.pe o admin'
                      }
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                      required
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-semibold text-slate-300">
                      Contraseña
                    </label>
                    <span className="text-[11px] text-slate-400">
                      Sensible a mayúsculas
                    </span>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-11 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 transition"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400 hover:text-slate-300">
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded border-slate-700 text-blue-600 focus:ring-blue-500 bg-slate-800"
                    />
                    <span>Recordar sesión en este equipo</span>
                  </label>
                  <span className="text-xs text-blue-400 hover:text-blue-300 cursor-pointer">
                    ¿Problemas de acceso?
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full mt-2 py-3 px-4 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg transition ${
                    selectedRole === 'student'
                      ? 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/30'
                      : selectedRole === 'instructor'
                      ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
                      : 'bg-purple-600 hover:bg-purple-500 shadow-purple-600/30'
                  } disabled:opacity-50`}
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>Ingresar como {selectedRole === 'student' ? 'Estudiante' : selectedRole === 'instructor' ? 'Docente' : 'Administrador'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1 text-[11px]">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Control RBAC Estricto Activo
                </span>
                <span className="text-[11px] text-slate-500">v2.5 Enterprise</span>
              </div>
            </div>
          </div>

          {/* Right Column: Clickable Test Accounts for Instant Evaluation */}
          <div className="lg:col-span-6 xl:col-span-7 w-full flex flex-col gap-6">
            
            <div className="bg-slate-900/60 border border-slate-700/60 rounded-2xl p-6 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white">
                      Cuentas y Contraseñas de Prueba (Acceso con 1-Clic)
                    </h2>
                    <p className="text-xs text-slate-400">
                      Haz clic en cualquier cuenta para autocompletar e iniciar sesión de inmediato con el rol asignado.
                    </p>
                  </div>
                </div>
              </div>

              {/* Roles Cards Grid */}
              <div className="space-y-4">
                {testAccounts.map((group) => {
                  const Icon = group.icon;
                  const isCurrentRole = selectedRole === group.role;

                  return (
                    <div
                      key={group.role}
                      className={`p-4 rounded-xl border transition-all ${
                        isCurrentRole
                          ? 'bg-slate-800/90 border-slate-600 shadow-md ring-1 ring-slate-600'
                          : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className={`p-1.5 rounded-lg ${group.badgeColor} text-white`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <span className="text-sm font-bold text-white">
                              {group.roleName}
                            </span>
                            <span className="ml-2 text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                              Rol: {group.role}
                            </span>
                          </div>
                        </div>

                        <span className="text-[11px] text-slate-400 hidden sm:inline">
                          {group.role === 'admin' ? 'Acceso Total' : group.role === 'instructor' ? 'Gestor de Curso' : 'Alumno Regular'}
                        </span>
                      </div>

                      <p className="text-xs text-slate-400 mb-3">
                        {group.description}
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {group.accounts.map((acc) => (
                          <div
                            key={acc.email}
                            className="bg-slate-950/60 border border-slate-800 hover:border-slate-700 rounded-lg p-3 flex flex-col justify-between gap-2.5 transition group"
                          >
                            <div className="flex items-start gap-2.5">
                              <img
                                src={acc.avatar}
                                alt={acc.name}
                                className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-700 shrink-0"
                              />
                              <div className="min-w-0">
                                <div className="text-xs font-bold text-slate-200 truncate group-hover:text-white">
                                  {acc.name}
                                </div>
                                <div className="text-[10px] text-slate-400 truncate">
                                  {acc.title}
                                </div>
                                <div className="text-[11px] font-mono text-slate-300 truncate mt-1">
                                  ✉️ {acc.email}
                                </div>
                                <div className="text-[11px] font-mono text-amber-300/90 truncate">
                                  🔑 Clave: <span className="font-bold bg-amber-950/50 px-1 py-0.2 rounded border border-amber-800/40">{acc.password}</span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 pt-1 border-t border-slate-800/60">
                              <button
                                type="button"
                                onClick={() => handleFillCredentials(acc.email, acc.password, group.role, false)}
                                className="flex-1 py-1 px-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-medium transition text-center"
                              >
                                Copiar al form
                              </button>
                              <button
                                type="button"
                                onClick={() => handleFillCredentials(acc.email, acc.password, group.role, true)}
                                className={`flex-1 py-1 px-2 rounded text-[11px] font-bold text-white transition text-center ${
                                  group.role === 'student'
                                    ? 'bg-blue-600 hover:bg-blue-500'
                                    : group.role === 'instructor'
                                    ? 'bg-emerald-600 hover:bg-emerald-500'
                                    : 'bg-purple-600 hover:bg-purple-500'
                                }`}
                              >
                                Acceder ya →
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Institutional Information Card */}
            <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-4 flex items-center justify-between gap-4 text-xs text-slate-400">
              <div className="flex items-center gap-3">
                <Award className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <span className="font-semibold text-slate-300 block">
                    Acreditación y Certificaciones AMADEUS G.
                  </span>
                  <span>
                    Validación digital con código QR criptográfico para diplomas de culminación laboral.
                  </span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Sede Central</span>
                <span className="text-slate-300 font-medium">Lima - Perú</span>
              </div>
            </div>

          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/60 bg-slate-950/60 py-4 px-4 sm:px-8 text-center text-xs text-slate-500">
        <p>
          © {new Date().getFullYear()} {centerSettings.name} - Plataforma de Educación Virtual e Institucional. Todos los derechos reservados.
        </p>
      </footer>
    </div>
  );
};
