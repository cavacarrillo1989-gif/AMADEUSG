import React, { useState } from 'react';
import { X, BookOpen, Clock, User, Check, Sparkles, CreditCard, Phone, ShieldCheck } from 'lucide-react';
import { usePlatform } from '../context/PlatformContext';
import { Course } from '../types';
import { PaymentGatewayModal } from './modals/PaymentGatewayModal';

interface CourseCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCourse: (courseId: string) => void;
}

export const CourseCatalogModal: React.FC<CourseCatalogModalProps> = ({
  isOpen,
  onClose,
  onSelectCourse
}) => {
  const { courses, users, enrollments, currentUser } = usePlatform();
  const [courseToPay, setCourseToPay] = useState<Course | null>(null);

  if (!isOpen) return null;

  const myEnrollments = enrollments.filter(e => e.studentId === currentUser.id);
  const whatsappNumber = '0997342614';

  const handlePaymentSuccess = (courseId: string) => {
    setCourseToPay(null);
    onClose();
    onSelectCourse(courseId);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn">
        <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full p-6 sm:p-8 space-y-6 my-8 border border-slate-200">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900">
                  Catálogo de Cursos y Programas de Capacitación
                </h2>
                <p className="text-xs text-slate-500">
                  Inscríbete mediante nuestra pasarela de pagos segura o contacta a un asesor por WhatsApp al <strong className="text-emerald-700 font-mono">{whatsappNumber}</strong>.
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {courses.map(course => {
              const isEnrolled = myEnrollments.some(e => e.courseId === course.id);
              const instructor = users.find(u => u.id === course.instructorId);
              const finalPrice = course.discountPrice || course.price || 49;
              const regularPrice = course.price || (finalPrice + 20);

              const wspUrl = `https://wa.me/593997342614?text=${encodeURIComponent(
                `Hola Amadeus G., deseo información e inscribirme en el curso: "${course.title}" ($${finalPrice} USD). Mi contacto es ${currentUser.name}.`
              )}`;

              return (
                <div
                  key={course.id}
                  className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md transition flex flex-col justify-between"
                >
                  <div>
                    <div className="h-44 relative bg-slate-100">
                      <img src={course.image} alt={course.title} className="w-full h-full object-cover" />
                      <div className="absolute top-3 left-3 flex gap-2">
                        <span className="px-2.5 py-1 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-bold rounded-lg uppercase">
                          {course.category}
                        </span>
                        <span className="px-2 py-0.5 bg-blue-600/90 text-white text-[10px] font-bold rounded-lg">
                          {course.level}
                        </span>
                      </div>

                      {/* Price Badge */}
                      <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-xs px-3 py-1.5 rounded-xl shadow-md text-right border border-slate-100">
                        {course.discountPrice && (
                          <span className="text-[10px] text-slate-400 line-through mr-1 font-medium">
                            ${regularPrice} USD
                          </span>
                        )}
                        <span className="text-sm font-black text-slate-900">
                          ${finalPrice} <span className="text-[10px] text-slate-500 font-semibold">USD</span>
                        </span>
                      </div>
                    </div>

                    <div className="p-5 space-y-2">
                      <h3 className="font-bold text-slate-900 text-base leading-snug">
                        {course.title}
                      </h3>
                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {course.description}
                      </p>

                      <div className="pt-2 flex items-center justify-between text-xs text-slate-500 border-t border-slate-100">
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          <span>{instructor?.name}</span>
                        </div>
                        <div className="flex items-center gap-1 font-semibold text-slate-700">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{course.durationHours} hrs</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-2">
                    {isEnrolled ? (
                      <button
                        onClick={() => {
                          onClose();
                          onSelectCourse(course.id);
                        }}
                        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition"
                      >
                        <Check className="w-4 h-4" />
                        <span>Ya Estás Inscrito • Ir al Aula Virtual</span>
                      </button>
                    ) : (
                      <div className="space-y-2">
                        <button
                          onClick={() => setCourseToPay(course)}
                          className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition"
                        >
                          <CreditCard className="w-4 h-4 text-amber-300" />
                          <span>Comprar y Matricularme (${finalPrice} USD)</span>
                        </button>

                        <a
                          href={wspUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="w-full py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 border border-emerald-200 transition"
                        >
                          <Phone className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Consultar por WhatsApp ({whatsappNumber})</span>
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Payment Gateway Modal */}
      {courseToPay && (
        <PaymentGatewayModal
          course={courseToPay}
          isOpen={!!courseToPay}
          onClose={() => setCourseToPay(null)}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </>
  );
};

