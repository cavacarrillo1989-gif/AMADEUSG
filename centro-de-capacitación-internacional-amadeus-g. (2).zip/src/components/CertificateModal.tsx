import React from 'react';
import { jsPDF } from 'jspdf';
import { Award, Download, Printer, CheckCircle, ShieldCheck, X, Share2 } from 'lucide-react';
import { Certificate } from '../types';

interface CertificateModalProps {
  certificate: Certificate | null;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ certificate, onClose }) => {
  if (!certificate) return null;

  const handleDownloadPDF = () => {
    // Generate high resolution PDF using jsPDF
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    });

    // Dimensions: 297mm x 210mm
    // Outer border
    doc.setDrawColor(30, 41, 59); // Slate-800
    doc.setLineWidth(3);
    doc.rect(10, 10, 277, 190);

    // Inner gold border
    doc.setDrawColor(202, 138, 4); // Yellow-600
    doc.setLineWidth(0.8);
    doc.rect(14, 14, 269, 182);

    // Header Center Name
    doc.setFont('times', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(15, 23, 42);
    doc.text(certificate.centerName.toUpperCase(), 148.5, 32, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text('RESOLUCIÓN INSTITUCIONAL DE ACREDITACIÓN N° 0842-2025', 148.5, 38, { align: 'center' });

    // Diploma Title
    doc.setFont('times', 'bold');
    doc.setFontSize(30);
    doc.setTextColor(180, 83, 9); // Amber-700
    doc.text('CERTIFICADO DE APROBACIÓN', 148.5, 58, { align: 'center' });

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(12);
    doc.setTextColor(71, 85, 105);
    doc.text('El Comité Académico y de Certificación hace constar que:', 148.5, 70, { align: 'center' });

    // Student Name
    doc.setFont('times', 'bold');
    doc.setFontSize(26);
    doc.setTextColor(15, 23, 42);
    doc.text(certificate.studentName, 148.5, 86, { align: 'center' });

    // Line under student name
    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.5);
    doc.line(60, 91, 237, 91);

    // Description
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(12);
    doc.setTextColor(51, 65, 85);
    doc.text('ha cumplido y aprobado satisfactoriamente todos los requisitos académicos del programa:', 148.5, 102, { align: 'center' });

    // Course Title
    doc.setFont('times', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(14, 116, 144); // Cyan-700
    doc.text(`"${certificate.courseTitle}"`, 148.5, 116, { align: 'center' });

    // Hours and Dates
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.setTextColor(71, 85, 105);
    doc.text(`Con una duración académica de ${certificate.durationHours} horas pedagógicas lectivas y prácticas.`, 148.5, 127, { align: 'center' });
    doc.text(`Expedido el día ${certificate.issueDate}.`, 148.5, 134, { align: 'center' });

    // Signatures
    // Left: Director
    doc.setDrawColor(100, 116, 139);
    doc.line(45, 165, 115, 165);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 41, 59);
    doc.text(certificate.directorName, 80, 171, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text('Director Académico y Certificaciones', 80, 176, { align: 'center' });

    // Right: Instructor
    doc.line(182, 165, 252, 165);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 41, 59);
    doc.text(certificate.instructorName, 217, 171, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text('Docente / Instructor Especialista', 217, 176, { align: 'center' });

    // Verification Code & Footer
    doc.setFont('courier', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(148, 163, 184);
    doc.text(`CÓDIGO DE VERIFICACIÓN OFICIAL: ${certificate.certificateCode}`, 148.5, 188, { align: 'center' });

    doc.save(`Certificado_${certificate.studentName.replace(/\s+/g, '_')}_${certificate.certificateCode}.pdf`);
  };

  const handlePrint = () => {
    window.print();
  };

  const [copied, setCopied] = React.useState(false);
  const handleCopyCode = () => {
    navigator.clipboard.writeText(certificate.certificateCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <Award className="w-6 h-6 text-amber-400" />
            <div>
              <h3 className="font-semibold text-base leading-tight">Certificado Oficial de Aprobación</h3>
              <p className="text-xs text-slate-300">Acreditación Académica y Registro Digital</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-lg text-xs transition shadow-sm"
              title="Descargar en formato PDF oficial"
            >
              <Download className="w-3.5 h-3.5" />
              Descargar PDF
            </button>
            <button
              onClick={handlePrint}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-lg text-xs transition border border-slate-700"
            >
              <Printer className="w-3.5 h-3.5" />
              Imprimir
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Display Area */}
        <div className="p-6 md:p-10 bg-slate-100 flex justify-center">
          <div
            id="certificate-print-area"
            className="w-full bg-[#fdfbf7] border-8 border-slate-900 p-8 md:p-12 rounded-lg shadow-xl relative text-center select-none"
            style={{
              backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(245, 158, 11, 0.03) 0%, transparent 80%)'
            }}
          >
            {/* Gold corner ornaments */}
            <div className="absolute top-2 left-2 w-10 h-10 border-t-2 border-l-2 border-amber-600"></div>
            <div className="absolute top-2 right-2 w-10 h-10 border-t-2 border-r-2 border-amber-600"></div>
            <div className="absolute bottom-2 left-2 w-10 h-10 border-b-2 border-l-2 border-amber-600"></div>
            <div className="absolute bottom-2 right-2 w-10 h-10 border-b-2 border-r-2 border-amber-600"></div>

            {/* Sub-border */}
            <div className="border border-amber-500/40 p-6 md:p-10 rounded">
              {/* Institution Seal & Name */}
              <div className="flex flex-col items-center mb-6">
                <div className="w-14 h-14 rounded-full bg-slate-900 border-2 border-amber-400 flex items-center justify-center mb-2 shadow-md">
                  <Award className="w-7 h-7 text-amber-400" />
                </div>
                <h4 className="text-xs md:text-sm font-bold tracking-widest text-slate-800 uppercase">
                  {certificate.centerName}
                </h4>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider">
                  Resolución Ministerial de Acreditación N° 0842-2025
                </span>
              </div>

              {/* Main Heading */}
              <div className="mb-6">
                <h1 className="text-2xl md:text-4xl font-extrabold text-amber-700 tracking-wide font-serif">
                  CERTIFICADO DE APROBACIÓN
                </h1>
                <p className="text-xs md:text-sm text-slate-600 italic mt-1 font-serif">
                  El Centro de Capacitación y el Comité Académico certifican que:
                </p>
              </div>

              {/* Student Name */}
              <div className="my-6">
                <h2 className="text-2xl md:text-4xl font-bold text-slate-950 underline decoration-amber-500/50 decoration-2 underline-offset-8 font-serif">
                  {certificate.studentName}
                </h2>
              </div>

              {/* Course & Completion Text */}
              <div className="max-w-2xl mx-auto my-6 space-y-2 text-slate-700 text-xs md:text-sm leading-relaxed">
                <p>
                  Ha cumplido y aprobado satisfactoriamente todas las exigencias teóricas, tareas prácticas,
                  evaluaciones y asistencia del programa de capacitación profesional:
                </p>
                <p className="text-base md:text-xl font-bold text-slate-900 text-cyan-800 font-serif">
                  "{certificate.courseTitle}"
                </p>
                <p className="text-xs text-slate-500">
                  Con una duración lectiva de <span className="font-semibold text-slate-700">{certificate.durationHours} horas pedagógicas</span>,
                  cumpliendo los estándares de calidad académica establecidos.
                </p>
              </div>

              {/* Issue Date & Signatures */}
              <div className="mt-10 pt-6 grid grid-cols-2 md:grid-cols-3 gap-6 items-end border-t border-slate-200">
                {/* Director Signature */}
                <div className="flex flex-col items-center">
                  <div className="w-32 border-b border-slate-700 pb-1 mb-1.5 flex flex-col items-center">
                    <span className="font-serif italic text-sm text-slate-800 select-none">R. Valenzuela P.</span>
                  </div>
                  <span className="text-xs font-bold text-slate-900">{certificate.directorName}</span>
                  <span className="text-[10px] text-slate-500">Director Académico</span>
                </div>

                {/* Golden Official Stamp */}
                <div className="hidden md:flex flex-col items-center justify-center">
                  <div className="w-20 h-20 rounded-full border-4 border-amber-600 bg-amber-50/80 flex flex-col items-center justify-center shadow-inner text-amber-800">
                    <ShieldCheck className="w-6 h-6 text-amber-600 mb-0.5" />
                    <span className="text-[8px] font-black uppercase tracking-tight">AMADEUS G. VÁLIDO</span>
                    <span className="text-[7px] text-amber-700 font-mono">OFICIAL</span>
                  </div>
                </div>

                {/* Instructor Signature */}
                <div className="flex flex-col items-center">
                  <div className="w-32 border-b border-slate-700 pb-1 mb-1.5 flex flex-col items-center">
                    <span className="font-serif italic text-sm text-slate-800 select-none">A. Morales C.</span>
                  </div>
                  <span className="text-xs font-bold text-slate-900">{certificate.instructorName}</span>
                  <span className="text-[10px] text-slate-500">Docente Titular</span>
                </div>
              </div>

              {/* Verification Code Footer */}
              <div className="mt-8 pt-4 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-slate-500">
                <span>Fecha de emisión: {certificate.issueDate}</span>
                <span className="font-mono bg-slate-200 px-2 py-0.5 rounded text-slate-800 font-semibold tracking-wide">
                  Código de verificación: {certificate.certificateCode}
                </span>
                <span className="text-emerald-700 font-medium flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> Verificable en línea
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-6 py-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span className="font-medium text-slate-800">Código Único:</span>
            <code className="bg-slate-100 px-2 py-1 rounded text-slate-800 font-mono font-semibold border border-slate-300">
              {certificate.certificateCode}
            </code>
            <button
              onClick={handleCopyCode}
              className="text-xs text-blue-600 hover:text-blue-800 underline font-medium"
            >
              {copied ? '¡Copiado!' : 'Copiar código'}
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadPDF}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg text-sm flex items-center gap-2 shadow-sm transition"
            >
              <Download className="w-4 h-4" />
              Descargar PDF
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-sm transition"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
