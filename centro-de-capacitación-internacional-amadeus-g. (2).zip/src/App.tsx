import React, { useState, useEffect } from 'react';
import { PlatformProvider, usePlatform } from './context/PlatformContext';
import { Navbar } from './components/Navbar';
import { LoginPage } from './components/LoginPage';
import { StudentDashboard } from './components/StudentDashboard';
import { CourseClassroom } from './components/CourseClassroom';
import { InstructorPanel } from './components/InstructorPanel';
import { AdminPanel } from './components/AdminPanel';
import { CertificateModal } from './components/CertificateModal';
import { CourseCatalogModal } from './components/CourseCatalogModal';
import { ZoomMeetingModal } from './components/ZoomMeetingModal';
import { WhatsAppWidget } from './components/WhatsAppWidget';
import { ZoomSession, UserRole } from './types';
import { Phone, ShieldCheck, CreditCard } from 'lucide-react';

const MainApp: React.FC = () => {
  const { currentUser, isAuthenticated, activeCertificateModal, setActiveCertificateModal, centerSettings } = usePlatform();

  // Navigation tab state
  const [currentTab, setCurrentTab] = useState<string>(() => {
    if (currentUser.role === 'admin') return 'admin_dashboard';
    if (currentUser.role === 'instructor') return 'instructor_courses';
    return 'student_courses';
  });

  // Active Classroom state (if viewing a course aula virtual)
  const [activeClassroomCourseId, setActiveClassroomCourseId] = useState<string | null>(null);

  // Modals state
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);
  const [activeZoomSession, setActiveZoomSession] = useState<ZoomSession | null>(null);

  // RBAC Access Control Enforcement
  useEffect(() => {
    if (!isAuthenticated) return;

    // Check allowed tabs by role
    const studentTabs = ['student_courses', 'student_tasks', 'student_zoom', 'student_certificates', 'classroom'];
    const instructorTabs = ['instructor_courses', 'instructor_grading', 'instructor_zoom', 'instructor_students', 'classroom'];
    const adminTabs = ['admin_dashboard', 'admin_courses', 'admin_users', 'admin_enrollments', 'admin_certificates', 'admin_settings', 'admin_payments', 'classroom'];

    if (currentUser.role === 'student' && !studentTabs.includes(currentTab)) {
      setCurrentTab('student_courses');
    } else if (currentUser.role === 'instructor' && !instructorTabs.includes(currentTab)) {
      setCurrentTab('instructor_courses');
    } else if (currentUser.role === 'admin' && !adminTabs.includes(currentTab)) {
      setCurrentTab('admin_dashboard');
    }
  }, [currentUser.role, currentTab, isAuthenticated]);

  const handleOpenCourseClassroom = (courseId: string) => {
    setActiveClassroomCourseId(courseId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromClassroom = () => {
    setActiveClassroomCourseId(null);
  };

  const handleLoginSuccess = (role: UserRole) => {
    setActiveClassroomCourseId(null);
    if (role === 'admin') {
      setCurrentTab('admin_dashboard');
    } else if (role === 'instructor') {
      setCurrentTab('instructor_courses');
    } else {
      setCurrentTab('student_courses');
    }
  };

  // If user is not authenticated, render Login Page as initial entry point
  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      {/* Top Navigation */}
      <Navbar
        currentTab={activeClassroomCourseId ? 'classroom' : currentTab}
        setCurrentTab={(tab) => {
          setActiveClassroomCourseId(null);
          setCurrentTab(tab);
        }}
        onOpenCatalog={() => setIsCatalogOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {activeClassroomCourseId ? (
          <CourseClassroom
            courseId={activeClassroomCourseId}
            onBack={handleBackFromClassroom}
            onOpenZoomModal={(session) => setActiveZoomSession(session)}
          />
        ) : (
          <>
            {/* Student Views */}
            {currentUser.role === 'student' && (
              <>
                {currentTab === 'student_courses' && (
                  <StudentDashboard
                    onSelectCourse={handleOpenCourseClassroom}
                    onOpenCatalog={() => setIsCatalogOpen(true)}
                    onOpenZoomModal={(s) => setActiveZoomSession(s)}
                    activeSubTab="courses"
                  />
                )}
                {currentTab === 'student_tasks' && (
                  <StudentDashboard
                    onSelectCourse={handleOpenCourseClassroom}
                    onOpenCatalog={() => setIsCatalogOpen(true)}
                    onOpenZoomModal={(s) => setActiveZoomSession(s)}
                    activeSubTab="tasks"
                  />
                )}
                {currentTab === 'student_zoom' && (
                  <StudentDashboard
                    onSelectCourse={handleOpenCourseClassroom}
                    onOpenCatalog={() => setIsCatalogOpen(true)}
                    onOpenZoomModal={(s) => setActiveZoomSession(s)}
                    activeSubTab="zoom"
                  />
                )}
                {currentTab === 'student_certificates' && (
                  <StudentDashboard
                    onSelectCourse={handleOpenCourseClassroom}
                    onOpenCatalog={() => setIsCatalogOpen(true)}
                    onOpenZoomModal={(s) => setActiveZoomSession(s)}
                    activeSubTab="certificates"
                  />
                )}
              </>
            )}

            {/* Instructor Views */}
            {currentUser.role === 'instructor' && (
              <>
                {currentTab === 'instructor_courses' && (
                  <InstructorPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    activeSubTab="courses"
                  />
                )}
                {currentTab === 'instructor_grading' && (
                  <InstructorPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    activeSubTab="grading"
                  />
                )}
                {currentTab === 'instructor_zoom' && (
                  <InstructorPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    activeSubTab="zoom"
                  />
                )}
                {currentTab === 'instructor_students' && (
                  <InstructorPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    activeSubTab="students"
                  />
                )}
              </>
            )}

            {/* Administrator Views */}
            {currentUser.role === 'admin' && (
              <>
                {currentTab === 'admin_dashboard' && (
                  <AdminPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    onNavigateTab={setCurrentTab}
                    activeSubTab="dashboard"
                  />
                )}
                {currentTab === 'admin_courses' && (
                  <AdminPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    onNavigateTab={setCurrentTab}
                    activeSubTab="courses"
                  />
                )}
                {currentTab === 'admin_users' && (
                  <AdminPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    onNavigateTab={setCurrentTab}
                    activeSubTab="users"
                  />
                )}
                {currentTab === 'admin_enrollments' && (
                  <AdminPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    onNavigateTab={setCurrentTab}
                    activeSubTab="enrollments"
                  />
                )}
                {currentTab === 'admin_certificates' && (
                  <AdminPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    onNavigateTab={setCurrentTab}
                    activeSubTab="certificates"
                  />
                )}
                {currentTab === 'admin_settings' && (
                  <AdminPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    onNavigateTab={setCurrentTab}
                    activeSubTab="settings"
                  />
                )}
                {currentTab === 'admin_payments' && (
                  <AdminPanel
                    onOpenClassroom={handleOpenCourseClassroom}
                    onNavigateTab={setCurrentTab}
                    activeSubTab="payments"
                  />
                )}
              </>
            )}
          </>
        )}
      </main>

      {/* Floating WhatsApp Widget */}
      <WhatsAppWidget />

      {/* Global Modals */}
      <CertificateModal
        certificate={activeCertificateModal}
        onClose={() => setActiveCertificateModal(null)}
      />

      <CourseCatalogModal
        isOpen={isCatalogOpen}
        onClose={() => setIsCatalogOpen(false)}
        onSelectCourse={handleOpenCourseClassroom}
      />

      <ZoomMeetingModal
        session={activeZoomSession}
        onClose={() => setActiveZoomSession(null)}
      />

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
            <div>
              <span className="font-bold text-white text-sm">AMADEUS G. Virtual</span> — {centerSettings.name}
              <p className="text-[11px] text-slate-400 mt-1 max-w-xl">
                Plataforma integral de formación continua: aulas virtuales interactivas, lecciones, evaluaciones, tutoría en vivo vía Zoom y pasarela de pago segura.
              </p>
            </div>

            {/* WhatsApp CTA in Footer */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <a
                href="https://wa.me/593997342614?text=Hola%20Centro%20de%20Capacitaci%C3%B3n%20Amadeus%20G.,%20deseo%20m%C3%A1s%20informaci%C3%B3n."
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-sm transition"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>WhatsApp: 0997342614</span>
              </a>

              <button
                onClick={() => setIsCatalogOpen(true)}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs flex items-center gap-1.5 border border-slate-700 transition"
              >
                <CreditCard className="w-3.5 h-3.5 text-amber-400" />
                <span>Pasarela de Pagos</span>
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
            <div>
              © {new Date().getFullYear()} {centerSettings.name} • Contacto directo: 0997342614
            </div>
            <div>
              Plataforma de Capacitación y Aulas Virtuales
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <PlatformProvider>
      <MainApp />
    </PlatformProvider>
  );
}
