import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  User,
  Course,
  CourseModule,
  Lesson,
  Task,
  TaskSubmission,
  Quiz,
  QuizAttempt,
  ZoomSession,
  Enrollment,
  Certificate,
  CenterSettings,
  PaymentTransaction,
  UserRole
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_COURSES,
  INITIAL_MODULES,
  INITIAL_LESSONS,
  INITIAL_TASKS,
  INITIAL_TASK_SUBMISSIONS,
  INITIAL_QUIZZES,
  INITIAL_QUIZ_ATTEMPTS,
  INITIAL_ZOOM_SESSIONS,
  INITIAL_ENROLLMENTS,
  INITIAL_CERTIFICATES,
  INITIAL_CENTER_SETTINGS,
  INITIAL_TRANSACTIONS
} from '../data/initialData';

interface PlatformContextType {
  // Current session
  currentUser: User;
  setCurrentUser: (user: User) => void;
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  centerSettings: CenterSettings;
  updateCenterSettings: (settings: Partial<CenterSettings>) => void;

  // Courses and content
  courses: Course[];
  modules: CourseModule[];
  lessons: Lesson[];
  tasks: Task[];
  taskSubmissions: TaskSubmission[];
  quizzes: Quiz[];
  quizAttempts: QuizAttempt[];
  zoomSessions: ZoomSession[];
  enrollments: Enrollment[];
  certificates: Certificate[];
  transactions: PaymentTransaction[];
  setTransactions: React.Dispatch<React.SetStateAction<PaymentTransaction[]>>;
  addTransaction: (txData: Omit<PaymentTransaction, 'id' | 'paymentDate' | 'receiptNumber'>) => PaymentTransaction;

  // Student actions
  enrollInCourse: (courseId: string, studentId?: string) => void;
  unenrollCourse: (courseId: string, studentId: string) => void;
  toggleLessonCompletion: (lessonId: string, courseId: string) => void;
  submitTask: (taskId: string, comments: string, fileName?: string, fileUrl?: string) => void;
  submitQuizAttempt: (quizId: string, answers: Record<string, number>) => QuizAttempt;
  getCourseProgress: (courseId: string, studentId?: string) => {
    completedLessons: number;
    totalLessons: number;
    percent: number;
    isCompleted: boolean;
    hasCertificate: boolean;
    tasksTotal: number;
    tasksGraded: number;
    quizzesTotal: number;
    quizzesPassed: number;
  };
  getCertificateForCourse: (courseId: string, studentId?: string) => Certificate | undefined;

  // Instructor / Admin actions
  gradeTaskSubmission: (submissionId: string, score: number, feedback: string) => void;
  createCourse: (course: Omit<Course, 'id' | 'createdAt'>) => Course;
  updateCourse: (id: string, updates: Partial<Course>) => void;
  deleteCourse: (id: string) => void;

  createModule: (moduleData: Omit<CourseModule, 'id'>) => CourseModule;
  updateModule: (id: string, updates: Partial<CourseModule>) => void;
  deleteModule: (id: string) => void;

  createLesson: (lessonData: Omit<Lesson, 'id'>) => Lesson;
  updateLesson: (id: string, updates: Partial<Lesson>) => void;
  deleteLesson: (id: string) => void;

  createTask: (taskData: Omit<Task, 'id' | 'createdAt'>) => Task;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  createQuiz: (quizData: Omit<Quiz, 'id' | 'createdAt'>) => Quiz;
  updateQuiz: (id: string, updates: Partial<Quiz>) => void;
  deleteQuiz: (id: string) => void;
  createZoomSession: (zoomData: Omit<ZoomSession, 'id'>) => ZoomSession;
  updateZoomSession: (id: string, updates: Partial<ZoomSession>) => void;
  deleteZoomSession: (id: string) => void;

  createUser: (userData: Omit<User, 'id' | 'registeredAt'>) => User;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // Authentication and Session
  isAuthenticated: boolean;
  login: (identifier: string, password: string, selectedRole?: UserRole) => { success: boolean; message?: string; user?: User };
  logout: () => void;

  // System
  resetAllData: () => void;
  activeCertificateModal: Certificate | null;
  setActiveCertificateModal: (cert: Certificate | null) => void;
}

const STORAGE_KEYS = {
  USERS: 'amadeus_users_v2',
  CURRENT_USER_ID: 'amadeus_current_user_id_v2',
  AUTH_STATUS: 'amadeus_auth_status_v2',
  COURSES: 'amadeus_courses_v2',
  MODULES: 'amadeus_modules_v2',
  LESSONS: 'amadeus_lessons_v2',
  TASKS: 'amadeus_tasks_v2',
  SUBMISSIONS: 'amadeus_submissions_v2',
  QUIZZES: 'amadeus_quizzes_v2',
  QUIZ_ATTEMPTS: 'amadeus_attempts_v2',
  ZOOM: 'amadeus_zoom_v2',
  ENROLLMENTS: 'amadeus_enrollments_v2',
  CERTIFICATES: 'amadeus_certificates_v2',
  SETTINGS: 'amadeus_settings_v2',
  TRANSACTIONS: 'amadeus_transactions_v2',
};

const PlatformContext = createContext<PlatformContextType | undefined>(undefined);

export const PlatformProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from local storage or initial
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS) || localStorage.getItem('cicap_users_v1');
    if (saved) {
      try {
        const parsed: User[] = JSON.parse(saved);
        return parsed.map(u => {
          const init = INITIAL_USERS.find(iu => iu.id === u.id);
          return {
            ...u,
            username: u.username || init?.username || u.email.split('@')[0],
            password: u.password || init?.password || (u.role === 'admin' ? 'admin123' : u.role === 'instructor' ? 'docente123' : 'estudiante123')
          };
        });
      } catch {
        return INITIAL_USERS;
      }
    }
    return INITIAL_USERS;
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID) || localStorage.getItem('cicap_current_user_id_v1');
    return saved || 'usr_student_1';
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUTH_STATUS);
    return saved === 'true';
  });

  const [centerSettings, setCenterSettings] = useState<CenterSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS) || localStorage.getItem('cicap_settings_v1');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (!parsed.name || parsed.name.includes('CICAP')) {
          return {
            ...parsed,
            name: INITIAL_CENTER_SETTINGS.name,
            logoText: INITIAL_CENTER_SETTINGS.logoText,
            contactEmail: INITIAL_CENTER_SETTINGS.contactEmail
          };
        }
        return parsed;
      } catch {
        return INITIAL_CENTER_SETTINGS;
      }
    }
    return INITIAL_CENTER_SETTINGS;
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COURSES);
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [modules, setModules] = useState<CourseModule[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MODULES);
    return saved ? JSON.parse(saved) : INITIAL_MODULES;
  });

  const [lessons, setLessons] = useState<Lesson[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LESSONS);
    return saved ? JSON.parse(saved) : INITIAL_LESSONS;
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TASKS);
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  const [taskSubmissions, setTaskSubmissions] = useState<TaskSubmission[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SUBMISSIONS);
    return saved ? JSON.parse(saved) : INITIAL_TASK_SUBMISSIONS;
  });

  const [quizzes, setQuizzes] = useState<Quiz[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.QUIZZES);
    return saved ? JSON.parse(saved) : INITIAL_QUIZZES;
  });

  const [quizAttempts, setQuizAttempts] = useState<QuizAttempt[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.QUIZ_ATTEMPTS);
    return saved ? JSON.parse(saved) : INITIAL_QUIZ_ATTEMPTS;
  });

  const [zoomSessions, setZoomSessions] = useState<ZoomSession[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ZOOM);
    return saved ? JSON.parse(saved) : INITIAL_ZOOM_SESSIONS;
  });

  const [enrollments, setEnrollments] = useState<Enrollment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ENROLLMENTS);
    return saved ? JSON.parse(saved) : INITIAL_ENROLLMENTS;
  });

  const [certificates, setCertificates] = useState<Certificate[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CERTIFICATES);
    return saved ? JSON.parse(saved) : INITIAL_CERTIFICATES;
  });

  const [transactions, setTransactions] = useState<PaymentTransaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [activeCertificateModal, setActiveCertificateModal] = useState<Certificate | null>(null);

  // Sync to localStorage
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, currentUserId); }, [currentUserId]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(centerSettings)); }, [centerSettings]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses)); }, [courses]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.MODULES, JSON.stringify(modules)); }, [modules]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.LESSONS, JSON.stringify(lessons)); }, [lessons]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks)); }, [tasks]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.SUBMISSIONS, JSON.stringify(taskSubmissions)); }, [taskSubmissions]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(quizzes)); }, [quizzes]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.QUIZ_ATTEMPTS, JSON.stringify(quizAttempts)); }, [quizAttempts]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.ZOOM, JSON.stringify(zoomSessions)); }, [zoomSessions]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.ENROLLMENTS, JSON.stringify(enrollments)); }, [enrollments]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.CERTIFICATES, JSON.stringify(certificates)); }, [certificates]);
  useEffect(() => { localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions)); }, [transactions]);

  const currentUser = users.find(u => u.id === currentUserId) || users[0];

  const setCurrentUser = (user: User) => {
    setCurrentUserId(user.id);
  };

  const updateCenterSettings = (settings: Partial<CenterSettings>) => {
    setCenterSettings(prev => ({ ...prev, ...settings }));
  };

  // Helper to trigger certificate generation if requirements met
  const checkAndIssueCertificate = (studentId: string, courseId: string, updatedCompletedLessons: string[]) => {
    const course = courses.find(c => c.id === courseId);
    if (!course) return;

    // Check if already certified
    const existingCert = certificates.find(c => c.studentId === studentId && c.courseId === courseId);
    if (existingCert) return;

    // Check all course lessons
    const courseLessons = lessons.filter(l => l.courseId === courseId);
    const totalLessons = courseLessons.length;
    const completedCount = updatedCompletedLessons.length;

    // Criteria: all lessons completed (or >= 85% of lessons)
    if (totalLessons > 0 && completedCount >= totalLessons) {
      const student = users.find(u => u.id === studentId);
      const instructor = users.find(u => u.id === course.instructorId);

      const newCert: Certificate = {
        id: `cert_${Date.now()}`,
        certificateCode: `AMADEUS-${new Date().getFullYear()}-${(course.slug || 'CUR').substring(0, 3).toUpperCase()}-${Math.floor(10000 + Math.random() * 90000)}`,
        studentId: studentId,
        studentName: student ? student.name : 'Estudiante',
        courseId: course.id,
        courseTitle: course.title,
        issueDate: new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date()),
        durationHours: course.durationHours,
        centerName: centerSettings.name,
        instructorName: instructor ? instructor.name : 'Instructor Certificado',
        directorName: centerSettings.directorName
      };

      setCertificates(prev => [newCert, ...prev]);

      // Mark enrollment as completed
      setEnrollments(prev => prev.map(e => {
        if (e.studentId === studentId && e.courseId === courseId) {
          return { ...e, isCompleted: true, completedAt: new Date().toISOString().split('T')[0] };
        }
        return e;
      }));

      // Celebrate with confetti
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (err) {
        console.log(err);
      }

      // Open certificate modal directly
      setActiveCertificateModal(newCert);
    }
  };

  const enrollInCourse = (courseId: string, studentId?: string) => {
    const targetStudentId = studentId || currentUser.id;
    const existing = enrollments.find(e => e.studentId === targetStudentId && e.courseId === courseId);
    if (existing) return;

    const newEnrollment: Enrollment = {
      id: `enr_${Date.now()}`,
      studentId: targetStudentId,
      courseId,
      enrolledAt: new Date().toISOString().split('T')[0],
      completedLessonIds: [],
      isCompleted: false
    };

    setEnrollments(prev => [...prev, newEnrollment]);
  };

  const unenrollCourse = (courseId: string, studentId: string) => {
    setEnrollments(prev => prev.filter(e => !(e.courseId === courseId && e.studentId === studentId)));
  };

  const toggleLessonCompletion = (lessonId: string, courseId: string) => {
    const studentId = currentUser.id;
    setEnrollments(prev => {
      return prev.map(enr => {
        if (enr.studentId === studentId && enr.courseId === courseId) {
          const alreadyCompleted = enr.completedLessonIds.includes(lessonId);
          const updated = alreadyCompleted
            ? enr.completedLessonIds.filter(id => id !== lessonId)
            : [...enr.completedLessonIds, lessonId];

          // Check if completion qualifies for certificate
          if (!alreadyCompleted) {
            setTimeout(() => {
              checkAndIssueCertificate(studentId, courseId, updated);
            }, 300);
          }

          return {
            ...enr,
            completedLessonIds: updated
          };
        }
        return enr;
      });
    });
  };

  const submitTask = (taskId: string, comments: string, fileName?: string, fileUrl?: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    // Check if previous submission exists
    const existingIndex = taskSubmissions.findIndex(s => s.taskId === taskId && s.studentId === currentUser.id);

    const submission: TaskSubmission = {
      id: existingIndex >= 0 ? taskSubmissions[existingIndex].id : `sub_${Date.now()}`,
      taskId,
      studentId: currentUser.id,
      courseId: task.courseId,
      submittedAt: new Date().toISOString(),
      comments,
      fileName: fileName || 'Entrega_Tarea_Alumno.pdf',
      fileSize: '1.2 MB',
      fileUrl: fileUrl || 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      status: 'submitted'
    };

    if (existingIndex >= 0) {
      setTaskSubmissions(prev => {
        const copy = [...prev];
        copy[existingIndex] = submission;
        return copy;
      });
    } else {
      setTaskSubmissions(prev => [submission, ...prev]);
    }

    // Auto mark the linked lesson as completed
    if (task.lessonId) {
      toggleLessonCompletion(task.lessonId, task.courseId);
    }
  };

  const gradeTaskSubmission = (submissionId: string, score: number, feedback: string) => {
    setTaskSubmissions(prev => prev.map(sub => {
      if (sub.id === submissionId) {
        return {
          ...sub,
          score,
          feedback,
          gradedAt: new Date().toISOString(),
          gradedBy: currentUser.name,
          status: 'graded'
        };
      }
      return sub;
    }));
  };

  const submitQuizAttempt = (quizId: string, answers: Record<string, number>): QuizAttempt => {
    const quiz = quizzes.find(q => q.id === quizId);
    if (!quiz) throw new Error('Quiz not found');

    let totalScore = 0;
    let maxScore = 0;

    quiz.questions.forEach(q => {
      maxScore += q.points;
      if (answers[q.id] === q.correctOptionIndex) {
        totalScore += q.points;
      }
    });

    const passed = totalScore >= quiz.passingScore;

    const attempt: QuizAttempt = {
      id: `att_${Date.now()}`,
      quizId,
      studentId: currentUser.id,
      courseId: quiz.courseId,
      completedAt: new Date().toISOString(),
      answers,
      score: totalScore,
      maxScore,
      passed
    };

    setQuizAttempts(prev => [attempt, ...prev]);

    // If passed and linked to lesson, mark as completed
    if (passed && quiz.lessonId) {
      toggleLessonCompletion(quiz.lessonId, quiz.courseId);
    }

    if (passed) {
      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
      } catch (e) {
        console.log(e);
      }
    }

    return attempt;
  };

  const getCourseProgress = (courseId: string, studentId?: string) => {
    const targetStudentId = studentId || currentUser.id;
    const enrollment = enrollments.find(e => e.studentId === targetStudentId && e.courseId === courseId);
    const courseLessons = lessons.filter(l => l.courseId === courseId);
    const courseTasks = tasks.filter(t => t.courseId === courseId);
    const courseQuizzes = quizzes.filter(q => q.courseId === courseId);

    const completedLessonIds = enrollment?.completedLessonIds || [];
    const completedCount = completedLessonIds.length;
    const totalCount = courseLessons.length || 1;
    const percent = Math.min(100, Math.round((completedCount / totalCount) * 100));

    const cert = certificates.find(c => c.studentId === targetStudentId && c.courseId === courseId);

    const gradedTasks = taskSubmissions.filter(s => s.courseId === courseId && s.studentId === targetStudentId && s.status === 'graded').length;
    const passedQuizzes = quizAttempts.filter(a => a.courseId === courseId && a.studentId === targetStudentId && a.passed).length;

    return {
      completedLessons: completedCount,
      totalLessons: courseLessons.length,
      percent,
      isCompleted: enrollment?.isCompleted || percent >= 100,
      hasCertificate: !!cert,
      tasksTotal: courseTasks.length,
      tasksGraded: gradedTasks,
      quizzesTotal: courseQuizzes.length,
      quizzesPassed: passedQuizzes
    };
  };

  const getCertificateForCourse = (courseId: string, studentId?: string) => {
    const targetStudentId = studentId || currentUser.id;
    return certificates.find(c => c.studentId === targetStudentId && c.courseId === courseId);
  };

  // Content Management CRUD
  const createCourse = (courseData: Omit<Course, 'id' | 'createdAt'>): Course => {
    const newCourse: Course = {
      ...courseData,
      id: `course_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setCourses(prev => [newCourse, ...prev]);
    return newCourse;
  };

  const updateCourse = (id: string, updates: Partial<Course>) => {
    setCourses(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const deleteCourse = (id: string) => {
    setCourses(prev => prev.filter(c => c.id !== id));
    setModules(prev => prev.filter(m => m.courseId !== id));
    setLessons(prev => prev.filter(l => l.courseId !== id));
  };

  const createModule = (moduleData: Omit<CourseModule, 'id'>): CourseModule => {
    const newModule: CourseModule = {
      ...moduleData,
      id: `mod_${Date.now()}`
    };
    setModules(prev => [...prev, newModule]);
    return newModule;
  };

  const updateModule = (id: string, updates: Partial<CourseModule>) => {
    setModules(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));
  };

  const deleteModule = (id: string) => {
    setModules(prev => prev.filter(m => m.id !== id));
    setLessons(prev => prev.filter(l => l.moduleId !== id));
  };

  const createLesson = (lessonData: Omit<Lesson, 'id'>): Lesson => {
    const newLesson: Lesson = {
      ...lessonData,
      id: `les_${Date.now()}`
    };
    setLessons(prev => [...prev, newLesson]);
    return newLesson;
  };

  const updateLesson = (id: string, updates: Partial<Lesson>) => {
    setLessons(prev => prev.map(l => l.id === id ? { ...l, ...updates } : l));
  };

  const deleteLesson = (id: string) => {
    setLessons(prev => prev.filter(l => l.id !== id));
  };

  const createTask = (taskData: Omit<Task, 'id' | 'createdAt'>): Task => {
    const newTask: Task = {
      ...taskData,
      id: `task_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setTasks(prev => [...prev, newTask]);
    return newTask;
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    setTaskSubmissions(prev => prev.filter(s => s.taskId !== id));
  };

  const createQuiz = (quizData: Omit<Quiz, 'id' | 'createdAt'>): Quiz => {
    const newQuiz: Quiz = {
      ...quizData,
      id: `quiz_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setQuizzes(prev => [...prev, newQuiz]);
    return newQuiz;
  };

  const updateQuiz = (id: string, updates: Partial<Quiz>) => {
    setQuizzes(prev => prev.map(q => q.id === id ? { ...q, ...updates } : q));
  };

  const deleteQuiz = (id: string) => {
    setQuizzes(prev => prev.filter(q => q.id !== id));
    setQuizAttempts(prev => prev.filter(a => a.quizId !== id));
  };

  const createZoomSession = (zoomData: Omit<ZoomSession, 'id'>): ZoomSession => {
    const newZoom: ZoomSession = {
      ...zoomData,
      id: `zoom_${Date.now()}`
    };
    setZoomSessions(prev => [newZoom, ...prev]);
    return newZoom;
  };

  const updateZoomSession = (id: string, updates: Partial<ZoomSession>) => {
    setZoomSessions(prev => prev.map(z => z.id === id ? { ...z, ...updates } : z));
  };

  const deleteZoomSession = (id: string) => {
    setZoomSessions(prev => prev.filter(z => z.id !== id));
  };

  const createUser = (userData: Omit<User, 'id' | 'registeredAt'>): User => {
    const newUser: User = {
      ...userData,
      id: `usr_${Date.now()}`,
      username: userData.username || userData.email.split('@')[0],
      password: userData.password || (userData.role === 'admin' ? 'admin123' : userData.role === 'instructor' ? 'docente123' : 'estudiante123'),
      registeredAt: new Date().toISOString().split('T')[0]
    };
    setUsers(prev => [...prev, newUser]);
    return newUser;
  };

  const updateUser = (id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, ...updates } : u));
  };

  const deleteUser = (id: string) => {
    if (id === currentUser.id) {
      alert('Por seguridad institucional, no puedes eliminar tu propio usuario de administrador mientras tu sesión esté activa.');
      return;
    }
    setUsers(prev => prev.filter(u => u.id !== id));
    setEnrollments(prev => prev.filter(e => e.studentId !== id));
  };

  const login = (identifier: string, password: string, selectedRole?: UserRole): { success: boolean; message?: string; user?: User } => {
    const cleanId = identifier.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanId || !cleanPass) {
      return { success: false, message: 'Por favor completa todos los campos (usuario o correo y contraseña).' };
    }

    const foundUser = users.find(u => 
      u.email.toLowerCase() === cleanId || 
      (u.username && u.username.toLowerCase() === cleanId)
    );

    if (!foundUser) {
      return { success: false, message: 'No existe ninguna cuenta registrada con este usuario o correo electrónico.' };
    }

    const validPassword = foundUser.password || (foundUser.role === 'admin' ? 'admin123' : foundUser.role === 'instructor' ? 'docente123' : 'estudiante123');
    if (cleanPass !== validPassword) {
      return { success: false, message: 'Contraseña incorrecta. Por favor verifica tus credenciales.' };
    }

    if (selectedRole && foundUser.role !== selectedRole) {
      const roleNames: Record<UserRole, string> = {
        admin: 'Administrador',
        instructor: 'Instructor / Docente',
        student: 'Estudiante'
      };
      return { 
        success: false, 
        message: `Esta cuenta pertenece al perfil de ${roleNames[foundUser.role]}. Selecciona el rol correspondiente para ingresar.` 
      };
    }

    setCurrentUserId(foundUser.id);
    setIsAuthenticated(true);
    localStorage.setItem(STORAGE_KEYS.AUTH_STATUS, 'true');
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, foundUser.id);

    return { success: true, user: foundUser };
  };

  const addTransaction = (txData: Omit<PaymentTransaction, 'id' | 'paymentDate' | 'receiptNumber'>): PaymentTransaction => {
    const newTx: PaymentTransaction = {
      ...txData,
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      paymentDate: new Date().toISOString(),
      receiptNumber: `REC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`
    };
    setTransactions(prev => [newTx, ...prev]);
    return newTx;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem(STORAGE_KEYS.AUTH_STATUS);
  };

  const resetAllData = () => {
    localStorage.clear();
    setUsers(INITIAL_USERS);
    setCurrentUserId('usr_student_1');
    setIsAuthenticated(false);
    setCenterSettings(INITIAL_CENTER_SETTINGS);
    setCourses(INITIAL_COURSES);
    setModules(INITIAL_MODULES);
    setLessons(INITIAL_LESSONS);
    setTasks(INITIAL_TASKS);
    setTaskSubmissions(INITIAL_TASK_SUBMISSIONS);
    setQuizzes(INITIAL_QUIZZES);
    setQuizAttempts(INITIAL_QUIZ_ATTEMPTS);
    setZoomSessions(INITIAL_ZOOM_SESSIONS);
    setEnrollments(INITIAL_ENROLLMENTS);
    setCertificates(INITIAL_CERTIFICATES);
    setTransactions(INITIAL_TRANSACTIONS);
  };

  return (
    <PlatformContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        users,
        setUsers,
        centerSettings,
        updateCenterSettings,
        isAuthenticated,
        login,
        logout,
        courses,
        modules,
        lessons,
        tasks,
        taskSubmissions,
        quizzes,
        quizAttempts,
        zoomSessions,
        enrollments,
        certificates,
        transactions,
        setTransactions,
        addTransaction,
        enrollInCourse,
        unenrollCourse,
        toggleLessonCompletion,
        submitTask,
        submitQuizAttempt,
        getCourseProgress,
        getCertificateForCourse,
        gradeTaskSubmission,
        createCourse,
        updateCourse,
        deleteCourse,
        createModule,
        updateModule,
        deleteModule,
        createLesson,
        updateLesson,
        deleteLesson,
        createTask,
        updateTask,
        deleteTask,
        createQuiz,
        updateQuiz,
        deleteQuiz,
        createZoomSession,
        updateZoomSession,
        deleteZoomSession,
        createUser,
        updateUser,
        deleteUser,
        resetAllData,
        activeCertificateModal,
        setActiveCertificateModal
      }}
    >
      {children}
    </PlatformContext.Provider>
  );
};

export const usePlatform = () => {
  const context = useContext(PlatformContext);
  if (!context) {
    throw new Error('usePlatform must be used within a PlatformProvider');
  }
  return context;
};
